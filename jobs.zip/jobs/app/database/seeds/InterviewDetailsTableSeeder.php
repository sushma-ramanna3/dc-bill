<?php

class InterviewDetailsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('interview_details')->truncate();

		$interview_details = array(

		);

		// Uncomment the below to run the seeder
		 //DB::table('interview_details')->insert($interview_details);
	}

}
