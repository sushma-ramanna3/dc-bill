<?php

class UsersTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		DB::table('users')->truncate();

		$users = array(
					'first_name'=>'FLIP',
					'last_name'=>'ADMIN',
					'password' => Hash::make('31JbiSn9MGhE'),
					'email' => 'ratnesh@learnwithflip.com',
					'usertype' => 'admin',
					'created_at' => new DateTime,
					'updated_at' => new DateTime
		);
		
		$users = array(
					'first_name'=>'FLIP',
					'last_name'=>'ADMIN',
					'password' => Hash::make('admin@flip'),
					'email' => 'jai@learnwithflip.com',
					'usertype' => 'admin',
					'created_at' => new DateTime,
					'updated_at' => new DateTime
		);
		//Uncomment the below to run the seeder
		DB::table('users')->insert($users);
	}

}