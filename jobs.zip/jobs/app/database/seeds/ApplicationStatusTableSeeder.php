<?php

class ApplicationStatusTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating

		// DB::table('applicationstatus')->truncate();

		$applicationstatus = array(
			[ 'status'=> 'Applied' ],
			[ 'status'=> 'Not Paid' ],
			[ 'status'=> 'Registered' ],
			[ 'status'=> 'Eligible' ],
			[ 'status'=> 'Not Eligible' ],
			[ 'status'=> 'Confirmed Application' ],
			[ 'status'=> 'Attending Interview' ],
			[ 'status'=> 'Cleared' ],
			[ 'status'=> 'Rejected' ],
			[ 'status'=> 'Did Not Attend' ],
			[ 'status'=> 'Enrolled' ],
			[ 'status'=> 'Certified' ],
			[ 'status'=> 'Full Payment' ],
			[ 'status'=> 'Accecpted Offer' ],
		);

		// Uncomment the below to run the seeder
		DB::table('application_status')->insert($applicationstatus);

		
	

	}

}
