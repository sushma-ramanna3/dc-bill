<?php

class JobsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('jobs')->truncate();

		$jobs = array(
			
		);

		// Uncomment the below to run the seeder
		// DB::table('jobs')->insert($jobs);
	}

}
