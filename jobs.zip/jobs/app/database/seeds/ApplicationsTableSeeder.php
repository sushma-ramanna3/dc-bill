<?php

class ApplicationsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('applications')->truncate();

		$applications = array(
			'user_id'=>'1',
			'job_id'=>'2',
			'reference_id' => 'FIRTKO123',
			'sslc_percentage' => '90',
			'sslc_year' => '2004',
			'puc_percentage' => '89',
			'puc_year' => '2006',
			'graduation_percentage' => '87',
			'graduation_year' => '2010',
			'graduation' => '2',
			'post_graduation_percentage' => '85',
			'post_graduation_year' => '2013',
			'post_graduation' => '1',
			'preferred_location' => '3',
			'cv_path' => '/assests/uploads/cv/Roopa_Interview_FLIP_Newsletter.docx',
			'created_at' => new DateTime,
			'updated_at' => new DateTime	
		);

		// Uncomment the below to run the seeder
		 DB::table('applications')->insert($applications);
	}

}
