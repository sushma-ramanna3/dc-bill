<?php

class TrackApplicationStatusTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('track_application_status')->truncate();

		$track_application_status = array(
			'application_id' => '2',
			'status' => '2',
			'created_at' => new DateTime,
			'updated_at' => new DateTime
		);

		// Uncomment the below to run the seeder
		 DB::table('track_application_status')->insert($track_application_status);
	}

}
