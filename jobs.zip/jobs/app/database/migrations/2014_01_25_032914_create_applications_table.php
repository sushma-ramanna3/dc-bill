<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateApplicationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('applications', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('user_id');
			$table->integer('job_cat_id');
			//$table->string('reference_id');
			$table->integer('sslc_percentage');
			$table->integer('sslc_year');
			$table->integer('puc_percentage');
			$table->integer('puc_year');
			$table->integer('graduation_percentage');
			$table->integer('graduation_year');
			$table->integer('graduation');
			$table->integer('post_graduation_percentage');
			$table->integer('post_graduation_year');
			$table->integer('post_graduation');
			$table->integer('preferred_location');
			$table->string('cv_path');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('applications');
	}

}
