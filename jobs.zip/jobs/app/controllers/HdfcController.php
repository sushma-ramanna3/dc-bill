<?php

use Carbon\Carbon;

class HdfcController extends BaseController {

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{

		$dob_rule = array(
				'dob' => 'After:1986-05-29'
			);

		$dob = array(
			'dob'	=> Input::get('dob_year').'-'.Input::get('dob_month').'-'.Input::get('dob_day')
			);

		$dob_validator = Validator::make($dob, $dob_rule);

		$rules = array(
		        'first_name' => 'Required|Min:3|Max:80',
		        'last_name' => 'Required|Min:1|Max:80',
		        'phone' => 'Required|numeric|Min:10',
		        'email'     => 'Required|Between:3,64|Email',
		        // 'resume'	=> 'Required',
		        'preferred_interview_location' => 'Required',
		        'graduation_percentage' => 'Required|Min:2',
		        // 'post_graduation_stream' => 'Required',
		        'graduation_year' => 'Required|Min:4',
		        'graduation_stream' => 'Required',
		        'attended' => 'Required',
		        'home_location' => 'Required|Min:3|Max:80',
		        'current_location' => 'Required|Min:3|Max:80',
		        'work_experience' => 'Required',
		        'preferred_job_location_1' => 'Required|Min:3|Max:80',
		        'preferred_job_location_2' => 'Required|Min:3|Max:80',
		        'preferred_job_location_3' => 'Required|Min:3|Max:80',
		        'sslc_percentage' => 'Required',
		        'relocate' => 'Required',
		        'puc_percentage' => 'Required'
		);
		$messages = array(
		   // 'email.unique' => 'You have already applied to this job with the same email ID. Please check your mail box for earlier job application details.',
		    'last_name.Alpha' => 'The last name may only contain one word and only letters. '
		   // 'phone.unique' => 'You have already applied to this job with the same phone number. Please check your mail box for earlier job application details.',
		);

		$validator = Validator::make(Input::all(), $rules, $messages);
		$data = Input::all();

		if ($validator->passes()) {
			$appid = '';
			
			$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');

			$jobids = array('4','5','6','7');

			if(isset($userid)){
				$appid = DB::table('hdfc_applications')->where('user_id', '=', $userid)
				->whereIn('job_id', $jobids)
				->pluck('id');
			}

			if($appid){
			 	return Response::json(array('status' => 'duplicate'));
			}
			else{
				//get age from date or birthdate
				$age = (date("md", date("U", mktime(0, 0, 0, Input::get('dob_month'), Input::get('dob_day'), Input::get('dob_year')))) > date("md")
				    ? ((date("Y") - Input::get('dob_year')) - 1)
				    : (date("Y") - Input::get('dob_year')));

				if(!isset($userid)){

					$user_details = array(
						'first_name' => Input::get('first_name'), 
						'last_name' => Input::get('last_name'),
						'email' => Input::get('email'),
						'password' => '',
						'usertype' => 'Registered',
						'phone' => Input::get('phone'),
						'dob' => Input::get('dob_day').'-'.Input::get('dob_month').'-'.Input::get('dob_year'),
						'age' => $age,
						'created_at' => new DateTime,
						'updated_at' => new DateTime
						);
						DB::table('users')->insert($user_details);
					$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');
				}

				$userid = isset($user->id) ? $user->id : $userid ;

				if (Input::hasFile('resume'))
				{
				    Input::file('resume')->move( app_path().'/views/resumes/', $userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName());
					$cv_path = app_path().'/views/resumes/'.$userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName();
				}


				$post_graduation_stream = Input::get('post_graduation_stream');
				if( $post_graduation_stream == "MBA - Others"){
					$post_graduation_stream = Input::get('others_specialization');
				}
				$relocation_specific = '';
				
				if( Input::get('relocation_specific') ) { 
					$relocation_specific = Input::get('relocation_specific');
					$relocation_specific = implode(',', $relocation_specific);
					$relocation_specific = str_replace(',', '', $relocation_specific);
				}

				$cv_path = isset($cv_path) ? $cv_path : '' ;
				$application_details = array(
											'job_id' => Input::get('job_id'),
											'reference_id' => '',
											'user_id' => $userid,
											'sslc_percentage' => round(rtrim(Input::get('sslc_percentage'),'%')),
											'sslc_year' => Input::get('sslc_year'),
											'puc_percentage' => round(rtrim(Input::get('puc_percentage'),'%')),
											'puc_year' => Input::get('puc_year'),
											'graduation_percentage' => round(rtrim(Input::get('graduation_percentage'),'%')),
											'graduation_year' => Input::get('graduation_year'),
											'graduation' => Input::get('graduation_stream'),
											'post_graduation_percentage' => round(rtrim(Input::get('post_graduation_percentage'),'%')),
											'post_graduation_year' => Input::get('post_graduation_year'),
											'post_graduation' => $post_graduation_stream,
											'post_graduation_college' => Input::get('post_graduation_college'),
											'result_status' => Input::get('result_status'),
											'other_college' => Input::get('other_colleges'),
											'ca_attempts' => Input::get('attempts'),
											'preferred_interview_location' => Input::get('preferred_interview_location'),
											'home_location' => Input::get('home_location'),
											'current_location' => Input::get('current_location'),
											'highest_qualification' => '',
											'work_experience' => Input::get('work_experience'),
											'attended' => Input::get('attended'),
											'preferred_job_location_1' => Input::get('preferred_job_location_1'),
											'preferred_job_location_2' => Input::get('preferred_job_location_2'),
											'preferred_job_location_3' => Input::get('preferred_job_location_3'),
											'relocate' => Input::get('relocate'),
											'relocation_specific' => $relocation_specific,
											'cv_path' => $cv_path
										  );

				$application = HdfcApplications::create($application_details);
				$ref_id = 'HDFC'.strtoupper(substr(md5($application->id), 0, 8));
				$application->reference_id = $ref_id;
				$application->save();

				// check if the candidate is eligible
				$status_code =  $this->isEligible($application, $age);

				if(!$dob_validator->passes()){
					$status_code = 21;
				}

				$application_status_details = array('application_id' => $application->id,
												'status' => $status_code,	// status 1 for applied & eligible without answering the questions
												'test_date' => '',
												'created_at' => new DateTime,
												'updated_at' => new DateTime ,
												'mail_sent' => ''
											);
				$application_status = HdfcTrackApplication::create($application_status_details);

				// send a notification to the customer
				
				if(Input::get('job_id') == 4) $job_title = 'Trade Sales Manager';
	            elseif(Input::get('job_id') == 5) $job_title = 'Branch Relationship Manager';
	            elseif(Input::get('job_id') == 6) $job_title = 'Relationship Manager - Business Banking';
	            elseif(Input::get('job_id') == 7) $job_title = 'Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG)';

				$data = array('name'=>Input::get('first_name'),'status'=>'applied', 'category'=>'HDFC Bank', 'job_title'=>$job_title,'reference_id'=>$ref_id, 'track_url'=>'http://jobs.learnwithflip.com/track');

				Mail::send('emails.hdfcmail', $data, function($message) use ($application)
				{
					$message->from('ratnesh@learnwithflip.com', 'Ratnesh');
				    $message->to(Input::get('email'), Input::get('first_name').' '.Input::get('last_name'))->subject('Job Application - Relationship Manager Program with HDFC Bank');
				});
				
				if(!$dob_validator->passes()){
					return Response::json(array('status' => '21'));
				}

				if ($status_code == 21) {
					return Response::json(array('status' => $status_code));
				}else if($status_code == 20){
					return Response::json(array('status' => $status_code,'job_id' => Input::get('job_id'), 'application_id' => $application->id ));
				}
				return Response::json(array('status' => $status_code));
			}

		}
		return Response::json(array('status' => 'validator'));
	}


	public function questionnarie()
	{
		if( Input::get('questionnarie') ) {
				$application_status_details = array('application_id' => Input::get('application_id'),
										'status' => '22',	// status test pass
										'test_date' => '',
										'created_at' => new DateTime,
										'updated_at' => new DateTime ,
										'mail_sent' => ''
									);
				$application_status = HdfcTrackApplication::create($application_status_details);

				$all = Input::get('q7').','.Input::get('q8');
				$questionnarie = array('application_id' => Input::get('application_id'),
							'answers' => $all,	// status test pass
							'created_at' => new DateTime,
							'updated_at' => new DateTime ,
						);
				$questionnarie_answers = HdfcQuestionnarie::create($questionnarie);

				//$this->questionnarie_ans(Input::get('application_id'), Input::all());
				//This takes the user to the payment gateway

				$users = DB::table('users')
				->join('hdfc_applications', 'users.id', '=', 'hdfc_applications.user_id')
				->select('users.email', 'users.phone', 'users.id', 'hdfc_applications.id as app_id')
				->where('hdfc_applications.id', Input::get('application_id'))
				->get();
				
				foreach ($users as $value) {
					$data = array('email' => $value->email, 'phone' => $value->phone, 'user_id' => $value->id, 'app_id' => $value->app_id);
				}
				//
				 $url = $this->charge_user($data);
				 return Redirect::to($url);
			}
			// send a notification to the customer
			
			/*$data = array('name'=>Input::get('first_name'),'status'=>'Applied', 'category'=>'HDFC Bank', 'job_title'=>'job','reference_id'=>strtoupper(substr(md5($application->id), 0, 8)), 'track_url'=>'http://jobs.learnwithflip.com/track');

			Mail::send('emails.email', $data, function($message) use ($application)
			{
			    $message->to(Input::get('email'), Input::get('first_name').' '.Input::get('last_name'))->subject('Job Application - job');
			});*/
			
			//return View::make('applications.payment')->with('id', Input::get('job_id') )->with('application_id', Input::get('application_id'));
			
		/*return Redirect::to('/guaranteed-bank-job/HDFC/')
			->withInput()
			->withErrors($validator);*/
	}

	/*public function questionnarie_ans($app_id, $data){
		$questionnarie = array('application_id' => $app_id,
							'answers' => serialize($data),	// status test pass
							'created_at' => new DateTime,
							'updated_at' => new DateTime ,
						);
		$questionnarie_answers = HdfcQuestionnarie::create($questionnarie);
	}*/

	private function charge_user($data)
	{
		$merchant_transaction_id = $data['app_id'].'FLIP'.time();

		// save the transaction to database
		$payment_details = array(
				'flip_transaction_id' => $merchant_transaction_id,
				'user_id' => $data['user_id'],
				'application_id' => $data['app_id'],
				'amount' => 75000,
				'status' => 'P',  // 'P' for pending & 'C' for Confirmed
				'type' => '',
				'payment_message' => null,
				'payzippy_transaction_id' => null,
				'created_at' => new DateTime,
				'updated_at' => new DateTime
			);
		$payment = Payment::create($payment_details);

		// send a charge request to payzippy
		$payzippy = new ChargingRequest();
		$payzippy->set_buyer_email_address($data['email']);
		$payzippy->set_buyer_phone_no($data['phone']);
		$payzippy->set_transaction_amount(75000);
		//$payzippy->set_payment_method('Optional');
		$payzippy->set_ui_mode('REDIRECT');
		$payzippy->set_merchant_transaction_id($merchant_transaction_id);
		$payzippy->set_callback_url('http://jobs.learnwithflip.com/payment');
		$request = $payzippy->charge();
		//dd($request['params']);
		$url = $request['url'].'?'.http_build_query($request['params']);
		return $url;
	}

	public function payment_response()
	{
		$response = Input::all();
		$merchant_transaction_id = explode('FLIP', $response['merchant_transaction_id']);
		$application_id = $merchant_transaction_id[0];
		
		$flip_transaction_id = $response['merchant_transaction_id'];

		if($response['merchant_transaction_id']){
			$user_id = DB::table('hdfc_applications')->where('id','=', $application_id)->pluck('user_id');
		}

		// details needed to send mail
		$user = DB::table('users')
			->join('hdfc_applications', 'users.id', '=', 'hdfc_applications.user_id')
			->select('users.first_name', 'users.last_name', 'users.email', 'users.phone')
			->where('hdfc_applications.id', $application_id)
			->get();

		// Change the status of the payment
		if ($response['transaction_response_code'] == 'SUCCESS') {
			$response_details = array(
					'amount' => $response['transaction_amount'],
					'status' => 'C',
					'payment_message' => $response['transaction_response_code'],
					'payzippy_transaction_id' => $response['payzippy_transaction_id'],
					'updated_at' => new DateTime
					);
			DB::table('payment')
					->where('flip_transaction_id',$flip_transaction_id)
					->update($response_details);

			foreach ($user as $usr) {
				$first_name = $usr->first_name;
				$email = $usr->email;
			}

			$job_title = DB::table('jobs')
				->join('hdfc_applications', 'jobs.id', '=', 'hdfc_applications.job_id')
				->where('hdfc_applications.id', $application_id)
				->pluck('jobs.title');

			$ref_id = 'HDFC'.strtoupper(substr(md5($application_id), 0, 8));

			$data = array('name'=>$first_name, 'status'=>'24', 'job_title'=>$job_title,'reference_id'=>$ref_id, 'track_url'=>'http://jobs.learnwithflip.com/track');

			Mail::send('emails.hdfcmail', $data, function($message) use ($email)
			{
				$message->from('ratnesh@learnwithflip.com', 'Ratnesh');
			    $message->to($email)->subject('Payment Confirmation - Relationship Manager Program with HDFC Bank');
			});
			//end

			$application_status_details = array('application_id' => $application_id,
											'status' => '24',	// payment done
											'test_date' => '',
											'created_at' => new DateTime,
											'updated_at' => new DateTime ,
											'mail_sent' => '1'
										);
			$application_status = HdfcTrackApplication::create($application_status_details);

		}
		else{
			$response_details = array(
					'amount' => $response['transaction_amount'],
					'status' => 'X',
					'payment_message' => $response['transaction_response_code'],
					'payzippy_transaction_id' => $response['payzippy_transaction_id'],
					'updated_at' => new DateTime
					);
			DB::table('payment')
					->where('flip_transaction_id',$flip_transaction_id)
					->update($response_details);
		}

		

		// send a notification to the user
		Mail::queue('emails.payment', $response, function($message)
		{
		    $message->to('nandeesh.mp@finitiatives.com', 'Nandeesh Mp')
		    	->subject('Finitiatives Learning India Pvt. Ltd : Payment details !');
		});

		return View::make('applications.payment')
						->with('user', $user)
						->with('response', $response);

	}

	public function isEligible($application,$age)
	{
		if ($application->post_graduation_percentage == 0) {
			$application->post_graduation_percentage = 999;
		}

		if (!isset($application->post_graduation_stream)) {
			$application->post_graduation_stream = false;
		}

		if ( $application->sslc_percentage 				< 50 ||
			 $application->puc_percentage  				< 50 ||
			 $application->graduation_percentage 		< 50 ||
			 $application->post_graduation_percentage 	< 50 ||
			 $application->attended 				    == 1 ||
			 Input::get('post_graduation_stream')		== "MBA Human Resource" ||
			 Input::get('post_graduation_stream') 		== "MBA Operations, Systems" ||
			 Input::get('work_experience')				== "More than 2 Years"

		) {
			return 21;
		}else if( ( $application->job_id == 6 OR  $application->job_id == 7 )  &&
			Input::get('post_graduation_stream') == 'CA'						&&
			Input::get('attempts') == 'More than 5'
		){
			return 21;
		}
		else{
			return 20;
		}

	}

	public function download()
	{
		
	}

	public function orders($application_id = null)
	{

		if($application_id !== null){

			$user = DB::table('users')
					->join('hdfc_applications', 'users.id', '=', 'hdfc_applications.user_id')
					->select('users.first_name', 'users.last_name', 'users.email', 'users.phone')
					->where('hdfc_applications.id', $application_id)
					->get();

		$order = DB::table('payment')
						->join('users', 'payment.user_id', '=', 'users.id')
						->where('payment.application_id', $application_id)
						->get();

		return View::make('applications.invoice')->with('user',$user)->with('order',$order);

		}

		$orders = DB::table('payment')
					->join('users', 'payment.user_id', '=', 'users.id')
					->where('payment.status', 'C')
					->paginate(15);

		return View::make('applications.orders')->with('orders',$orders);
	}

	public function updateOrderStatus()
	{
		$pending_orders = DB::table('payment')
							->select('flip_transaction_id','application_id')
							->where('status','P')
							->get();

		$query_request = new QueryRequest();

		foreach ($pending_orders as $order) {

			$query_request->set_merchant_transaction_id($order->flip_transaction_id);
			$response = $query_request->query();
			$response_params = $response->get_response_params();

			if(!isset($response_params['data'][0])){
				continue;
			}

			if($response_params['data'][0]['transaction_response_code'] == 'SUCCESS'){

				$status = 'C';

				$application_status_details = array('application_id' => $order->application_id,
								'status' => '24',	// payment done
								'test_date' => '',
								'created_at' => new DateTime,
								'updated_at' => new DateTime ,
								'mail_sent' => '1'
							);
				$application_status = HdfcTrackApplication::create($application_status_details);

			}else if($response_params['data'][0]['transaction_response_code'] == 'FAILURE'){
				$status = 'X';
			}else if($response_params['data'][0]['transaction_response_code'] == 'INITIATED'){
				$status = 'I';
			}
				$response_details = array(
						'amount' => $response_params['data'][0]['transaction_amount'],
						'status' => $status,
						'payment_message' => $response_params['data'][0]['transaction_response_code'],
						'payzippy_transaction_id' => $response_params['data'][0]['payzippy_transaction_id'],
						'updated_at' => new DateTime
						);

				DB::table('payment')
						->where('flip_transaction_id',$response_params['data'][0]['merchant_transaction_id'])
						->update($response_details);

		}

		return Redirect::to('orders')->with('message','Order Status Update Successfully');
	}

}