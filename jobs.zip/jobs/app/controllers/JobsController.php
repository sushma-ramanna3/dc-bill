<?php

class JobsController extends BaseController {


	
	public function __construct()
	{
		$this->beforeFilter('admin', array('only'=>array('create', 'store', 'edit', 'update', 'destroy')));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$jobs = Job::all();
        return View::make('jobs.index')->with('jobs',$jobs);
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
        return View::make('jobs.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		// validate
		// read more on validation at http://laravel.com/docs/validation
		$rules = array(
			'job_cat_id'  		=> 'required',
			'title'    		=> 'required',
			'category' 		=> 'required',
			'description' 	=> 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the creation
		if ($validator->fails()) {
			return Redirect::to('jobs/create')
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else {
			// store
			$job = new Job;
			$job->job_cat_id    = Input::get('job_cat_id');
			$job->title      	= Input::get('title');
			$job->category 		= Input::get('category');
			$job->lms_id    	= Input::get('lms_id');
			$job->product_id    = Input::get('product_id');
			$job->description 	= Input::get('description');
			$job->publish 		= Input::get('publish');
			if($job->publish != 1) $job->publish = 0;
			$job->save();

			// redirect
			Session::flash('message', 'Successfully created job!');
			return Redirect::to('jobs');
		}
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
        $job = Job::find($id);
        return View::make('jobs.show')->with('job',$job);

	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
        //return View::make('jobs.edit');
        $job = Job::find($id);
		return View::make('jobs.edit')->with('job', $job);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		// validate
		// read more on validation at http://laravel.com/docs/validation
		$rules = array(
			'job_cat_id'  		=> 'required',
			'title'    		=> 'required',
			'category' 		=> 'required',
			'description' 	=> 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the creation
		if ($validator->fails()) {
			return Redirect::to('jobs/'.'$id'.'/edit')
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else {
			// store
			$job = Job::find($id);
			$job->job_cat_id       = Input::get('job_cat_id');
			$job->title      	= Input::get('title');
			$job->category 		= Input::get('category');
			$job->lms_id    	= Input::get('lms_id');
			$job->product_id    = Input::get('product_id');
			$job->description 	= Input::get('description');
			$job->publish 		= Input::get('publish');
			if($job->publish != 1) $job->publish = 0;
			$job->save();

			// redirect
			Session::flash('message', 'Successfully updated job!');
			return Redirect::to('jobs');
		}
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		// delete
		$job = Job::find($id);
		$job->delete();

		// redirect
		Session::flash('message', 'Successfully deleted the job!');
		return Redirect::to('jobs');
	}

}
