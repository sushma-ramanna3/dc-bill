<?php

class ApplicationStatusController extends BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$application_id = Cookie::get('application_id');
		$reference_id = Cookie::get('reference_id');

		if(isset($application_id) AND isset($reference_id)){

			$application = DB::table('hdfc_applications')->where("id", "=", $application_id)->get();

			$status = DB::table('hdfc_track_application')
					->join('application_status', function($join) use ($application_id)
			        {
			            $join->on('hdfc_track_application.status', '=', 'application_status.id')
			                 ->where("hdfc_track_application.application_id", "=", $application_id );
			        })
					->orderBy('hdfc_track_application.id', 'ASC')
					->select('hdfc_track_application.id', 
						'hdfc_track_application.application_id',
						'application_status.status',
						'application_status.status_message',
						'hdfc_track_application.created_at',
						'hdfc_track_application.updated_at'
						)
					->get();
			$job = Job::find($application[0]->job_id);
			$data = array('application' => $application, 'status' => $status, 'job' => $job);

			return View::make('applicationstatus.hdfc')
							->with('data',$data);

		}else if (isset($application_id)) {
			$application = DB::table('applications')->where("id", "=", $application_id)->get();

			$status = DB::table('track_application_status')
					->join('application_status', function($join) use ($application_id)
			        {
			            $join->on('track_application_status.status', '=', 'application_status.id')
			                 ->where("track_application_status.application_id", "=", $application_id );
			        })
					->orderBy('track_application_status.id', 'ASC')
					->select('track_application_status.id', 
						'track_application_status.application_id',
						'application_status.status',
						'application_status.status_message',
						'track_application_status.created_at',
						'track_application_status.updated_at'
						)
					->get();
			$job = Job::find($application[0]->job_id);
			$data = array('application' => $application, 'status' => $status, 'job' => $job);

			return View::make('applicationstatus.show')
							->with('data',$data);
		}

        return View::make('applicationstatus.track');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
        return View::make('applicationstatus.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{

		$rules = array(
		        'email'     => 'Required|Between:3,64|Email',
		        'reference_id'	=> 'Required'
		);

		$validator = Validator::make(Input::all(), $rules);
		if (!$validator->passes()) {
			return Redirect::back()->withInput()->with('flash_message', 'Your details are invalid');
		}

		$email = Input::get('email');
		$reference_id = Input::get('reference_id');

		$user = DB::table('users')->where("email", "=", $email)->get();

		if (!isset($user[0]->id)) {
			return Redirect::back()->with('flash_message', 'Entered email is not valid')->withInput();
		}

		// if the reference id begins with 'HDFC' we are taking a completely different route
		if('HDFC' == substr($reference_id,0,4)){
			$this->trackHDFCStatus($user, $reference_id);
			return Redirect::back();
		}

		$applications = DB::table('applications')->where("user_id", "=", $user[0]->id)->get();
		$application = null;
		foreach ($applications as $key => $value) {
			if (strtoupper(substr(md5($value->id), 0, 8)) == $reference_id) {
				$application = $applications[$key];
			}
		}
		if(!isset($application)){
			return Redirect::back()->with('flash_message', 'Entered reference is not valid')->withInput();
		}
		$application = array(0 => $application);

		// $application = DB::table('applications')->where("id", "=", $reference_id)->get();
		if(!isset($application[0]->id)){
			return Redirect::back()->with('flash_message', 'Entered reference is not valid')->withInput();
		}
		$application_id = $application[0]->id;
		$status = DB::table('track_application_status')
					->join('application_status', function($join) use ($application_id)
			        {
			            $join->on('track_application_status.status', '=', 'application_status.id')
			                 ->where("track_application_status.application_id", "=", $application_id );
			        })
					->orderBy('track_application_status.id', 'ASC')
					->select('track_application_status.id', 
						'track_application_status.application_id',
						'application_status.status',
						'application_status.status_message',
						'track_application_status.created_at',
						'track_application_status.updated_at'
						)
					->get();					
		$job = Job::find($application[0]->job_id);
		$data = array('user' => $user, 'application' => $application, 'status' => $status, 'job'=> $job);

		Cookie::queue('application_id', $application_id, '5');
		return View::make('applicationstatus.show')
						->with('data',$data);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{

        return View::make('applicationstatus.show');
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
        return View::make('applicationstatus.edit');
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function updateStatus()
	{

		$application = DB::table('track_application_status')
								->where("application_id", "=", Input::get('application_id'))
								->where("status", "=", Input::get('status'))
								->get();
		if (isset($application[0]->id)) {
			return Redirect::to('/applicationstatus');
		}

		$status = TrackApplicationStatus::create(array( 'application_id' => Input::get('application_id'),
				'status' => Input::get('status'),
				'created_at' => new DateTime(),
				'updated_at' => new DateTime()
				));

		return Redirect::to('/applicationstatus');
	}

	/**
	 * track status for hdfc bank
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function trackHDFCStatus($user,$reference_id)
	{
		
		$applications = DB::table('hdfc_applications')->where("user_id", "=", $user[0]->id)->get();
		$application = null;
		foreach ($applications as $key => $value) {
			if ( 'HDFC'.strtoupper(substr(md5($value->id), 0, 8) ) == $reference_id ) {
				$application = $applications[$key];
			}
		}
		if(!isset($application)){
			return Redirect::back()->with('flash_message', 'Entered reference is not valid')->withInput();
		}

		$application = array(0 => $application);

		// $application = DB::table('applications')->where("id", "=", $reference_id)->get();
		if(!isset($application[0]->id)){
			return Redirect::back()->with('flash_message', 'Entered reference is not valid')->withInput();
		}

		$application_id = $application[0]->id;
		$status = DB::table('track_application_status')
					->join('application_status', function($join) use ($application_id)
			        {
			            $join->on('track_application_status.status', '=', 'application_status.id')
			                 ->where("track_application_status.application_id", "=", $application_id );
			        })
					->orderBy('track_application_status.id', 'ASC')
					->select('track_application_status.id', 
						'track_application_status.application_id',
						'application_status.status',
						'application_status.status_message',
						'track_application_status.created_at',
						'track_application_status.updated_at'
						)
					->get();					
		$job = Job::find($application[0]->job_id);
		$data = array('user' => $user, 'application' => $application, 'status' => $status, 'job'=> $job);

		Cookie::queue('application_id', $application_id, '5');
		Cookie::queue('reference_id', $reference_id, '5');
		return View::make('applicationstatus.show')
						->with('data',$data);



	}

	public function charge_user()
	{

		$application = HdfcApplications::find(Input::get('application_id'));
		
		$user = User::find($application->user_id);

		$merchant_transaction_id = $application->id.'FLIP'.time();

		// save the transaction to database
		$payment_details = array(
				'flip_transaction_id' => $merchant_transaction_id,
				'user_id' => $application->user_id,
				'application_id' => $application->id,
				'amount' => 75000,
				'status' => 'P',  // 'P' for pending & 'C' for Confirmed
				'type' => '',
				'payment_message' => null,
				'payzippy_transaction_id' => null,
				'created_at' => new DateTime,
				'updated_at' => new DateTime
			);
		$payment = Payment::create($payment_details);		

		/*if($application->id == 361) $application->id = '0361';*/

		
		// send a charge request to payzippy
		$payzippy = new ChargingRequest();
		$payzippy->set_buyer_email_address($user->email);
		$payzippy->set_buyer_phone_no($user->phone);
		$payzippy->set_transaction_amount(75000);
		$payzippy->set_ui_mode('REDIRECT');
		$payzippy->set_merchant_transaction_id($merchant_transaction_id);
		$payzippy->set_callback_url('http://jobs.learnwithflip.com/payment');
		$request = $payzippy->charge();
		$url = $request['url'].'?'.http_build_query($request['params']);
		return Redirect::to($url);
	}

	public function certificationStatus()
	{

		$rules = array(
			'job_cat_id'  => 'required' 
		);
		$validator = Validator::make(Input::all(), $rules);

		if ($validator->fails()) {
			return Redirect::to('users')->withErrors($validator)->withInput();
		} 
		else 
		{
			$enrolled_emails = array(); 
			$certified_emails = array();
			$result = array();
			$application_ids = array();
			$lms_id = '';

			$midArr = TrackApplicationStatus::getLatestStatus();
			
			$enrolled_users = DB::table('users')
					            ->join('applications', 'users.id', '=', 'applications.user_id')
					            ->join('track_application_status', 'applications.id', '=', 'track_application_status.application_id')
					            ->join('jobs', 'applications.job_id', '=', 'jobs.id')
					            ->select('users.email', 'applications.id', 'jobs.lms_id') 
					    		->whereIn('track_application_status.id', $midArr)
					    		->where('track_application_status.status', Input::get('status')) 
					    		->where('jobs.job_cat_id', Input::get('job_cat_id'))
					    		->get(); 

			if($enrolled_users) {
			    foreach ($enrolled_users as $user) {
			    	$enrolled_emails[] = $user->email;
			    	$lms_id = $user->lms_id;
			    	$app_ids[] = $user->id;
			    }
			
				$candidates_list = DB::connection('mysql2')
									->table('jos_uploadscore')
									->join('jos_uploadcertification', 'jos_uploadcertification.candidateid', '=', 'jos_uploadscore.candidateid')
									->select('jos_uploadcertification.email', 'jos_uploadscore.result')
									->whereIn('jos_uploadcertification.email', $enrolled_emails)
									->where('jos_uploadscore.courseid', '=', $lms_id)
									->get();

				foreach ($candidates_list as $list) {
			    	$certified_emails[] = $list->email;
			    	$result[] = $list->result;
			    }
			}

			if($candidates_list) {
				
				$app_merge = array_combine($enrolled_emails, $app_ids);
				$res_merge = array_combine($certified_emails, $result);
				$diff =  array_diff($enrolled_emails, $certified_emails ); //getting arrays difference

				foreach($app_merge as $val=>$key) { // filtering array
					if(in_array($val, $diff)) {
						unset($app_merge[$val]);
					}
				} 
				
				foreach($res_merge as $val=>$key) { // getting app id and result into arrays by mapping array keys
					$application_ids[] = $app_merge[$val]; // list of application ids
					$result_fin[] = $key; // status
				}
				
				if($application_ids) {

					for($i=0; $i<count($application_ids); $i++) {

						if($result_fin[$i] === "PASS") $result_fin[$i] = 12;
						elseif($result_fin[$i] === "FAIL") $result_fin[$i] = 13;
						elseif($result_fin[$i] === "ABSENT") $result_fin[$i] = 14;

						TrackApplicationStatus::create(array( 'application_id' => $application_ids[$i],
							'status' => $result_fin[$i],
							'created_at' => new DateTime(),
							'updated_at' => new DateTime()
						));
					}
				}

				return Redirect::to('users')->with('success', 'Status updated successfully.');
			}
			else {
				return Redirect::to('users')->with('warning', 'No users found matching the criteria.');
			}
		}

	}

	//HDFC job first installment status update

	public function updatePaymentStatus()
	{

		$job_ids = array(4,5,6,7);
		$midArr = HdfcTrackApplication::getLatestStatus();
		
		$interview_cleared_users = DB::table('users')
				            ->join('hdfc_applications', 'users.id', '=', 'hdfc_applications.user_id')
				            ->join('hdfc_track_application', 'hdfc_applications.id', '=', 'hdfc_track_application.application_id')
				            ->join('jobs', 'hdfc_applications.job_id', '=', 'jobs.id')
				            ->select('users.email', 'hdfc_applications.id', 'jobs.product_id') 
				    		->whereIn('hdfc_track_application.id', $midArr)
				    		->where('hdfc_track_application.status', 28) // interview cleared status for hdfc jobs
				    		->whereIn('jobs.id', $job_ids)
				    		->get(); 

		if($interview_cleared_users) {
		    foreach ($interview_cleared_users as $user) {
		    	$interview_cleared_emails[] = $user->email;
		    	$product_ids[] = $user->product_id;
		    	$app_ids[] = $user->id;
		    }
		   	//dd($interview_cleared_emails);
			//dd($product_ids);
			//dd($app_ids);

			$userids = DB::connection('mysql2')->table('jos_users')
						->select('id')
						->whereIn('email', $interview_cleared_emails)
						->get();

			//dd($userids);

			if($userids){

				foreach ($userids as $id) {
					$user_ids[] = $id->id;
				}

				$paid_user_emails = DB::connection('mysql2')
									->table('jos_vm_orders')
									->join('jos_vm_order_item', 'jos_vm_orders.order_id','=','jos_vm_order_item.order_id')
									->join('jos_vm_order_user_info', 'jos_vm_orders.order_id','=','jos_vm_order_user_info.order_id')
									->select('jos_vm_order_user_info.user_email')
									->whereIn('jos_vm_orders.user_id', $user_ids)
									->where('jos_vm_orders.order_status', '=', 'C')
									->whereIn('jos_vm_order_item.product_id', $product_ids)
									->get();
				//dd($paid_user_emails);
				if($paid_user_emails){

					foreach ($paid_user_emails as $mail) {
						$paid_users_email[] = $mail->user_email;
					}

					$interview_cleared_user_appids = DB::table('users')
						            ->join('hdfc_applications', 'users.id', '=', 'hdfc_applications.user_id')
						            ->select('hdfc_applications.id') 
						    		->whereIn('users.email', $paid_users_email)
						    		->get(); 

					//dd($interview_cleared_user_appids);

					foreach ($interview_cleared_user_appids as $app) {
						$application_status_details = array('application_id' => $app->id,
															'status' => 31,	// First installment paid
															'test_date' => '',
															'created_at' => new DateTime,
															'updated_at' => new DateTime ,
															'mail_sent' => ''
														);
						$application_status = HdfcTrackApplication::create($application_status_details);
					}

				}
				return Redirect::to('hdfc')->with('success', 'Payment status updated successfully.');
			}
		}
		//else {
			return Redirect::to('hdfc')->with('warning', 'No users found matching the criteria.');
		//}

	}


}

