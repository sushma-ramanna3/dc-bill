<?php

class UsersController extends BaseController {


	public function __construct()
	{
		$this->beforeFilter('admin',array('except' => array('cvDownload')));
	}


	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//$users  = User::all();
		
		$midArr = TrackApplicationStatus::getLatestStatus();
		
		$users = DB::table('users')	
	            ->join('applications', 'users.id', '=', 'applications.user_id')
	            ->join('track_application_status', 'applications.id', '=', 'track_application_status.application_id')
	            ->join('jobs', 'applications.job_id', '=', 'jobs.id')
	            ->join('application_status', 'track_application_status.status', '=', 'application_status.id')
	            ->select('users.id', 'users.first_name', 'users.last_name', 'users.email', 'users.phone', 'track_application_status.updated_at', 
	    			'applications.id as application_id', 'applications.cv_path',  'jobs.job_cat_id', 'jobs.category', 'application_status.status')
	    		->whereIn('track_application_status.id', $midArr)
	    		->where('users.usertype', '!=' , 'admin');

	   	$users_applied = $this->countUsers(clone($users), 1);
	    $users_eligible = $this->countUsers(clone($users), 4);
	    $users_confirmed = $this->countUsers(clone($users), 6);
	    $users_attending_interview = $this->countUsers(clone($users), 7);
	    $users_cleared = $this->countUsers(clone($users), 8);

    	if (Input::has('reference_id'))
        {
          	$users->where('applications.reference_id',  Input::get('reference_id'));
        }
		if (Input::has('job_cat_id'))
        {
          	$users->where('jobs.job_cat_id', Input::get('job_cat_id'));
        }
        if (Input::has('status'))
        {
          	$users->where('application_status.id', Input::get('status'));
        }
        if (Input::has('email'))
        {
          	$users->where('users.email', Input::get('email') );
        }	
        if (Input::has('application_id'))
        {
          	$users->where('applications.id', Input::get('application_id'));
        }

    	$users = $users->orderBy('users.id', 'asc')->paginate(10);

    	$pagination = $users->appends(
	        array(
	            'reference_id'       => Input::get('reference_id'),
	            'job_cat_id' => Input::get('job_cat_id'),
	            'status'  => Input::get('status'),
	            'application_id'  => Input::get('application_id'),
	            'users.email' =>  Input::get('email')
	        ))->links();

		$application_status = array('' => 'Please Select Status') + ApplicationStatus::lists('status', 'id');

		$job_ids = array('' => 'Please Select Job ID') + Job::lists('job_cat_id', 'job_cat_id');

		$usertype = array('' => 'Please Select User Type') + User::lists('usertype', 'usertype');
		
		$users  = array('job_ids' => $job_ids, 'pagination' => $pagination, 'application_status' => $application_status, 'users' => $users, 'usertype' => $usertype,
				'users_applied' => $users_applied, 'users_eligible' => $users_eligible, 'users_confirmed' => $users_confirmed, 'users_attending_interview' => $users_attending_interview, 'users_cleared' => $users_cleared);

        return View::make('users.index')->with('users', $users);
	}


	/***
		HDFC jobs model 
		listing of users
	*/

	public function hdfcUsers()
	{
		//$users  = User::all();
		
		$midArr = HdfcTrackApplication::getLatestStatus();
		
		$users = DB::table('users')
	            ->join('hdfc_applications', 'users.id', '=', 'hdfc_applications.user_id')
	            ->join('hdfc_track_application', 'hdfc_applications.id', '=', 'hdfc_track_application.application_id')
	            ->join('jobs', 'hdfc_applications.job_id', '=', 'jobs.id')
	            ->join('application_status', 'hdfc_track_application.status', '=', 'application_status.id')
	            ->select('users.id', 'users.first_name', 'users.last_name', 
	            		 'users.email', 'users.phone', 'users.dob',  
	            		 'users.age', 'hdfc_track_application.updated_at', 'hdfc_track_application.id as track_id',
	            		 'hdfc_applications.reference_id',
	            		 'hdfc_applications.sslc_percentage','hdfc_applications.sslc_year',
	            		 'hdfc_applications.puc_percentage','hdfc_applications.puc_year',
	            		 'hdfc_applications.graduation','hdfc_applications.graduation_percentage','hdfc_applications.graduation_year',
	            		 'hdfc_applications.post_graduation','hdfc_applications.post_graduation_percentage','hdfc_applications.post_graduation_year', 
	            		 'hdfc_applications.post_graduation_college', 'hdfc_applications.other_college',
						 'hdfc_applications.preferred_interview_location','hdfc_applications.work_experience', 'hdfc_applications.relocation_specific',
	            		 'hdfc_applications.home_location','hdfc_applications.current_location', 'hdfc_applications.preferred_job_location_1', 'hdfc_applications.preferred_job_location_2', 'hdfc_applications.preferred_job_location_3',
	    				 'hdfc_applications.id as application_id', 'hdfc_applications.cv_path', 'hdfc_applications.relocate',
	    				 'hdfc_applications.ca_attempts','hdfc_applications.attended','hdfc_applications.result_status',
	    				 'jobs.job_cat_id', 'jobs.category', 'application_status.status', 'jobs.id as job_id')
	    		->whereIn('hdfc_track_application.id', $midArr)
	    		->where('users.usertype', '!=' , 'admin');

	    $users_eligible = $this->countUsers(clone($users), 20);
	    $users_ineligible = $this->countUsers(clone($users), 21);
	    $users_qf = $this->countUsers(clone($users), 22);
	    $users_paid = $this->countUsers(clone($users), 24);
	    $users_test_cleared = $this->countUsers(clone($users), 25);
	    $users_test_failed = $this->countUsers(clone($users), 26);

    	if (Input::has('reference_id'))
        {
          	$users->where('hdfc_applications.reference_id',  Input::get('reference_id'));
        }
		if (Input::has('job_cat_id'))
        {
          	$users->where('jobs.job_cat_id', Input::get('job_cat_id'));
        }
        if (Input::has('status'))
        {
          	$users->where('application_status.id', Input::get('status'));
        }
        if (Input::has('email'))
        {
          	$users->where('users.email', Input::get('email') );
        }	
        if (Input::has('application_id'))
        {
          	$users->where('hdfc_applications.id', Input::get('application_id'));
        }
        if (Input::has('usertype'))
        {
          	$users->where('users.usertype', Input::get('usertype'));
        }

        if (Input::get('submit') == 'download')
        {
        	$users = $users->orderBy('users.id', 'asc')->get();
          	$this->generateReport($users);
        }

        if(Input::get('sendmail')){
    		$users = $users->where('hdfc_track_application.mail_sent', '!=' , 1)->get();
    		$pagination = '';
    		$track_url = url('http://jobs.learnwithflip.com/track');

    		// the data that will be passed into the mail view blade template
			if(Input::get('status') == 20)
				$subject = 'Job Application – Registration Process for HDFC Bank Job';
			else if(Input::get('status') == 22)
				$subject = 'Job Application for HDFC Bank Job – Registration Fee Payment';
			else if(Input::get('status') == 24)
				$subject = 'Payment Confirmation - Relationship Manager Program with HDFC Bank';
			else if(Input::get('status') == 25 || Input::get('status') == 26)
				$subject = 'Online Test | Relationship Manager Program';

			if($users){
	    		foreach ($users as $user) {
	    			$email = $user->email;
	    			$reference_id = 'HDFC'.strtoupper(substr(md5($user->application_id), 0, 8));

	    			if($user->job_id == 4){ 
	    				$job_title = 'Trade Sales Manager';
	    				$prep_link = 'http://www.learnwithflip.com/FLIP/Prep-pack-Trade-Sales-Manager.zip';
	    			}
		            elseif($user->job_id == 5){ 
		            	$job_title = 'Branch Relationship Manager';
		            	$prep_link = 'http://www.learnwithflip.com/FLIP/Prep-pack-Branch-Relationship-Manager.zip';
		        	}
		            elseif($user->job_id == 6){ 
		            	$job_title = 'Relationship Manager - Business Banking';
		            	$prep_link = 'http://www.learnwithflip.com/FLIP/Prep-pack-RM-Business-Banking.zip';
		            }
		            elseif($user->job_id == 7){ 
		            	$job_title = 'Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG)';
		            	$prep_link = 'http://www.learnwithflip.com/FLIP/Prep-pack-RM-Emerging-Enterprise-Group.zip';
		            }
					$data = array(
							'status'=> Input::get('status'),
							'name'  => $user->first_name,
							'reference_id' => $reference_id,
							'job_title' => $job_title,
							'track_url' => $track_url,
							'subject' => $subject,
							'prep_link' => $prep_link
					);
				
					Mail::send('emails.hdfcmail', $data, function ($message) use ($email, $subject) {
						$message->from('ratnesh@learnwithflip.com', 'Ratnesh');
						$message->subject($subject);
						$message->to($email); // Recipient address
					});
					
					DB::statement("UPDATE hdfc_track_application SET mail_sent = 1 where id = $user->track_id");
				}
				return Redirect::to('hdfc')->with('success', 'Mail has been sent successfully.');
			}
			else return Redirect::to('users')->with('warning', 'No users found matching the criteria / mail have already sent.');

        }
        else{
			$users = $users->orderBy('users.id', 'asc')->paginate(10);


	    	$pagination = $users->appends(
		        array(
		            'reference_id'       => Input::get('reference_id'),
		            'job_cat_id' => Input::get('job_cat_id'),
		            'status'  => Input::get('status'),
		            'application_id'  => Input::get('application_id'),
		            'users.email' =>  Input::get('email'),
		            'users.usertype' =>  Input::get('usertype')
		        ))->links();
		}
		$application_status = array('' => 'Please Select Status') + ApplicationStatus::lists('status', 'id');

		$job_ids = array('' => 'Please Select Job ID') + Job::lists('job_cat_id', 'job_cat_id');

		$usertype = array('' => 'Please Select User Type') + User::lists('usertype', 'usertype');
		
		$users  = array('job_ids' => $job_ids, 'pagination' => $pagination, 'application_status' => $application_status, 'users' => $users, 'usertype' => $usertype,
			'users_ineligible' => $users_ineligible, 'users_eligible' => $users_eligible, 'users_qf' => $users_qf, 'users_paid' => $users_paid,
			'users_test_cleared' => $users_test_cleared, 'users_test_failed' => $users_test_failed);

        return View::make('users.hdfc')->with('users', $users);
	}


	/*
		*getting of users based on different status
	*/
	public function countUsers($users, $status){
		$users_count = $users->where('application_status.id', $status)->count();
		return $users_count;
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
        return View::make('users.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
        return View::make('users.show');
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
        return View::make('users.edit');
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function generateReport($users)
	{
		$csv_output = '';
		$answers = '';
		$report_heading = ", Users";
		$report_file = "Users_Details";
		$csv_output .= '';
		$csv_output .= $report_heading.' '.date('d-F-Y h:i A');
		$csv_output .= "\n";
		$csv_output .= "Serial No, User Id, Application Id, Reference Id, First Name, Last Name, Email, Phone, DOB(d-m-Y), Age, Job Id, Job Category, SSLC Percentage, SSLC Passed Year, PUC Percentage, PUC Passed Year, Graduation, Graduation Percentage, Graduation Passed Year, Post Graduation Percentage, Post Graduation Passed Year, Post Graduation,  Post Graduation College, Result Status, Preferred Interview Location, Work Experience, CA Attempts, Attended Interview in last 3 months?, Status, Willing to relocate?, Preferred relocation, NISM certification, Pan Card, CV Path, Home Location, Current Location, Preferred Job Location_1, Preferred Job Location_2, Preferred Job Location_3\n";
		$arr = array();
		$work_area = $work_ex = '';
		$j = 0;
		foreach ($users as $row) {
			$j++;
			$id =  $row->id;
			$first_name  =  $row->first_name;
			$last_name = $row->last_name;
			$email = $row->email;
			$phone = $row->phone;
			$dob = $row->dob;
			$age = $row->age;
			$reference_id = $row->reference_id;
			$application_id = $row->application_id;
			$job_id = $row->job_cat_id;
			$job_category = $row->category;
			$sslc_percentage = $row->sslc_percentage;
			$sslc_passed_year = $row->sslc_year;
			$puc_percentage = $row->puc_percentage;
			$puc_passed_year = $row->puc_year;
			$graduation = $row->graduation;
			$graduation_percentage = $row->graduation_percentage;
			$graduation_passed_year = $row->graduation_year;
			$post_graduation = '"'.$row->post_graduation.'"';
			$post_graduation_percentage = $row->post_graduation_percentage;
			$post_graduation_passed_year = $row->post_graduation_year;
			$post_graduation_passed_college = trim($row->post_graduation_college);
			if ($post_graduation_passed_college && $post_graduation_passed_college != 999 && is_numeric($post_graduation_passed_college)) 
			{
				if($post_graduation_passed_college >= 568) $post_graduation_passed_college++; //fix due to rogue record at 568 in database
				$post_graduation_college = DB::table('college_list_sorted')->where('id', $post_graduation_passed_college)->pluck('college_name');
				$post_graduation_passed_college = str_replace(',', '-', $post_graduation_college);
				//$post_graduation_passed_college = $post_graduation_college[0];
			} 
			else{
				//$post_graduation_passed_college = trim($row->other_college);
				$post_graduation_passed_college = str_replace(',', '-', trim($row->other_college));
			}
			$result_status = $row->result_status;
			$preferred_interview_location = DB::table('hdfc_interview_locations')->where('id','=', $row->preferred_interview_location)->pluck('location');
			$ca_attempts = $row->ca_attempts;
			$relocate = $row->relocate;
			$relocation_specific= $row->relocation_specific;
			$attended = ($row->attended == 0 ) ? 'No' : 'Yes';
			$work_experience = $row->work_experience;
			$home_location = '"'.$row->home_location.'"';
			$current_location = '"'.$row->current_location.'"';
			$preferred_job_location_1 = '"'.$row->preferred_job_location_1.'"';
			$preferred_job_location_2 = '"'.$row->preferred_job_location_2.'"';
			$preferred_job_location_3 = '"'.$row->preferred_job_location_3.'"';
			$status = $row->status;
			$status = explode(',', $status);
			$status = $status[sizeof($status)-1];
			$answers = DB::table('hdfc_questionnarie')->where('application_id','=', $row->application_id)->pluck('answers');
			if($answers) $answers = explode(',',$answers);
			$answers[0] = isset($answers[0]) ? $answers[0] : '';
			$answers[1] = isset($answers[1]) ? $answers[1] : '';
			$cv_path = 'http://jobs.learnwithflip.com/cvdownload/HDFC_'.$application_id;

			$csv_output_row1 = "$j, $id, $application_id, $reference_id, $first_name, $last_name,$email, $phone, $dob, $age, $job_id, $job_category,$sslc_percentage, $sslc_passed_year, $puc_percentage, $puc_passed_year, $graduation, $graduation_percentage, $graduation_passed_year, $post_graduation_percentage, $post_graduation_passed_year, $post_graduation, $post_graduation_passed_college, $result_status, $preferred_interview_location, $work_experience, $ca_attempts, $attended,$status,$relocate,$relocation_specific,$answers[0],$answers[1],$cv_path,$home_location,$current_location,$preferred_job_location_1,$preferred_job_location_2,$preferred_job_location_3\n";
								
			$csv_output .=$csv_output_row1;
		}
		$file = $report_file.date('d-m-Y h:i A').'.csv';
		header('Content-type: text/csv');
		header("Content-Disposition: attachment; filename=".$file."");
		echo $csv_output;
		exit;
	}

	public function cvDownload($application_id)
	{
		if(substr($application_id, 0, 4) == 'HDFC'){
			$application_id = explode('_', $application_id);
			$application_id = $application_id[1];
			$file = DB::table('hdfc_applications')->where('id', '=', $application_id)->pluck('cv_path');
		}else{
			$file = DB::table('applications')->where('id', '=', $application_id)->pluck('cv_path');
		}
		return Response::download($file);
	}

}
