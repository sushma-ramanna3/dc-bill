<?php

use Carbon\Carbon;

class ApplicationsController extends BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
        return View::make('applications.index');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
        return View::make('applications.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		

		$rules = array(
		        'first_name' => 'Required|Min:3|Max:80|Alpha',
		        'last_name' => 'Required|Min:2|Max:80|Alpha',
		        'phone' => 'Required|numeric|Min:10|unique:users',
		        'email'     => 'Required|Between:3,64|Email|unique:users',
		        'resume'	=> 'Required',
		        'preferred_job_location' => 'Required',
		        'graduation_percentage' => 'Required',
		        'graduation_year' => 'Required'
		        //'resume'	=> 'mimes:pdf,doc,docx,rtf'
		);
		$messages = array(
		    'email.unique' => 'You have already applied to this job with the same email ID. Please check your mail box for earlier job application details.',
		    'last_name.Alpha' => 'The last name may only contain one word and only letters. ',
		    'phone.unique' => 'You have already applied to this job with the same phone number. Please check your mail box for earlier job application details.',

		);

		$validator = Validator::make(Input::all(), $rules, $messages);
		$data = Input::all();

		if ($validator->passes()) {
			$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');

			if(!isset($userid)){
				//date in mm/dd/yyyy format; or it can be in other formats as well
				//explode the date to get month, day and year
				$birthdate = Input::get('dob_month').'-'.Input::get('dob_day').'-'.Input::get('dob_year');
				$birthDate = explode("-", $birthdate);
				//get age from date or birthdate
				 $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
				    ? ((date("Y") - $birthDate[2]) - 1)
				    : (date("Y") - $birthDate[2]));

				$user_details = array('first_name' => Input::get('first_name'), 
					'last_name' => Input::get('last_name'),
					'email' => Input::get('email'),
					'password' => '',
					'usertype' => 'Registered',
					'phone' => Input::get('phone'),
					'dob' => Input::get('dob_year').'-'.Input::get('dob_month').'-'.Input::get('dob_day'),
					'age' => $age,
					'created_at' => new DateTime,
					'updated_at' => new DateTime
					);
					DB::table('users')->insert($user_details);
				$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');
			}
			
			$userid = isset($user->id) ? $user->id : $userid ;

			if (Input::hasFile('resume'))
			{
			    Input::file('resume')->move( app_path().'/views/resumes/', $userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName());
				$cv_path = app_path().'/views/resumes/'.$userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName();
			}
			$cv_path = isset($cv_path) ? $cv_path : '' ;
			$application_details = array('job_id' => Input::get('job_id'),
									 'user_id' => $userid,
									 'sslc_percentage' => round(rtrim(Input::get('sslc_percentage'),'%')),
									 'sslc_year' => Input::get('sslc_year'),
									 'puc_percentage' => round(rtrim(Input::get('puc_percentage'),'%')),
									 'puc_year' => Input::get('puc_year'),
									 'graduation_percentage' => round(rtrim(Input::get('graduation_percentage'),'%')),
									 'graduation_year' => Input::get('graduation_year'),
									 'graduation' => Input::get('graduation_stream'),
									 'post_graduation_percentage' => round(rtrim(Input::get('post_graduation_percentage'),'%')),
									 'post_graduation_year' => Input::get('post_graduation_year'),
									 'post_graduation' => Input::get('post_graduation_stream'),
									 // 'preferred_interview_location' => Input::get('preferred_interview_location'),
									 'preferred_job_location' => Input::get('preferred_job_location'),
									 'cv_path' => $cv_path
									  );

			$application = Application::create($application_details);

			$application->reference_id = strtoupper(substr(md5($application->id), 0, 8));
			$application->save();

			$application_status_details = array('application_id' => $application->id,
											'status' => '1',	// status 1 for applied but not payed yet
											'created_at' => new DateTime,
											'updated_at' => new DateTime 
										);
			$application_status = TrackApplicationStatus::create($application_status_details);

			//store work ex details
			$input = Input::all();
			$workdetails = array_combine($input['workarea'], $input['workex']);
			foreach ($workdetails as $key => $value) {
				$work_array = array('user_id' => $userid,
								'application_id' => $application->id,
								'work_area' => trim($key),
								'work_ex' => trim($value),
								'updated_at' => new DateTime,
								'created_at' => new DateTime

					);
				WorkExperience::create($work_array);
			}

			// This takes the user to the payment gateway
			// $url = $this->charge_user($data, $userid);
			// return Redirect::to($url);
			// dd($application);

			// send a notification to the customer
			
			$data = array('name'=>Input::get('first_name'),'status'=>'Applied', 'category'=>'HDFC Bank', 'job_title'=>'Branch Sales Officer Program','reference_id'=>strtoupper(substr(md5($application->id), 0, 8)), 'track_url'=>'http://jobs.learnwithflip.com/track');

			Mail::send('emails.email', $data, function($message) use ($application)
			{
			    $message->to(Input::get('email'), Input::get('first_name').' '.Input::get('last_name'))->subject('Job Application - Branch Sales Officer Program with HDFC Bank');
			});


			
			return View::make('applications.thankyou')->with('flash_message','Your application has saved successfully');
			//return Redirect::to('/applications/1')->with('successful', true );
		}

		return Redirect::to('/applications/1')
			->withInput()
			->withErrors($validator);
	}

	/*IIFL job model*/

	public function iifl()
	{

		$rules = array(
		        'first_name' => 'Required|Min:3|Max:80|Alpha',
		        'last_name' => 'Required|Min:2|Max:80|Alpha',
		        'phone' => 'Required|numeric|Min:10',
		        'email'     => 'Required|Between:3,64|Email|unique:users',
		        'resume'	=> 'Required',
		        'preferred_job_location' => 'Required',
		        'highest_qualification_stream' => 'Required'		        
		);
		$messages = array(
		    'email.unique' => 'You have already applied to this job with the same email ID. Please check your mail box for earlier job application details.',
		    'last_name.Alpha' => 'The last name may only contain one word and only letters. '
		);

		$validator = Validator::make(Input::all(), $rules, $messages);
		$data = Input::all();

		if ($validator->passes()) {
			$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');

			if(!isset($userid)){
					$user_details = array('first_name' => Input::get('first_name'), 
					'last_name' => Input::get('last_name'),
					'email' => Input::get('email'),
					'password' => '',
					'usertype' => 'Registered',
					'phone' => Input::get('phone'),
					//'dob' => Input::get('dob_year').'-'.Input::get('dob_month').'-'.Input::get('dob_day'),
					//'age' => $age,
					'created_at' => new DateTime,
					'updated_at' => new DateTime
					);
					DB::table('users')->insert($user_details);
				$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');
			}
			
			$userid = isset($user->id) ? $user->id : $userid ;

			if (Input::hasFile('resume'))
			{
			    Input::file('resume')->move( app_path().'/views/resumes/', $userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName());
				$cv_path = app_path().'/views/resumes/'.$userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName();
			}
			$cv_path = isset($cv_path) ? $cv_path : '' ;
			$application_details = array('job_id' => Input::get('job_id'),
									 'user_id' => $userid,
									 'preferred_job_location' => Input::get('preferred_job_location'),
									 'highest_qualification' => Input::get('highest_qualification_stream'),
									 'WM_certified' => Input::get('WM_certified'),
									 'cv_path' => $cv_path
									  );

			$application = Application::create($application_details);

			$application->reference_id = strtoupper(substr(md5($application->id), 0, 8));
			$application->save();

			$application_status_details = array('application_id' => $application->id,
											'status' => '1',	// status 1 for applied but not payed yet
											'created_at' => new DateTime,
											'updated_at' => new DateTime 
										);
			$application_status = TrackApplicationStatus::create($application_status_details);

			//store work ex details
			$input = Input::all();
			$workdetails = array_combine($input['workarea'], $input['workex']);
			foreach ($workdetails as $key => $value) {
				$work_array = array('user_id' => $userid,
								'application_id' => $application->id,
								'work_area' => trim($key),
								'work_ex' => trim($value),
								'updated_at' => new DateTime,
								'created_at' => new DateTime

					);
				WorkExperience::create($work_array);
			}

			// This takes the user to the payment gateway
			// $url = $this->charge_user($data, $userid);
			// return Redirect::to($url);
			// dd($application);

			// send a notification to the customer
			
			/*$data = array('name'=>Input::get('first_name'),'status'=>'Applied', 'category'=>'India Infoline', 'job_title'=>'Job Opening : Market Analyst (Non-Sales Role)','reference_id'=>strtoupper(substr(md5($application->id), 0, 8)), 'track_url'=>'http://jobs.learnwithflip.com/track');

			Mail::send('emails.email', $data, function($message) use ($application)
			{
			    $message->to(Input::get('email'), Input::get('first_name').' '.Input::get('last_name'))->subject('Job Application - Job Opening : Market Analyst (Non-Sales Role) with India Infoline');
			});*/
			
			return View::make('applications.thankyou_iifl')->with('flash_message','Your application has saved successfully');
		}

		return Redirect::back()
			->withInput()
			->withErrors($validator);
	}


	/**
	* UPLOAD USERS THROUGH CSV 
	*/
	public function uploadUsers()
	{
		$rules = array(
		        'uploadusers'	=> 'Required'
		);
		
		$validator = Validator::make(Input::all(), $rules);
		if ($validator->fails()) {
			return Redirect::to('users')
				->withErrors($validator)
				->withInput();
		} 
		else{
			$ext = Input::file('uploadusers')->getClientOriginalExtension();
			if($ext != 'csv')
	    	{
	    		return Redirect::to('users')->with('error', 'Please upload a csv file.');
    		} 
    		else
    		{
			 	$file = Input::file('uploadusers');
		    	$handle = fopen($file,"r");
				$data[] = array();
				$duplicate_email =array();
		    	//loop through the csv file and insert into database
		    	do {
		    		if ($data[0]) {
						$userid = DB::table('users')->where('email','=', trim($data[3]))->pluck('id');

						if(!isset($userid)){
							//date in mm/dd/yyyy format; or it can be in other formats as well
							//explode the date to get month, day and year
							$birthDate = explode("/", trim($data[5]));
							//get age from date or birthdate
							 $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
							    ? ((date("Y") - $birthDate[2]) - 1)
							    : (date("Y") - $birthDate[2]));

							$mm = $birthDate[0];
							$dd = $birthDate[1];
							$yyyy = $birthDate[2];

							$dob1 = $yyyy.'-'.$mm.'-'.$dd;

							$user_details = array('first_name' => trim($data[1]), 
								'last_name' => trim($data[2]),
								'email' => trim($data[3]),
								'password' => '',
								'usertype' => trim($data[0]),
								'phone' => trim($data[4]),
								'dob' => $dob1,
								'age' =>  $age,
								'created_at' => new DateTime,
								'updated_at' => new DateTime
								);
								DB::table('users')->insert($user_details);

							$userid = DB::table('users')->where('email','=', trim($data[3]))->pluck('id');

							$userid = isset($user->id) ? $user->id : $userid ;

							$cv_path = isset($cv_path) ? $cv_path : '' ;

							$application_details = array('job_id' => $data[6],
											 'user_id' => $userid,
											 'sslc_percentage' => round(rtrim($data[7],'%')),
											 'sslc_year' => $data[8],
											 'puc_percentage' => round(rtrim($data[9],'%')),
											 'puc_year' => $data[10],
											 'graduation_percentage' => round(rtrim($data[11],'%')),
											 'graduation_year' => $data[12],
											 'graduation' => $data[13],
											 'post_graduation_percentage' => round(rtrim($data[14],'%')),
											 'post_graduation_year' => $data[15],
											 'post_graduation' => $data[16],
											 // 'preferred_interview_location' => $data[],
											 'preferred_job_location' =>trim($data[17]),
											 'cv_path' => $cv_path
											  );

							$application = Application::create($application_details);

							$application->reference_id = strtoupper(substr(md5($application->id), 0, 8));
							$application->save();

							$application_status_details = array('application_id' => $application->id,
															'status' => '1',	// status 1 for applied but not payed yet
															'created_at' => new DateTime,
															'updated_at' => new DateTime 
														);
							$application_status = TrackApplicationStatus::create($application_status_details);

							//store work ex details
							$data[18] = explode('|', $data[18]);
							$data[19] = explode('-', $data[19]);
							$workdetails = array_combine($data[18], $data[19]);
							foreach ($workdetails as $key => $value) {
								$work_array = array('user_id' => $userid,
												'application_id' => $application->id,
												'work_area' => trim($key),
												'work_ex' => trim($value),
												'updated_at' => new DateTime,
												'created_at' => new DateTime

									);
								WorkExperience::create($work_array);
							}

							// send a notification to the customer
							
							$data1 = array('name'=>$data[1],'status'=>'Applied', 'category'=>'HDFC Bank', 'job_title'=>'Branch Sales Officer Program','reference_id'=>strtoupper(substr(md5($application->id), 0, 8)), 'track_url'=>'http://jobs.learnwithflip.com/track');
							Mail::send('emails.email', $data1, function($message) use ($data)
							{
							    $message->to($data[3], $data[1].' '.$data[2])->subject('Job Application - Branch Sales Officer Program with HDFC Bank');
							});
						}
						else{
							$duplicate_email[] = array('email' =>  $data[3]);
						}
						
					}
		    	} while ($data = fgetcsv($handle,0,",","'"));
			    fclose($handle);

			    if($duplicate_email){
	    			$this->duplicates($duplicate_email);
	    			return Redirect::to('users')->with('warning', ' Failed to create some duplicate accounts.<br>' );
    			}
    			else return Redirect::to('users')->with('success', 'Users created successfully.');
			}	
		}

	}


	function duplicates($result)
    {

    	$report_heading = " List of duplicate entries";
    	$report_file = "Duplicate entries";
    	$csv_output = '';
    	$csv_output = $report_heading.' '.date('d-F-Y');
    	$csv_output .= "\n";
    	$csv_output .= "Email Id\n";
    	
    	$file = fopen('/tmp/'.'_duplicates_file.csv', 'w');
    	foreach($result as $order)
    	{
    		$csv_output_row = $order["email"]."\n";
    		$csv_output .=$csv_output_row;
    	}
    
		$filename=$report_file.date('d-m-Y').'.csv';
    
    	$fp =fopen($filename,"w");
    	fwrite($fp,$csv_output);
    	header("Pragma: public");
    	header("Expires: 0");
    	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    	header("Cache-Control: private",false);
    	header("Content-Type: application/ms-excel");
    	header("Content-Disposition: attachment; filename=".$filename.";" );
    	//header("Content-Transfer-Encoding: binary");
    	header("Content-Length: ".filesize($filename));
    	readfile("$filename");
    	@unlink($filename);
    	exit;
    	
    }
    /****
	* hdfc jobs model 
    **/

	public function showHdfc($id='')
	{
		if($id) return View::make('applications.show4');
		else return View::make('applications.closed');
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id='')
	{
		$id = ($id) ? $id : 1 ;

		$ids = array(0, $id); 

		if($id == 4 || $id == 5 || $id == 6 || $id == 7){
			$preferred_job_location = array('' => 'Please Select Location') + DB::table('hdfc_interview_locations')
			->where('job_id', 'LIKE', "%$id%")->orderBy('location', 'ASC')->lists('location', 'id');
		}
		else{
			$preferred_job_location = array('' => 'Please Select Location') + DB::table('location_details')->where('flag', '!=', 'J')
									->whereIn('job_id', $ids)->orderBy('location', 'ASC')->lists('location', 'id');
		}
		
		$location  = array('preferred_job_location' => $preferred_job_location, 'id' => $id);

		$college_details =  DB::table('college_list')->orderBy('college_name', 'ASC')->lists('city','college_name');
		$college_list[] = 'Please Select College';
		foreach ($college_details as $key => $value) {
			$college_list[] = "$key, $value";
		}
		unset($college_list[478]);
		$college_list[999] = "Others";

		if($id == 1)
			return View::make('applications.show')->with('location',$location);
		elseif ($id == 2) 
			return View::make('applications.show1')->with('location',$location);
		elseif ($id == 3)
			return View::make('applications.show2')->with('location',$location);
		elseif ($id == 4 || $id == 5 || $id == 6 || $id == 7)
			return View::make('applications.closed');

			// return View::make('applications.show4')->with('college_list', $college_list)->with('location',$location);
       
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
        return View::make('applications.edit');
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}

	/**
	 * marks the users as eligible or not eligible
	 */
	public function runEligibility()
	{

		// TODO: fetch records based on job_cat_id
		$applications = Application::with('WorkExperience', 'applicationStatus', 'user')->take(1000)->skip(6000)->get(); 
		
		//temporary fix
		$job_id = trim(Input::get('job_cat_id'));

		if ( $job_id === "ANANDWMFEB14" ) $job_id = 2;
		elseif ( $job_id === "HDFCBSOPFEB14" ) $job_id = 1;
		//end temporary fix

		foreach ($applications as $key => $application) {

			if($this->isApplicationStatusApplied($application)){
			
				if($this->isEligible($application, Input::all())){

						$this->setApplicationStatus($application->id, 4, $job_id); // 4 for Eligible
						
				}else{
						$this->setApplicationStatus($application->id, 5, $job_id); // 5 for Eligible
				}
			}
		}
		return Redirect::to('users')->with('success', 'Status updated successfully.');
	}

	private function setApplicationStatus($application_id, $status, $job_id)
	{
		//temporary fix
		$app_id = DB::table('applications')
					->where('id', '=', $application_id)
					->where('job_id', '=', $job_id)
					->pluck('id');
		//end
					
		if($app_id){
			TrackApplicationStatus::Create( array(
								'application_id' => $app_id,
								'status' => $status,
								'created_at' => Carbon::now(),
								'updated_at' => Carbon::now()
								));
		}
	}

	private function isApplicationStatusApplied($application){

		$application_status = DB::table('track_application_status')->where('application_id', $application->id)->orderBy('id', 'desc')->first();
		
		if(!is_object($application_status)) return false;
		if ($application_status->status == 1) return true;

		return false;

	}

	private function isEligible($application, $conditions)
	{

		foreach ($conditions as $key => $value) {
			$conditions[$key] = ($value=='') ? 0 : $value;
		}

		// TODO : currently the need is all work ex should be less than specified experience
		$total_work_exp = 0;
		foreach ($application->work_experience as $key => $work_experience) {
			$total_work_exp += $work_experience['work_ex'];
		}
		

		if ( ($conditions['sslc_percentage'] <= $application->sslc_percentage) &&
			 ($conditions['puc_percentage'] <= $application->puc_percentage) &&
			 ($conditions['graduation_percentage'] <= $application->graduation_percentage) &&
			 ($conditions['post_graduation_percentage'] <= $application->post_graduation_percentage) &&
			 ($conditions['agefrom'] <= $application->user->age) &&
			 ($conditions['ageto'] >= $application->user->age) &&
			 ($conditions['graduation_year'] >= $application->graduation_year) &&
			 ($conditions['work_ex'] >= $total_work_exp)
			){
			return true;
		}
		return false;
	}

	

	public function interviewDetails() 
    {
    	$rules = array(
			'interviewdata'  => 'required' //|mimes:csv
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the creation
		if ($validator->fails()) {
			return Redirect::to('users')
				->withErrors($validator)
				->withInput();
		} 
		else 
		{
			$ext = Input::file('interviewdata')->getClientOriginalExtension();
			if($ext != 'csv')
	    	{
	    		return Redirect::to('users')->with('error', 'Please upload a csv file.');
    		} 
    		else
    		{
	            $file = Input::file('interviewdata');
		    	
	            ini_set('auto_detect_line_endings',TRUE);
	            $delimiter=',';
				$header = NULL;
				$data = array();
				if (($handle = fopen($file, 'r')) !== FALSE)
				{
					while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE)
					{
						if(!$header)
							$header = $row;
						else
							$data[] = array_combine($header, $row);

						if ($row[0]) {
		    				$application = DB::table('applications')
			    							->where('id', '=', trim($row[0]))
			    							->pluck('id');

			    			$app_id = DB::table('interview_details')
			    							->where('application_id', '=', trim($row[0]))
			    							->pluck('application_id');
			    							
			    			if(!$app_id && $application){
								//echo '<br>'.$row[0].'<br>'.$row[1].'<br>'.$row[2];
								DB::table('interview_details')->insert(
								    array('application_id' => trim($row[0]), 'interview_date' => trim($row[1]), 'interview_time' => trim($row[2]), 'interview_location_details' => trim($row[3]), 'created_at' => new DateTime, 'updated_at' => new DateTime )
								);
							}
						}
					}
					fclose($handle);
				}

			    return Redirect::to('users')->with('success', 'Data inserted successfully.');
			}
	    	
    	}
	}
	

	public function applicationStatus() 
    {
    	$rules = array(
			'updatestatus'  => 'required' //|mimes:csv
		);
		$validator = Validator::make(Input::all(), $rules);
		// process the creation
		if ($validator->fails()) {
			return Redirect::to('users')
				->withErrors($validator)
				->withInput();
		} 
		else 
		{
			$ext = Input::file('updatestatus')->getClientOriginalExtension();
			if($ext != 'csv')
	    	{
	    		return Redirect::to('users')->with('error', 'Please upload a csv file.');
    		} 
    		else
    		{
	            $file = Input::file('updatestatus');
		    	$handle = fopen($file,"r");
				$data[] = array();
				if(Input::get('hdfc_jobs')){
					$table = 'hdfc_applications';
					$table2 = 'hdfc_track_application';
				} 
				else{
					$table = 'applications';
					$table2 = 'track_application_status';	
				} 
		    	//loop through the csv file and insert into database
		    	do {
		    		if ($data[0]) {
		    			$application = DB::table($table)
		    							->where('id', '=', trim($data[0]))
		    							->pluck('id');
		    			if($application ){
			    			DB::table($table2)->insert(
							    array('application_id' => $data[0], 'status' => $data[1], 'created_at' => new DateTime, 'updated_at' => new DateTime )
							);
			    		}
		    		}
		    	} while ($data = fgetcsv($handle,0,",","'"));
			    fclose($handle);
			  
			  	if(Input::get('hdfc_jobs')) return Redirect::to('hdfc')->with('success', 'Status updated successfully.');
			  	else return Redirect::to('users')->with('success', 'Status updated successfully.');
			}
    	}
	}

	public function downloadORsendmail()
	{


		$rules = array(
				'job_cat_id'  => 'required'
				//'status'  	  => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the creation
		if ($validator->fails()) {
			return Redirect::to('users')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$current_status = $cstatus = '';
			$midArr = TrackApplicationStatus::getLatestStatus();

			$users = DB::table('users')
			->join('applications', 'users.id', '=', 'applications.user_id')
			->join('track_application_status', 'applications.id', '=', 'track_application_status.application_id')
			->join('jobs', 'applications.job_id', '=', 'jobs.id')
			->join('application_status', 'track_application_status.status', '=', 'application_status.id');

			//for sending mails to users
			if (Input::has('sendmail') && Input::has('status'))
			{
				$current_status = DB::table('application_status')->where('id','=', Input::get('status'))->pluck('status');

				if($current_status === "Applied" || $current_status === "Eligible" || $current_status === "Not Eligible"){
					$users->select('users.email', 'users.first_name', 'application_status.status', 'applications.id as application_id', 'applications.reference_id', 'applications.highest_qualification', 'applications.alerts', 'jobs.category', 'jobs.title', 'track_application_status.id as track_id');
				}
				else{
					$cstatus = 1;
					$users->join('interview_details', 'applications.id' , '=', 'interview_details.application_id')
					->select('users.email', 'users.first_name', 'users.usertype', 'application_status.status', 'applications.id as application_id', 'applications.highest_qualification', 'applications.alerts', 'applications.reference_id', 'jobs.category', 'jobs.title',
							'interview_details.interview_date', 'interview_details.interview_time', 'interview_details.interview_location_details', 'track_application_status.id as track_id');

				}

				if(Input::has('from_date') && Input::has('to_date')) {
					$users->whereBetween('track_application_status.updated_at', array(Input::get('from_date'), Input::get('to_date')));
				}

				$users->where('track_application_status.mail_sent', '!=' , 1);
			}
			else{ 
				// downloading users report
				$users->select('users.id', 'users.usertype', 'users.first_name', 'users.last_name', 'users.email', 'users.phone', 'users.dob', 'users.age', 'track_application_status.updated_at',
						'applications.reference_id', 'applications.highest_qualification', 'applications.alerts', 'applications.id as application_id', 'jobs.job_cat_id', 'jobs.category', 'applications.sslc_percentage', 'applications.sslc_year',
						'applications.puc_percentage', 'applications.puc_year',  'applications.graduation_percentage', 'applications.graduation_year',
						'applications.graduation', 'applications.post_graduation_percentage', 'applications.post_graduation_year',
						'applications.post_graduation', 'applications.preferred_job_location', 'applications.WM_certified', 'application_status.status');
			}

			// downloading users report Based on USERTYPE
			if(Input::has('usertype') && Input::get('job_cat_id') == 1){
				$users = $users->where('users.usertype', '=', trim(Input::get('usertype')))
						->whereIn('track_application_status.id', $midArr);
			}
			else{
				$users = $users->where('jobs.job_cat_id', trim(Input::get('job_cat_id')))
					->whereIn('track_application_status.id', $midArr);
			}

			if (Input::has('status')){
				$users = $users->where('track_application_status.status', trim(Input::get('status')));
			}
			
			$users = $users->orderBy('users.id', 'asc')
					->get();

			if(Input::has('sendmail') && Input::has('status'))
			{
				if($users){
					$subject = '';
					$interview_location = '';
					$interview_date = '';
					$interview_time = '';
					$interview_day = '';
					$enrol_url = '';
					$track_url = url('/track');

					foreach ($users as $row) {
							$email =  $row->email;
							$reference_id = $row->reference_id;
							$status = $row->status;
							$name  =  $row->first_name;
							$category = $row->category;
							$title = $row->title;

							if($cstatus){
								$interview_location = $row->interview_location_details;
								$interview_time = $row->interview_time;
								
								$timestamp = strtotime($row->interview_date);
								$interview_date = date("d-m-Y", $timestamp);
								$interview_day = date('l', $timestamp);
							}
							
							if($email && $status && $reference_id){
								// the data that will be passed into the mail view blade template
								if($status === "Applied") $subject = 'Job Application - '.$title.' with '.$category;
								else if($status === "Eligible" || $status === "Not Eligible") $subject = 'Status Update - '.$title.' with '.$category;
								else if($status === "Confirmed Application") $subject = 'Interview Details - '.$title.' with '.$category;
								else if($status === "Cleared" || $status === "Rejected") {
									$subject = 'Interview Results - '.$title.' with '.$category;

										if($row->usertype === 'TJ'){
											$enrol_url = '';
										}
										else{
											$enrol_url = '';
										}
								}
							
								$data = array(
										'status'=> $status,
										'name'  => $name,
										'reference_id' => $reference_id,
										'category' => $category,
										'job_title' => $title,
										'track_url' => $track_url,
										'interview_date' => $interview_date,
										'interview_time' => $interview_time,
										'interview_day' => $interview_day,
										'interview_location' => $interview_location,
										'subject' => $subject,
										'enrol_url' => $enrol_url
								);
							
								Mail::send('emails.email', $data, function ($message) use ($email, $subject) {
									$message->subject($subject);
									$message->to($email); // Recipient address
								});

								DB::statement("UPDATE track_application_status SET mail_sent = 1 where id = $row->track_id");
							}
							
						}
					return Redirect::to('users')->with('success', 'Mail has been sent successfully.');

				}
				else return Redirect::to('users')->with('warning', 'No users found matching the criteria / mail have already sent.');

			}
			else{

				if(!$users){
					return Redirect::to('users')->with('warning', 'No users found matching the criteria.');
				}
				else{
					$csv_output = '';
					$report_heading = ", Users";
					$report_file = "Users_Details";
					$csv_output .= '';
					$csv_output .= $report_heading.' '.date('d-F-Y h:i A');
					$csv_output .= "\n";
					$csv_output .= "Serial No, User Type, User Id, Application Id, Reference Id, First Name, Last Name, Email, Phone, DOB(Y-m-d), Age, Last Updated At, Job Id, Job Category, SSLC Percentage, SSLC Passed Year, PUC Percentage, PUC Passed Year, Graduation Percentage, Graduation Passed Year, Graduation, Post Graduation Percentage, Post Graduation Passed Year, Post Graduation, Preferred Job Location, Status, Work Experience Area, Work Experience, Highest Qualification, Alerts, WM Certified\n";
					$arr = array();
					$work_area = $work_ex = '';
					$j = 0;
					foreach ($users as $row) {
						$j++;
						$id =  $row->id;
						$user_type =  $row->usertype;
						$first_name  =  $row->first_name;
						$last_name = $row->last_name;
						$email = $row->email;
						$phone = $row->phone;
						$dob = $row->dob;
						$age = $row->age;
						$last_updated_at = $row->updated_at;
						$application_id = $row->application_id;
						$job_id = $row->job_cat_id;
						$job_category = $row->category;
						$sslc_percentage = $row->sslc_percentage;
						$sslc_passed_year = $row->sslc_year;
						$puc_percentage = $row->puc_percentage;
						$puc_passed_year = $row->puc_year;
						$graduation = $row->graduation;
						$graduation_percentage = $row->graduation_percentage;
						$graduation_passed_year = $row->graduation_year;
						$post_graduation = $row->post_graduation;
						$post_graduation_percentage = $row->post_graduation_percentage;
						$post_graduation_passed_year = $row->post_graduation_year;
						$preferred_job_location = DB::table('location_details')->where('id','=', $row->preferred_job_location)->pluck('location');
						$status = $row->status;
						$reference_id = $row->reference_id;
						$highest_qualification = $row->highest_qualification;
						$alerts = $row->alerts;
						$WM_certified = $row->WM_certified;

						$work_experience =  DB::table('work_experience')
											->select('work_area', 'work_ex')
											->where('user_id', $row->id)
											->where('application_id', $row->application_id)
											->get();
						
						if( count($work_experience) > 0 ){
							$work_area = $work_ex = ''; 
							for ($i=0; $i<count($work_experience); $i++) {
   								$work_area .= '|' . $work_experience[$i]->work_area;
   								$work_ex.= '-' . $work_experience[$i]->work_ex;
							}
							$work_ex = substr($work_ex, 1);
							$work_area = substr($work_area, 1);
						}

						$csv_output_row1 = "$j, $user_type, $id, $application_id, $reference_id, $first_name, $last_name, $email, $phone, $dob, $age, $last_updated_at, $job_id, $job_category, $sslc_percentage, $sslc_passed_year, $puc_percentage, $puc_passed_year, $graduation_percentage, $graduation_passed_year, $graduation, $post_graduation_percentage, $post_graduation_passed_year, $post_graduation, $preferred_job_location, $status, $work_area, $work_ex, $highest_qualification, $alerts, $WM_certified \n";
						$csv_output .=$csv_output_row1;
					}
					$file = $report_file.date('d-m-Y h:i A').'.csv';
					header('Content-type: text/csv');
					header("Content-Disposition: attachment; filename=".$file."");
					echo $csv_output;
				}
			}
		}

	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function applyAnandRathi() {
		$rules = array(
		        'first_name' => 'Required|Min:3|Max:80|Alpha',
		        'last_name' => 'Required|Min:1|Max:80|Alpha',
		        'phone' => 'Required|numeric|Min:10',
		        'email'     => 'Required|Between:3,64|Email',
		        'resume'	=> 'Required',
		        'preferred_job_location' => 'Required',
		        'smsalerts' => 'Required',
		        'highest_qualification_stream' => 'Required'
		);

		$messages = array(
		    'last_name.Alpha' => 'The last name may only contain one word and only letters. ',
		    'resume.Required' => 'Please upload your resume',
		);

		$validator = Validator::make(Input::all(), $rules, $messages);
		$data = Input::all();

		if ($validator->passes()) {
			$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');

			$hasAlreadyApplied = DB::table('applications')
									->where('user_id','=', $userid)
									->where('job_id', '=', 2)
									->pluck('id');
			if(isset($hasAlreadyApplied)){
				return Redirect::back()
						->withInput()
						->withErrors('You have already applied for this job with this email');
			}

			if(!isset($userid)){
				$user_details = array('first_name' => Input::get('first_name'), 
					'last_name' => Input::get('last_name'),
					'email' => Input::get('email'),
					'password' => '',
					'usertype' => 'Registered',
					'phone' => Input::get('phone'),
					'created_at' => new DateTime,
					'updated_at' => new DateTime
					);
					DB::table('users')->insert($user_details);
				$userid = DB::table('users')->where('email','=', Input::get('email'))->pluck('id');
			}
			
			$userid = isset($user->id) ? $user->id : $userid ;

			if (Input::hasFile('resume'))
			{
			    Input::file('resume')->move( app_path().'/views/resumes/', $userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName());
				$cv_path = app_path().'/views/resumes/'.$userid.'_'.time().'_'.Input::file('resume')->getClientOriginalName();
			}
			$cv_path = isset($cv_path) ? $cv_path : '' ;
			$application_details = array('job_id' => Input::get('job_id'),
									 'user_id' => $userid,
									 'preferred_job_location' => Input::get('preferred_job_location'),
									 'highest_qualification' => Input::get('highest_qualification_stream'),
									 'alerts' => Input::get('smsalerts'),
									 'cv_path' => $cv_path
									  );

			$application = Application::create($application_details);

			$application->reference_id = strtoupper(substr(md5($application->id), 0, 8));
			$application->save();

			$application_status_details = array('application_id' => $application->id,
											'status' => '1',	// status 1 for applied but not payed yet
											'created_at' => new DateTime,
											'updated_at' => new DateTime 
										);
			$application_status = TrackApplicationStatus::create($application_status_details);

			//store work ex details
			$input = Input::all();
			$workex = $input['workex'];
			$work_array = array('user_id' => $userid,
							'application_id' => $application->id,
							'work_ex' => trim($workex[0]),
							'updated_at' => new DateTime,
							'created_at' => new DateTime

				);

			WorkExperience::create($work_array);

			// if register_value value is 0 - not registered, 1 - registered, 2 - registered and purchased
			$register_value = $this->register_user(Input::all());

			$user_details = DB::connection('mysql')->table('filter_anandrathi')
								->insert(array(
									'user_id' => $userid,
									'job_id' => Input::get('job_id'),
									'filter_code' => $register_value
									));

			$user_details = DB::connection('mysql2')->table('jos_users')->select('email', 'switch_pass')->where('email', Input::get('email'))->get();

			$data = array( 'name'=>Input::get('first_name'),
							'status'=>'Applied','job_title'=>'Thank you for applying Anand Rathi', 
							'user_details' => $user_details,
							'register_value' => $register_value
							);

			Mail::send('emails.anandrathi', $data, function($message) use ($application)
			{
				$message->from('ratnesh@learnwithflip.com', 'Nitish');
			    $message->to(Input::get('email'), Input::get('first_name').' '.Input::get('last_name'))->subject('Job Application - Wealth Management (Financial Advisor) Certification Program');
			});
			
			return View::make('applications.thankyou_anandrathi', array('register_value' => $register_value, 'user_details' => $user_details));
		}

		return Redirect::back()
			->withInput()
			->withErrors($validator);
	}

	private function register_user($data)
	{
		$userid = DB::connection('mysql2')->table('jos_users')->where('email', $data['email'])->pluck('id');
		
		// if isset user is registered
		if(!isset($userid)){
		
		// simply register the user and return the response
		$name = $data['first_name'].' '.$data['last_name'];
		$password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
		
		DB::connection('mysql2')->table('jos_users')->insert( array(
			'name' => $name,
			'username' => $data['email'],
			'email' =>  $data['email'],
			'password' => md5($password),
			'switch_pass' => $password,
			'usertype' => 'Registered',
			'gid' => 18,
			'registerDate' => Carbon::now(),
			'createDate' => time()
			));

		$userid = DB::connection('mysql2')->table('jos_users')->where('email', $data['email'])->pluck('id');

		$hash_secret = "VirtueMartIsCool";
        $user_info_id=md5(uniqid( $hash_secret));

        DB::connection('mysql2')->table('jos_vm_user_info')->insert(array(
        	'user_info_id' => $user_info_id, 
        	'user_id' => $userid,
        	'address_type' => 'BT', 
        	'user_email' => $data['email'],
        	'cdate' => time(),
        	'mdate' => time(), 
        	'first_name' => $name,
        	'vm_hearaboutus' => 'Google',
        	'vm_highestqualification' => 'Graduate',
        	'vm_educationalinstituition' => 'NA',
        	'vm_workexperience' => '0',
        	'vm_nameofcompany' => 'NA',
        	'vm_professionaldegree' => 'NA',
        	'vm_smsalerts' => 'NA',
        	'vm_captcha' => 'VM_CAPTCHA'
        	));

        DB::connection('mysql2')->table('jos_core_acl_aro')->insert(array(
        	'section_value' => 'users',
        	'value'=> $userid,
        	'order_value' => 0,
        	'name' => $name,
        	'hidden' => 0
        	));
		
		$aro_id = DB::connection('mysql2')->table('jos_core_acl_aro')->where('value', $userid)->pluck('id');

        DB::connection('mysql2')->table('jos_core_acl_groups_aro_map')->insert(array(
        	'group_id' => 18, 
        	'section_value' => '',
        	'aro_id' => $aro_id
        	));

        DB::connection('lms_connection')->table('mdl_user')->insert(array(
        	'cmsid' => $userid, 
        	'confirmed' => 1, 
        	'mnethostid' => 1, 
        	'username' => $data['email'],
        	'password' => md5($password), 
        	'firstname' => $name,
        	'email'  => $data['email']
        ));

		$lms_user_id = DB::connection('lms_connection')->table('mdl_user')->where('email', $data['email'])->pluck('id');

		DB::connection('mysql2')
					->table('jos_users')
		            ->where('email', $data['email'])
		            ->update(array('lmsid' => $lms_user_id));

		return 0;

		}else{
			// check if the user is enrolled to WM course and return the response
			$order_ids = DB::connection('mysql2')
							->table('jos_vm_orders')
							->select('jos_vm_order_item.order_id')
							->join('jos_vm_order_item', 'jos_vm_orders.order_id','=','jos_vm_order_item.order_id')
							->where('jos_vm_orders.user_id', $userid)
							->where('jos_vm_order_item.order_status', '=', 'C')
							->whereIn('jos_vm_order_item.product_id', array(268,438,269,341))
							->get();
							// dd($order_ids);
			$is_wm_user = isset($order_ids[0]->order_id)? true: false;

			if($is_wm_user){
				return 2;
			}else{
				return 1; // 0 - not registered, 1 - registered, 2 - registered and purchased
			}

		}
	}

	public function registrationsClosed(){
		$user_details = array(
				'name' => Input::get('name'),
				'email' => Input::get('email'),
				'phone' => Input::get('phone'),
				'preferred_job_location' => Input::get('preferred_location'),
				'current_location' => Input::get('current_location'),
		);

		ClosedRegistrations::create($user_details);

		return View::make('applications.closed')->with('registered', TRUE);

	}

	public function registrationsClosedDownload()
	{
		
		$csv_output = '';
		$report_heading = ", Users";
		$report_file = "Users_Details";
		$csv_output .= '';
		$csv_output .= $report_heading.' '.date('d-F-Y h:i A');
		$csv_output .= "\n";
		$csv_output .= "Serial No, Name, Email, Phone, Preferred Job Location, Current Location, Registered Date \n";

		$users = ClosedRegistrations::all();

		foreach ($users as $user) {
			$user_details = "$user->id,$user->name,$user->email,$user->phone,$user->preferred_job_location,$user->current_location,$user->created_at \n";
			$csv_output .= $user_details;
		}

		$file = $report_file.date('d-m-Y h:i A').'.csv';
		header('Content-type: text/csv');
		header("Content-Disposition: attachment; filename=".$file."");
		echo $csv_output;
	}
}
