<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', 'ApplicationsController@show');

Route::get('guaranteed-bank-job/HDFC/{id}', 'ApplicationsController@show');


//new HDFC model
// Route::get('guaranteed-bank-job/HDFC/{job_id}', 'ApplicationsController@showHdfc');
Route::get('guaranteed-bank-job/HDFC/', 'ApplicationsController@showHdfc');


//Anand RAti - job model 2

Route::get('guaranteed-interview/AR/{id}', 'ApplicationsController@show');

//IIFL - job model 3

Route::get('IIFL/{id}', 'ApplicationsController@show');

Route::get('profile', function()
{
	return 'You are logged in'. Auth::user()->email;
})->before('auth');

Route::get('login', 'SessionsController@create');

Route::get('logout', 'SessionsController@destroy');

Route::get('track', 'ApplicationStatusController@index');

Route::get('/cvdownload/{application_id}', 'UsersController@cvDownload');

Route::resource('sessions', 'SessionsController'); //,['only'=>['create','store','destroy']]

//Route::resource('sessions', 'SessionsController', array('only'=>array('create','store','destroy')) );

Route::get('/hdfc/tc/', function()
{
    return View::make('hdfc.tc');
});

Route::any('payment', 'HdfcController@payment_response');

Route::resource('jobs', 'JobsController');

Route::resource('/hdfcApplications', 'HdfcController');

Route::post('/questionnarie', 'HdfcController@questionnarie');

Route::get('/orders/{id?}', 'HdfcController@orders');

Route::post('/showquestionnarie', function ()
{
	$location = array('id' => Input::get('job_id'));
	return View::make('applications.questionnarie')
				->with('id', Input::get('job_id') )
				->with('location', $location)
				->with('application_id', Input::get('application_id'));
});

Route::resource('users', 'UsersController');

// start custom routes
Route::post('/users', 'UsersController@index');

/*Route::post('/hdfc', 'UsersController@hdfcUsers');*/

Route::resource('/hdfc', 'UsersController@hdfcUsers');

Route::post('/cvfilter', 'ApplicationsController@cvfilter');

Route::post('/interviewDetails', 'ApplicationsController@interviewDetails');

Route::post('/applicationStatus', 'ApplicationsController@applicationStatus');

Route::post('/downloadORsendmail', 'ApplicationsController@downloadORsendmail');

Route::post('/uploadUsers', 'ApplicationsController@uploadUsers');

// end custom routes 

Route::resource('applications', 'ApplicationsController');

Route::resource('applicationstatus', 'ApplicationStatusController');


Route::post('runEligibility', 'ApplicationsController@runEligibility');

Route::post('/applyAnandRathi', 'ApplicationsController@applyAnandRathi');

Route::post('/iifl', 'ApplicationsController@iifl');

Route::post('updatestatus', 'ApplicationStatusController@updatestatus');

Route::post('payfromtrack', 'ApplicationStatusController@charge_user');

Route::get('update-order-status', 'HdfcController@updateOrderStatus');

//updatePaymentStatus

Route::get('update-payment-status', 'ApplicationStatusController@updatePaymentStatus');

// submit closed form data
Route::post('registrations-closed', 'ApplicationsController@registrationsClosed');
// download closed form data
Route::get('download-closed-registrations', 'ApplicationsController@registrationsClosedDownload');