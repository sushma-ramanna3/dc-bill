<?php

class CollegeList extends Eloquent {

	protected $guarded = array();

	public static $rules = array();

	protected $table = 'college_list';
}
