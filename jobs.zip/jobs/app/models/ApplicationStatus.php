<?php

class ApplicationStatus extends Eloquent {

	protected $guarded = array();

	public static $rules = array();

	protected $table = 'application_status';

}
