<?php

class WorkExperience extends Eloquent {
	protected $guarded = array();

	public static $rules = array();

	protected $table = 'work_experience';
}
