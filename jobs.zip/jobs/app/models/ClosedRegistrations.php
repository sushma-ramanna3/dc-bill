<?php

class ClosedRegistrations extends Eloquent {

	protected $guarded = array();

	public static $rules = array();

	protected $table = 'closed_registrations';
}