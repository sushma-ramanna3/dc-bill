<?php

class TrackApplicationStatus extends Eloquent {

	protected $guarded = array();

	public static $rules = array();

	protected $table = 'track_application_status';

	/**
	 * Get the latest id for the user track application.
	 *
	 * @return string
	 */
	public static function getLatestStatus()
	{
		$midArr[] = '';
		$max_id = DB::table('track_application_status')
					->join('applications', 'track_application_status.application_id', '=', 'applications.id')
					->select(DB::raw('MAX(track_application_status.id) as mid'))
					->groupBy('track_application_status.application_id')
					->get();

		foreach($max_id as $id){
			$midArr[] = $id->mid;
		}
		return $midArr;
	}

}
