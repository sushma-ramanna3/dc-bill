<?php

class Payment extends Eloquent {
	protected $guarded = array();
	protected $table = 'payment';

	public static $rules = array();
}
