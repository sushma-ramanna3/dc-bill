<?php

class Application extends Eloquent {
	protected $guarded = array();

	public static $rules = array();

	public function WorkExperience()
	{
		return $this->hasMany('WorkExperience');
	}

	public function applicationStatus()
	{
		return $this->hasMany('TrackApplicationStatus');
	}

	public function user()
	{
		return $this->belongsTo('User');
	}

}
