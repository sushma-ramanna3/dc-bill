<?php

class HdfcTrackApplication extends Eloquent {

	protected $guarded = array();

	public static $rules = array();

	protected $table = 'hdfc_track_application';

	/**
	 * Get the latest id for the user track application.
	 *
	 * @return string
	 */
	public static function getLatestStatus()
	{
		$midArr[] = '';
		$max_id = DB::table('hdfc_track_application')
					->join('hdfc_applications', 'hdfc_track_application.application_id', '=', 'hdfc_applications.id')
					->select(DB::raw('MAX(hdfc_track_application.id) as mid'))
					->groupBy('hdfc_track_application.application_id')
					->get();

		foreach($max_id as $id){
			$midArr[] = $id->mid;
		}
		return $midArr;
	}

}
