
<?php

class HdfcInterviewLocations extends Eloquent {

	protected $guarded = array();

	public static $rules = array();

	protected $table = 'hdfc_interview_locations';
}
