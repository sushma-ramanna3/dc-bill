@extends('layouts.main')

@section('content')
	Hello, World !!
@stop