  	 @if($location['id'] == 6 || $location['id'] == 7) 
  	 <style type="text/css">#nav_li>li {
		background: #001E74;
		width: 175px;
		text-align: center;
		}
	</style>
	@endif
  <ul class="nav nav-pills padd-15" data-tabs="tabs" id="nav_li" style="padding-left:25px;">  
    <li class="active about"><a href="#about" data-toggle="tab">Program Details</a></li>  
    @if($location['id'] == 5 || $location['id'] == 4) 
    	<li class="apply"><a href="#apply" data-toggle="tab">Apply</a></li>
    @endif
    <li class="track"><a href="/track">Track My Application</a></li> 
    <li class="faq"><a href="#faq" data-toggle="tab">FAQs</a></li>
    <li><a href="#updates" data-toggle="tab">Updates</a></li>
    <li class="last-item contact"><a href="#contact" data-toggle="tab">Contact Us</a></li>   
  </ul>