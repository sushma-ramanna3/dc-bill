<div id="my-tab-content" class="tab-content padd-15 border-top">
        <div id="about" class="tab-pane active">   
          <h4 class="red1 font-bold paddb-border">Program Selection Process</h4>
              
              <h5 class="blue font-bold">You need to follow a simple, 4 step process:</h5>
              <ol>
                <li><span class="blue font-bold">Online Test:</span> Complete the HDFC Bank Online test.</li>
                <li><span class="blue font-bold">Clear Interview and get an offer:</span> Candidates who clear the test, will be <b>interviewed by HDFC Bank</b>; selected candidates get a <b>conditional offer letter.</b></li>
                <li><span class="blue font-bold">Earn Industry recognized Certification:</span> Candidate must enroll and successfully complete the following certification to become eligible to join HDFC Bank:</li>
                <ul>
                  <li>
                    The FLIP Corporate Banking, RM and Credit Analysis Certification.
                  </li>
                </ul>
                <li><span class="blue font-bold">Join HDFC Bank immediately:</span> Candidate clearing FLIP certification program will join HDFC Bank.</li>
              </ol>

              <p><b>Limited seats, strictly on a first-come-first served basis, for the current batch.</b> <!-- <a href="#apply" class="apply_now cust_apply" data-toggle="tab">Apply</a> --></p>

              <h4 class="red1 font-bold paddb-border">The FLIP Certification program</h4>
              <p>
                The <span class="blue font-bold">FLIP Corporate Banking, RM and Credit Analysis Certification</span>, in association with HDFC Bank, aims to provide role specific training, and make the candidate job ready. The program covers ,how to spot opportunities and pitch to clients,the different banking products to be offered ,and how to do a detailed  credit evaluation. You will also learn how to prepare a CAM in practice.
              </p>
                 <p>  <a style="color: #11AC4F;" class="modalButton co" id="modalButtonee" data-toggle="modal" data-src="https://www.learnwithflip.com/CourseOutline/CorporateBanking.html" 
  data-height=400 data-width=561 data-target="#myModalee">
  Click here to see the complete coverage</a></p>
              <p>
                The <b>online program</b> is blended with interesting, <b>live simulations, web faculty sessions</b>, and <b>e-mail query support;</b> you can access the course from anywhere, anytime.
              </p>
              <p class="red1 font-bold"><b>You will need a computer and an internet connection, for the program.</b></p>

              <h4 class="red1 font-bold paddb-border">Registration & Program Fee</h4>
              <ol>
                <li><b>Registration Fee:</b> Candidate needs to pay <b>INR 750 as registration fee</b> (Inclusive of all taxes), while applying for the program process.</b></li>
                <li style="margin-top:5px;"><b>FLIP Certification Program Fee:</b> Payable in two installments:<br><span style="display:block;margin-top: 5px;">
<b>1st Installment:</b> &nbsp;INR 9,000 (Inclusive of all taxes), at the time of enrollment for the FLIP certification program, <b>only</b> after getting the conditional offer letter.<br>
<b>2nd Installment:</b> INR 8,000 (Inclusive of all taxes), <b>only</b> on clearing the FLIP certification program, and before joining the bank.<br></li></span>
              </ol>
       </div>

<div class="modal fade" id="myModalee" tabindex="-1" role="dialog"  aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-dialog">
        <div class="modal-content">
           <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
               <h4 class="modal-title" id="myModalLabel"></h4>
          </div>
        <div class="modal-body">
             <iframe frameborder="0"></iframe>
        </div>
        <div class="modal-footer">
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
       </div>
    </div>
  </div>
       
<script type="text/javascript">
   (function($) {
        document.title = 'Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG)';

    $('#modalButtonee').on('click', function(e) {
      var src = $(this).attr('data-src');
      var height = $(this).attr('data-height') || 300;
      var width = $(this).attr('data-width') || 400;
      
      $("#myModalee iframe").attr({'src':src,
                'height': height,
                'width': width});
    });

    })(jQuery);
</script>
