<script>

$(document).ready(function() {

  // process the form
  $('#appform').submit(function(event) {
     if($("#post_graduation_stream option:selected").text() == 'MBA - Others') {
        $('.none, .none1').css({'display':'block'});
        $('.none2').css({'display':'none'});
        $('#post_graduation_percentage, #post_graduation_year, #post_graduation_college, #others_specialization, #result_status').attr('required','required');
        $('#attempts').removeAttr('required');
        $("#post_graduation_college option:first").val('');
      }
      else if($("#post_graduation_stream option:selected").text() != 'CA' && $("#post_graduation_stream option:selected").text() != 'MBA - Others') {
        $('.none1').css({'display':'block'});
        $('.none2').css({'display':'none'});
        $('.none').css({'display':'none'});
        $("#post_graduation_college option:first").val('');
        $('#post_graduation_percentage, #post_graduation_year, #post_graduation_college, #result_status').attr('required','required');
        $('#others_specialization, #attempts').removeAttr('required');
      
      }
      else if($("#post_graduation_stream option:selected").text() == 'CA') {
        $('.none2').css({'display':'block'});
        $('.none, .none1').css({'display':'none'});
        $('#attempts').attr('required','required');
        $('#post_graduation_percentage, #post_graduation_year, #post_graduation_college, #others_specialization, #result_status').removeAttr('required');
      }
      
      if( $("#post_graduation_percentage").val() != "" && $("#post_graduation_percentage").val() < 2) { 
        alert("If you are entering CGPA then convert it to percentage and proceed");
        return false;
      }
  // disable the button
  $('#submit').attr('disabled', 'disabled');

  // get the form data
  // var formData = $('form').serialize();
  var formData = new FormData(this);
  formData.append('resume',$("#resume").get(0).files[0]);

    // process the form
    $.ajax({
      type    : 'POST', // define the type of HTTP verb we want to use (POST for our form)
      url     : '/hdfcApplications', // the url where we want to POST
      data    : formData, // our data object
      contentType: false,
      processData: false,
      dataType  : false // what type of data do we expect back from the server
    })
      // using the done promise callback
      .done(function(obj) {
          // re-enable button
          $('#submit').removeAttr('disabled');

          // log data to the console so we can see
          console.log(obj);
        if(obj.status == 21){
              $('#myModal').modal('show');
        }else if(obj.status == 20){
              var responseData = $.param( obj );
              console.log(responseData);
              $( "#application_id" ).val(obj.application_id );
              $( "#qsubmit" ).trigger( "click" );
        }else if(obj.status == 'duplicate'){
              console.log(obj);
              $('#appliedModal').modal('show');
        }else if(obj.status == 'validator'){
              $('#validatorModal').modal('show');
        }else{
              console.log('Something went wrong!!');
        }
      });

    // stop the form from submitting the normal way and refreshing the page
    event.preventDefault();
  });

});
</script>