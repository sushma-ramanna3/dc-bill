<style type="text/css">
  .form-group{
    margin-bottom: 0px;
  }

</style>
<div id="apply" class="tab-pane"> 
  <form class="form-horizontal col-md-12" id="questionnarie" action="/questionnarie" method="post">
        <fieldset id="fieldsetappend" >
            <!-- Form Name -->
            <h5 class="paddb-border red font-bold"><span class="red1">Step 2:</span>To proceed, please answer the following & submit the application</h5>
           
            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">1. I understand that, I need to pay a non-refundable registration fee, for applying to the program.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q1','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                 <!--  {{ Form::radio('q1','0','', array('id'=>'first2')) }}
                 {{ Form::label('0','I disagree', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">2. I understand that, I need to appear for an online test. If successful in the test, I need to appear for the HDFC Bank interview.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q2','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                 <!--  {{ Form::radio('q2','0','', array('id'=>'first2')) }}
                 {{ Form::label('0','I disagree', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

             <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue" style="text-align:left;">3. I understand that, once I get the provisional offer letter, I need to enroll for the FLIP Certification program as a pre-requisite, for which I need to pay a non-refundable program fee of INR 9,000 (Inclusive of all taxes) as 1st Installment.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q3','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                 <!--  {{ Form::radio('q3','0','', array('id'=>'first2')) }}
                 {{ Form::label('0','I disagree', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

    
             <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue" style="text-align:left;">4.  I understand that, I will need to pay the 2nd instalment of INR 8,000 (Inclusive of all taxes), only if I clear the certification exam/s, and before joining the bank.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q4','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                <!--   {{ Form::radio('q4','0','', array('id'=>'first2')) }}
                {{ Form::label('0','I disagree', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

             <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">5. I understand that, if I am unsuccessful in the FLIP exam (2 attempts), the offer letter is null and void, and I will not get any refund for fees paid till-date.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q5','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                 <!--  {{ Form::radio('q5','0','', array('id'=>'first2')) }}
                 {{ Form::label('0','I disagree', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">6.  I understand that, I may need to re-locate within the region specified by HDFC bank.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q6','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                <!--   {{ Form::radio('q6','0','', array('id'=>'first2')) }}
                {{ Form::label('0','I disagree', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue" style="text-align:left;">7. <!-- If I am applying for Relationship Manager – Branch Banking or Trade Sales Manager, --> I understand that I need to also clear the regulatory <b>NISM – Mutual Fund Distributors Certification Examination</b> – to be eligible to join HDFC bank.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                
                  {{ Form::radio('q7','Already NISM certified','', array('id'=>'second1')) }}
                  {{ Form::label('1','Already NISM certified', array('style' => 'font-weight:normal'))}}<br>
                  {{ Form::radio('q7','I agree to write NISM certification','', array('id'=>'second2')) }}
                  {{ Form::label('2','I agree to write NISM certification', array('style' => 'font-weight:normal')) }}<br>
            <!--  {{ Form::radio('q7','Not applicable for Relationship Manager – Business Banking/EEG','', array('id'=>'second3')) }}
                  {{ Form::label('3','Not applicable for Relationship Manager – Business Banking/EEG', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>

            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">8. I understand that I need to have valid Pan Card to apply for NISM certification</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q8','Already have Pan Card','', array('id'=>'third1')) }}
                  {{ Form::label('1','Already have Pan Card', array('style' => 'font-weight:normal'))}}<br>
                  {{ Form::radio('q8','I will apply & get my Pan Card in time','', array('id'=>'third2')) }}
                  {{ Form::label('2','I will apply & get my Pan Card in time', array('style' => 'font-weight:normal')) }}<br>
            <!--  {{ Form::radio('q8','Not applicable for Relationship Manager – Business Banking/EEG','', array('id'=>'third3')) }}
                  {{ Form::label('3','Not applicable for Relationship Manager – Business Banking/EEG', array('style' => 'font-weight:normal;margin-bottom:10px')) }} -->
                </div>
            </div>
 
            <input id="job_id" name="job_id" type="hidden" value="<?php echo $id; ?>" />
            <input id="application_id" name="application_id" type="hidden" value="<?php echo $application_id; ?>" /> <!-- -->
            <input id="questionnarie" name="questionnarie" type="hidden" value="1" />

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="submit"></label>
              <div class="col-md-5">
                <button id="submit" name="submit" class="btn btn-lg btn-success btn-block button-padd">Submit and Pay Registration Fee</button>
              </div>
            </div>
        </fieldset>
      </form>
  </div>

  <!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">All fields are required!</h4>
      </div>
      <div class="modal-body">
       <!-- Please go through below link 
       <a href="#">Click here</a>-->
       Please answer all the questions
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div> 
</div>

<!-- <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Not Eligibile!</h4>
      </div>
      <div class="modal-body">
       Please go through below link 
       <a href="#">Click here</a>
       You are do not pass the test.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div> 
</div> -->

<script>
  (function($) {
    $('.none').css({'display':'none'});
   
   /* $('input[name=third]').change(function() {
      if($('input[name=third]:checked').val() == 'third1') {
        $('.none').css({'display':'block'});
      }
      else{
        $('.none').css({'display':'none'});
      }
    });*/

    $('#questionnarie').submit("click",function() {
      if ($("input[name='q1']:checked").length == 0 || $("input[name='q2']:checked").length == 0 
        || $("input[name='q3']:checked").length == 0 || $("input[name='q4']:checked").length == 0  
        || $("input[name='q5']:checked").length == 0 || $("input[name='q6']:checked").length == 0
        || $("input[name='q7']:checked").length == 0 || $("input[name='q8']:checked").length == 0) {
        $('#myModal').modal('show');
          return false;
      }
      /*else if($('input[name=q1]:checked').val() == 1 && $('input[name=q2]:checked').val() == 1
        && $('input[name=q3]:checked').val() == 1 && $('input[name=q4]:checked').val() == 1
        && $('input[name=q5]:checked').val() == 1 && $('input[name=q6]:checked').val() == 1) {
        return true;
      } 
      else if($('input[name=q1]:checked').val() != 1 || $('input[name=q2]:checked').val() != 1 
        || $('input[name=q3]:checked').val() != 1 || $('input[name=q4]:checked').val() != 1
        || $('input[name=q5]:checked').val() != 1 || $('input[name=q6]:checked').val()!= 1) {
        $('#myModal1').modal('show');
        //return false;
      }*/
    });
    
  })(jQuery);

</script>
