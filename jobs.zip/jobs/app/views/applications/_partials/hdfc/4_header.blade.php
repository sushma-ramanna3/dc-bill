  <!--   <div class="col-md-12 img_w padd_null"><img src="/assets/images/banner2.jpg" alt="banner" name="banner"/></div> -->
<div class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="http://www.learnwithflip.com" target="_blank">
        <img src="/assets/images/fliplogo.png" alt="logo">
      </a>
      <ul class="nav navbar-nav col-md-7 align_center margin-navbar pull-left" style="margin-left:0px;">
      <?php if(!isset($location['id'])){
        $location['id'] = 999;
      }
      ?>
          @if($location['id'] == 4) 
            <h1 id="job_page_title" style="font-size: 40px;margin-top: 15px;">Trade Sales Manager</h1>
          @elseif($location['id'] == 5) 
            <h1 id="job_page_title" style="font-size: 30px;margin-top: 20px;text-align:cenrter;margin-left:26px;">Branch Relationship Manager</h1>
          @elseif($location['id'] == 6) 
            <h1 id="job_page_title" style="font-size: 30px;margin-top: 10px;margin-left:15px;">Relationship Manager - Business Banking</h1>
          @elseif($location['id'] == 7) 
          <h1 id="job_page_title" style="font-size: 26px;margin-top: 10px;margin-left:15px;">Sales Manager/Relationship Manager –Emerging Enterprise Group (EEG)</h1>
          @elseif($location['id'] == 999) 
          <h1 id="job_page_title" style="font-size: 30px;margin-top: 10px;margin-left:15px;">Relationship Manager Program</h1>
          @endif
      </ul>
      <a class="navbar-right hdfc border pull-right" style="margin-top: 1.5%" href="#">
        <img src="/assets/images/hdfc_logo.png" alt="HDFC" style="height: 56px;">
      </a>
    </div>
   </div>
</div>