<div id="contact" class="tab-pane text-center"> 
  <h4><b>Contact Person: </b>Ratnesh</h4> 
  <h4><b>Contact : </b><a href="mailto:ratnesh@learnwithflip.com">ratnesh@learnwithflip.com</a></h4> 
  <h4><b>Call us: </b>+91 9035.026.044/ 9243.666.002/003 </h4>
</div>