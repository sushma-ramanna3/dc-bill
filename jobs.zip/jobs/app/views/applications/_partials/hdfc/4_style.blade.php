<style>
  .iifl{
    display: none;
  }
  #nav_li>li {
    background: #001E74;
    width: 140px;
    text-align: center;
  }
 #nav_li>li.active>a, #nav_li>li.active>a:hover, #nav_li>li.active>a:focus, #nav_li>li a:hover {
    color: #fff;
    background-color:#EE0000;
  }
  .red1,  #red  {
    color: #EE0000;
  }
  .nav-pills>li>a {
    padding: 10px 3px !important;
  }
  #nav_li .track{
     width: 170px;
  }
  </style>