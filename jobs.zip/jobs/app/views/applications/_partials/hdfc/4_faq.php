  <div id="faq" class="tab-pane">   
    <h4 class="red1 font-bold paddb-border">FREQUENTLY ASKED QUESTIONS (FAQs)</h4>
        
        <h5 class="blue font-bold"><span class="paddl-5">1. What is the Relationship Manager Program (RMP)?</span></h5>
        <div class="paddl-20">
           <p>The Relationship Manager Program (RMP), is a joint FLIP-HDFC Bank partnership, to create trained and job ready managers, to join HDFC Bank, across India. The roles on offer currently are:</p>
            <p>– Relationship Manager/Sales Manager – Emerging Enterprises Group, Relationship Manager -Business Banking, Trade Sales Manager and Branch Relationship Manager.</p>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">2. What is the selection process?</span></h5>
        <div class="paddl-20">
           <p>You need to follow a simple, 4 step process:</p>
           <ol>
                <li><span class="blue font-bold">Online Test:</span> Apply &amp; write the HDFC Bank Online test.</li>
                <li><span class="blue font-bold">Clear Interview and get an offer:</span>&nbsp;Candidates who clear the test, get interviewed by HDFC Bank; selected candidates get a provisional offer letter.</li>
                <li><span class="blue font-bold">Earn Industry recognized Certification:</span> With offer letter, a candidate must enrol &amp; successfully complete:</li>
                    <ul>
                      <li>The relevant FLIP Certification program, and</li>
                      <li>NISM – Mutual Fund Distributors Certification Examination( not applicable for Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG) and Branch Relationship Manager profiles)</li>
                    </ul>
                <li><span class="blue font-bold">Join HDFC Bank:</span> Candidates clearing FLIP certification program &amp; NISM certification will join HDFC Bank.</li>
            </ol>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">3. What is the program fee?</span></h5>
        <div class="paddl-20">
           <p>The candidate will have to pay INR 750 (all incl.) as registration fee.  In addition, the candidate will have to pay the program fee. The program fee has to be paid in two installments as follows:</p>
            <p><b>Installment 1</b>: INR 9000 (all incl.), to be payable after getting provisional offer letter from the bank.</p>           
            <p><b>Installment 2</b>: INR 8000 (all incl.), to be payable after clearing the FLIP Certification exam,and NISM(where applicable).</p>
            <p>Candidate will have to pay Installment 1 <u>only after getting selected</u> by the bank and Installment 2, <u>only after clearing FLIP certification exam and the NISM exam(where applicable).</u></p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">4. How can I make the payment?</span></h5>
        <div class="paddl-20">
           <p>When you enroll online at www.learnwithflip.com,, you can pay in the following ways:</p>
           <ol>
             <li>Online, via debit/credit card or net banking.</li>
             <li>By using a special deposit slip (you can download it during the enrolment process), and depositing a cheque or cash, at any Axis Bank branch in India.</li>
           </ol>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">5. When/How will the online test be conducted?</span></h5>
        <div class="paddl-20">
            <p>After you register for the program, you will be invited for an online test. You can take this test from anywhere.  The test will be scheduled in batches, as and when a specified number of candidates sign up for it. You will receive a prior notification to attend.The online test will have aptitude and psychometric questions.</p>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">6. What happens if I do not clear the online test?</span></h5>
        <div class="paddl-20">
            <p>You need to clear the online test to proceed to the interview stage. If you do not clear the online test, you will no longer be included in the program. The registration fee of RS.750 is non refundable.</p>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">7. Is it necessary for me to go through the FLIP Certification program?</span></h5>
        <div class="paddl-20">
            <p>The FLIP certification program is a pre-requisite to be selected for these roles. Further, this is an industry recognized certification, that will help you deliver faster in your role.</p>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">8. What certification program do I need to undergo for Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG), Relationship Manager – Business Banking, Trade Sales Manager and Relationship Manager – Branch Banking?</span></h5>
        <div class="paddl-20">
            <p>After you get a provisional offer letter from HDFC Bank, you will undergo a specific FLIP certification program, as a pre-requisite for the role. The relevant FLIP certification for each role is mentioned below: </p>
                <table border="1" cellpadding="3" cellspacing="1" style="width: 500px;font-family: arial;font-size: 12px;">
                  <tbody>
                    <tr>
                      <td align="center">
                        <strong>Role</strong></td>
                      <td align="center">
                        <strong>Required FLIP Certification</strong>
                        </td>
                    </tr>
                    <tr>
                      <td>
                        Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG)
                      </td>
                      <td>
                        <ul class="ul_padding">
                          <li>FLIP Corporate Banking products, RM & Credit analysis Certification</li>
                        </ul>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Relationship Manager -Business Banking
                      </td>
                      <td>
                        <ul class="ul_padding">
                          <li>FLIP Corporate Banking products, RM & Credit analysis Certification</li>
                        </ul>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Trade Sales Manager
                      </td>
                      <td>
                        <ul class="ul_padding">
                          <li>FLIP Branch Relationship Manager Certification</li>
                          <li>NISM SeriesMutual Fund Distributors Certification Exam</li>
                        </ul>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Branch Relationship Manager
                      </td>
                      <td>
                        <ul class="ul_padding">
                          <li>FLIP Branch Relationship Manager Certification</li>
                          <li>NISM Series Mutual Fund Distributors Certification Exam</li>
                        </ul>
                      </td>
                    </tr>
                  </tbody>
                </table>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">9. I have been interviewed by HDFC Bank previously. Am I eligible to apply?</span></h5>
        <div class="paddl-20">
            <p>You are eligible to apply only if you have not gone through the recruitment process with HDFC Bank in the last six months.</p>
        </div>


        <h5 class="blue font-bold"><span class="paddl-5">10. Can I apply to more than one job profiles?</span></h5>
        <div class="paddl-20">
            <p>No. You can apply to only one role, i.e. Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG), Relationship Manager - Business Banking, Trade Sales Manager and Branch Relationship Manager.</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">11. Can I change my application to another job after clearing the online test?</span></h5>
        <div class="paddl-20">
            <p>No. You cannot change your application to any other job profile after clearing the online test</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">12. How and where is the FLIP Certification Program conducted?</span></h5>
        <div class="paddl-20">
           <p>The FLIP Certification Program (RMP) is conducted online. You will need a computer with an internet connection (or a Smart Phone!), and that's it. You can learn from anywhere, any time.</p>
           <p><b>After receiving your provisional offer letter from HDFC Bank, you will enrol for the Program. You will receive a login-ID and password. Log in at www.learnwithflip.com, for a friendly, flexible learning experience.</b></p>
           <p>For any content related queries, you can avail the following learning support:</p>
           <ol>
             <li>Doubt clearing sessions with faculty</li>
             <li>E-mail & live chat query support: Help is just a click away; you can mail us or come on live chat, to get your queries answered.</li>
           </ol>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">13. What is the recognition of the  FLIP Certification?</span></h5>
        <div class="paddl-20">
           <p>All FLIP Certifications are recognized by India's leading banks and Financial Institutions. Thousands of students and working professionals take FLIP Certifications, each year - even without the assurance of placement opportunities!</p>
            <p>For this program, a career with HDFC Bank is assured on successful completion. You can see the program, on HDFC Bank's website as well: (www.hdfcbank.com/careers)</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">14. I do not have a PAN card. What should I do??</span></h5>
        <div class="paddl-20">
           <p>A valid PAN is required for taking the NISM certification.  This certification is required if you are applying for Trade Sales Manager and Relationship Manager – Branch Banking profile.</p>
           <p>To start, you can still apply for these profiles and enrol for the FLIP certification. Meanwhile, you can apply for PAN card and submit it later, during registration of NISM Series certification. Note: If you do not have the PAN, and hence not eligible for the NISM exam, you will be out of the selection process.</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">15. Do I have to register for NISM certification separately?</span></h5>
        <div class="paddl-20">
            <p>Yes. You should register for the NISM certification separately. This certification costs Rs.1282 (all incl.), which will be reimbursed by HDFC Bank after you join the bank.</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">16. I am already NISM certified. Do I need to take the certification again?</span></h5>
        <div class="paddl-20">
           <p>No. If you have a valid NISM certification, you do not need to take the certification again. However, in this case, the certification cost incurred in the past will not be reimbursed by HDFC Bank.</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">17. How can I take the FLIP certification exam?</span></h5>
        <div class="paddl-20">
           <p>FLIP runs online testing centers, across India. You can book a slot, (4 slots per day, 6 days a week) and write the computer based exam, in any of these centers, on any convenient day.</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">18. What if I do not clear the FLIP certification exam?</span></h5>
        <div class="paddl-20">
            <p>This program is for participants, who are serious about their career. 
We will guide you at every stage; you will also take a mock exam, before the actual certification exam.  However, if you do not clear the FLIP certification exam, you will get one more attempt. You will need to appear for the recertification within one month, to be considered for the program. The re-certification exam will cost Rs. 1500 plus taxes, and will have to be borne by the candidate.</p>
        </div>

        <h5 class="blue font-bold"><span class="paddl-5">19. Where will I get my posting?</span></h5>
        <div class="paddl-20">
           <p>The indicative job locations for each of the job profiles are given below. However, a candidate should be open for a  relocation within a particular region/zone.</p>
                <table border="1" cellpadding="3" cellspacing="1" style="width: 500px;font-family: arial;font-size: 12px;">
                  <tbody>
                    <tr>
                      <td align="center">
                        <strong>Role</strong></td>
                      <td align="center">
                        <strong>Locations</strong>
                        </td>
                    </tr>
                    <tr>
                      <td>
                        Relationship Manager/Sales Manager – Emerging Enterprises Group
                      </td>
                      <td>
                        North, South and West India
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Relationship Manager -Business Banking
                      </td>
                      <td>
                        Andhra Pradesh, Assam, Bihar, Delhi, Gujarat, Haryana, Himachal Pradesh, J&K, Karnataka, Madhya Pradesh, Mumbai and Rest of Maharashtra, NCR, Odisha, Punjab, Rajasthan, Sikkim, Tamil Nadu, Uttar Pradesh and West Bengal
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Trade Sales Manager
                      </td>
                      <td>
                        Ahmedabad, Bangalore, Chandigarh, Chennai, Gurgaon, Hyderabad, Kolkata and Mumbai.
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Branch Relationship Manager
                      </td>
                      <td>
                        Delhi, Gujarat, Karnataka, Mumbai and Rest of Maharashtra.
                      </td>
                    </tr>
                </tbody>
              </table>
        </div>
</div>