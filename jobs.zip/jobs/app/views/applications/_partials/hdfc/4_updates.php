<style type="text/css">p {
    margin: 0 0 10px;
  }
</style>
  <div id="updates" class="tab-pane">   
   <h4 class="red1 font-bold paddb-border">Updates</h4>
    <!-- <h5 class="red1 font-bold">Batch wise status</h5>
    <table border="1" cellpadding="3" cellspacing="1" style="width: 95%;font-family: arial;font-size: 12px;" >
      <tbody>
        <tr style="background:#efefef;font-weight:bold;padding:5px;">
          <td align="center"></td>
          <td align="center">
            <strong>Applications </strong></td>
          <td align="center">
            <strong>Cleared online test</strong></td>
          <td align="center">
            <strong>Interviewed</strong></td>
          <td align="center">
            <strong>Selected</strong></td>
        </tr>
        <tr>
           <td align="center">Batch1</td>
            <td align="center">  115       </td>
          <td align="center">
               73
           </td>
           <td align="center">In process</td> 
           <td align="center"></td> 
        </tr>
        <tr>
            <td align="center">  Batch2  </td>
            <td align="center">  150  </td>
          <td align="center">96</td>
           <td align="center">In process</td> 
           <td align="center"></td> 
        </tr>
        <tr>
            <td align="center"> Batch3  </td>
            <td align="center"> 95 </td>
          <td align="center">60</td>
          <td align="center">In process</td> 
          <td align="center"></td> 
        </tr>
        <tr>
            <td align="center"> Batch4 </td>
            <td align="center"> 78 </td>
          <td align="center">51</td>
          <td align="center"></td> 
          <td align="center"></td> 
        </tr>
        <tr>
            <td align="center"> Batch5 </td>
            <td align="center"> 30 </td>
          <td align="center"></td>
          <td align="center"></td> 
          <td align="center"></td> 
        </tr>
      </tbody>
    </table> -->

    <h5 class="red1 font-bold">
    Conditional Offers - Business Banking/Emerging Enterprise Group: till 11<sup>th</sup> June 2014</h5>
    
     <!--   <div class="col-md-4">
      <h5 class="font-bold" style="margin-bottom:15px;margin-top:15px;"><span class="blue">Batch 3</span> (105 candidates)</h5>
    
      <p><b>22<sup>nd</sup> May</b> - Applications open.</p>
      <p style="margin-bottom:20px;"><b>29<sup>th</sup> May - 1<sup>st</sup> June</b> - Online Test.</p>
    </div>
    
    
    <div class="col-md-4"  style="border-left: 1px solid #d0d0d0;">
      <h5 class="font-bold" style="margin-bottom:15px;margin-top:15px;"><span class="blue">Batch 2</span> (150 candidates)</h5>
    
         <p><b>22<sup>nd</sup> May</b> - Online test started.</p>
     <p><b>25<sup>th</sup> May</b> - Online test completed.</p>
     <p><b>27<sup>th</sup> May</b> - Online test results declared.</p>
     <p><b>28<sup>th</sup> May</b> - Interviews completed for Delhi & Mumbai (EEG & BB).</p>
     <p style="margin-bottom:20px;"><b>30<sup>th</sup> May</b> - Bangalore & Video Interviews Scheduled (EEG & BB).</p>
    </div>
    
      <div class="col-md-4" style="border-left: 1px solid #d0d0d0;">
       <h5 class="font-bold" style="margin-bottom:15px;"><span class="blue">Batch 1</span> (115 candidates)</h5>
    
      <p><b>14<sup>th</sup> May</b> - Batch 1 launched.</p>
    
      <p><b>15<sup>th</sup> May</b> - Online test started.</p>
    
      <p><b>18<sup>th</sup> May</b> - Online test completed.</p>
      <p><b>21<sup>st</sup> May</b> - Online test results declared.</p>
      <p><b>28<sup>th</sup> May</b> - Interviews completed for Delhi & Mumbai (EEG & BB).</p>
      <p><b>30<sup>th</sup> May</b> - Bangalore & Video Interviews Scheduled (EEG & BB).</p>
      </div> -->

   <table border="1" cellpadding="3" cellspacing="1" style="width: 95%;font-family: arial;font-size: 12px;" >
        <thead style="background:#efefef;font-weight:bold;padding:5px;">
          <tr><td align='center' style="padding:7px;">S.N0</td><td>Name</td><td>Business Unit - HDFC Bank</td><td>Business School</td></tr>
        </thead>
        <tbody>
         
<tr><td align='center'>1</td><td>Abhishek Katta</td><td>Emerging Enterprise Group</td><td>Kirloskar Institute of Advanced Management Studies- Pune</td></tr>
<tr><td align='center'>2</td><td>Aditya Das</td><td>Emerging Enterprise Group</td><td>S J Mehta School of Management- IIT Mumbai</td></tr>
<tr><td align='center'>3</td><td>Ajitpal Singh</td><td>Business Banking</td><td>SIBM - Pune</td></tr>
<tr><td align='center'>4</td><td>Amarjyoti Bordoloi</td><td>Emerging Enterprise Group</td><td>Alliance Busines Academy- Bangalore</td></tr>
<tr><td align='center'>5</td><td>Aparna Rakshit</td><td>Business Banking</td><td>National Institute of Financial Management- Faridabad</td></tr>
<tr><td align='center'>6</td><td>Gaurav Agarwal</td><td>Business Banking</td><td>Delhi Technological University</td></tr>
<tr><td align='center'>7</td><td>Himanshu Gaur</td><td>Emerging Enterprise Group</td><td>Christ College of Management- Bangalore</td></tr>
<tr><td align='center'>8</td><td>Himanshu Singh</td><td>Business Banking</td><td>IMT Ghaziabad</td></tr>
<tr><td align='center'>9</td><td>Jeetesh P Menda</td><td>Business Banking</td><td>Xavier Institute of Management and Entrepreneurship, Bangalore</td></tr>
<tr><td align='center'>10</td><td>Jins Thomas</td><td>Business Banking</td><td>SCMS Cochin School of Busines- Kochi</td></tr>
<tr><td align='center'>11</td><td>Khushleen Dhariwal</td><td>Business Banking</td><td>Amity Business School - Noida</td></tr>
<tr><td align='center'>12</td><td>Koushik Das</td><td>Business Banking</td><td>Indian Institute of Management- Raipur</td></tr>
<tr><td align='center'>13</td><td>Manisha Sharma</td><td>Emerging Enterprise Group</td><td>Himachal Pradesh University Business School</td></tr>
<tr><td align='center'>14</td><td>Praneeth Movva</td><td>Business Banking</td><td>Institute of Public Enterprise- Hyderabad</td></tr>
<tr><td align='center'>15</td><td>Prasitha Vairamani</td><td>Emerging Enterprise Group</td><td>PSG Institute of Management- Coimbatore</td></tr>
<tr><td align='center'>16</td><td>Raj Pujara</td><td>Business Banking</td><td>Nirma Institute of Management- Ahmedabad</td></tr>
<tr><td align='center'>17</td><td>Rajbir Singh</td><td>Business Banking</td><td>Nirma Institute of Management- Ahmedabad</td></tr>
<tr><td align='center'>18</td><td>Rapheal Charles P</td><td>Business Banking</td><td>Xavier Institute of Management and Entrepreneurship, Bangalore</td></tr>
<tr><td align='center'>19</td><td>Sandeep Elayidom</td><td>Business Banking</td><td>Sri Sathya Sai Institute of Higher Learning - Anantapur (AP)</td></tr>
<tr><td align='center'>20</td><td>Shashank Mishra</td><td>Emerging Enterprise Group</td><td>Indian School of Mines - Dhanbad</td></tr>
<tr><td align='center'>21</td><td>Shilpa Sharma</td><td>Emerging Enterprise Group</td><td>Amity Global Business School, Chandigarh</td></tr>
<tr><td align='center'>22</td><td>Varun Goel</td><td>Business Banking</td><td>Department of Management Studies- IIT Roorkee</td></tr>
<tr><td align='center'>23</td><td>Nikunj Goyal</td><td>Emerging Enterprise Group</td><td>Chartered Accountant</td></tr>
<tr><td align='center'>24</td><td>Saket Deepak</td><td>Business Banking</td><td>SIBM - Bangalore</td></tr>
<tr><td align='center'>25</td><td>Rohan Vohra</td><td>Business Banking</td><td>SIMS - Pune</td></tr>
<tr><td align='center'>26</td><td>Pradeepa S</td><td>Emerging Enterprise Group</td><td>Pondicherry University</td></tr>
<tr><td align='center'>27</td><td>Sneha Thacker</td><td>Business Banking</td><td>Symbiosis School Of Banking Management - Pune</td></tr>
<tr><td align='center'>28</td><td>Gokullnath R</td><td>Business Banking</td><td>Bharathiar School of Management and Entrepreneur Development- Coimbatore</td></tr>
<tr><td align='center'>29</td><td>Yogeshwr Prakaash</td><td>Business Banking</td><td>IBS Bangalore</td></tr>
<tr><td align='center'>30</td><td>Rohit Oberoi</td><td>Business Banking</td><td>University Business School - Chandigarh</td></tr>
<tr><td align='center'>31</td><td>Abhay Sawhney</td><td>Business Banking</td><td>Foundation for Organisational Research  Education School of Management - New Delhi</td></tr>
<tr><td align='center'>32</td><td>Mirza Monis Beg</td><td>Business Banking</td><td>IILM Graduate School of Management, Greater Noida </td></tr>
<tr><td align='center'>33</td><td>Mohit Maheshwari</td><td>Business Banking</td><td>Chartered Accountant</td></tr>
<tr><td align='center'>34</td><td>Akshay Raunak</td><td>Business Banking</td><td>K.J.Somaiya Institute of Management Studies & Research- Mumbai</td></tr>
<tr><td align='center'>35</td><td>Monika Sharma</td><td>Emerging Enterprise Group</td><td>Chartered Accountant</td></tr>
<tr><td align='center'>36</td><td>Mayank Malhotra</td><td>Business Banking</td><td>Institute of Management Technology(IMT)- Ghaziabad</td></tr>
<tr><td align='center'>37</td><td>Deepak Sharma</td><td>Emerging Enterprise Group</td><td>Poornima School of Management (RTU) - Jaipur</td></tr>
<tr><td align='center'>38</td><td>Ritesh Bhatnagar</td><td>Emerging Enterprise Group</td><td>Amity Business School Noida</td></tr>
<tr><td align='center'>39</td><td>Zuhair Rizvi</td><td>Emerging Enterprise Group</td><td>Department of Business Administration- Lucknow</td></tr>
<tr><td align='center'>40</td><td>Manmeet Malik</td><td>Emerging Enterprise Group</td><td>Symbiosis School Of Banking Management - Pune</td></tr>
<tr><td align='center'>41</td><td>Gopala Krishnan</td><td>Emerging Enterprise Group</td><td>Institute of Public Enterprise - Hyderabad</td></tr>
<tr><td align='center'>42</td><td>Milind Kasi</td><td>Emerging Enterprise Group</td><td>Faculty of Management Studies, BHU</td></tr>
<tr><td align='center'>43</td><td>Bharti Thakur</td><td>Emerging Enterprise Group</td><td>Institute of Financial Management and Research- Chennai</td></tr>
<tr><td align='center'>44</td><td>Karthik Chandran</td><td>Emerging Enterprise Group</td><td>Symbiosis School Of Banking Management - Pune</td></tr>
<tr><td align='center'>45</td><td>Nitin Kadam</td><td>Emerging Enterprise Group</td><td>Indira Institute of Business Management, Mumbai University</td></tr>
<tr><td align='center'>46</td><td>Mohit Wadhwani</td><td>Emerging Enterprise Group</td><td>Institute For Technology & Management- Mumbai</td></tr>
<tr><td align='center'>47</td><td>Mrunalini Kurkure</td><td>Business Banking</td><td>Indian Institute Of Management- Calcutta</td></tr>
<tr><td align='center'>48</td><td>Sameer Wankhare</td><td>Business Banking</td><td>SIMS - Pune</td></tr>

        </tbody>
    </table>

</div>