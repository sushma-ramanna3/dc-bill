  <div id="apply" class="tab-pane"> 
        @if($errors->has())
        <div id="form-errors" class="red">
          <p>The following errors have occurred:</p>
          <ul>
            @foreach($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div><!-- end form-errors -->
        @endif
        @if(Session::get('successful'))
        <div class="col-md-12 font-bold font-14 padd_null text-center panel panel-default" id="success-message">
          <div class="panel-heading">
            <p class="text-center" style="display:inline">Your have successfully applied for this job. Please check your mail for details. </p>
          </div>
         </div>
        @endif
        <form class="form-horizontal col-md-12" action="/hdfcApplications" method="post" enctype="multipart/form-data" id="appform">
            <fieldset id="fieldsetappend" >

            <!-- Form Name -->
            <h4 class="paddb-border red1 font-bold">Application Form</h4>
            <div class="form-group">
              <div class="col-md-12">
                  <p>Please fill the form to apply for the job & pay the registration fee of INR 750. Get your credit/debit card or internet banking details ready to proceed with the online payment.</p>
              </div>
              <div class="col-md-5">
                {{ 'Fields marked as <span class="red1 font-bold"> *</span> are mandatory' }}
              </div>
            </div>
            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="first_name">First Name<span class="red1 font-bold"> *</span> </label>  
              <div class="col-md-5">
              {{ Form::text('first_name', null, array('class'=>'form-control input-md','placeholder'=>'enter your first name', 'required' => 'true', 'id' => 'first_name')) }}
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="last_name">Last Name<span class="red1 font-bold"> *</span></label>  
              <div class="col-md-5">
              {{ Form::text('last_name', null, array('class'=>'form-control input-md','placeholder'=>'enter your last name', 'required' => 'true', 'id' => 'last_name')) }}  
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="email">Email ID<span class="red1 font-bold"> *</span></label>  
              <div class="col-md-5">
              {{ Form::email('email', null, array('class'=>'form-control input-md','placeholder'=>'enter your email', 'required' => 'true')) }}  
                
              </div>
            </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="phone">Phone Number<span class="red1 font-bold"> *</span></label>  
            <div class="col-md-5">
              {{ Form::text('phone', null, array('class'=>'form-control input-md','placeholder'=>'phone number','maxlength'=>'10', 'required' => 'true', 'id' => 'phone_number', 'required'=>'required')) }}      
            </div>
          </div>

          <!-- Select Basic -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="dob">Date of Birth( dd-mm-yyyy )<span class="red1 font-bold"> *</span></label>
            <div class="col-md-2 pull-left">
              {{ Form::selectRange('dob_day', 1, 31, null, array('class'=>'form-control')); }}
            </div>
            <div class="col-md-2 pull-left">
              {{ Form::selectRange('dob_month', 1, 12, null, array('class'=>'form-control')); }}
            </div>
            <div class="col-md-2 pull-left">
              {{ Form::selectRange('dob_year', 1975, 2010, null, array('class'=>'form-control')); }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="tenth">10th<span class="red1 font-bold"> *</span></label>  
            <div class="col-md-2">
            {{ Form::text('sslc_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage','required' => 'true', 'id' => 'sslc_percentage')) }}      
            </div>
            <div class="col-md-3">
              {{ Form::text('sslc_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion', 'required' => 'true', 'id' => 'sslc_year')) }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="twelfth">12th<span class="red1 font-bold"> *</span></label>  
            <div class="col-md-2">
            {{ Form::text('puc_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage','required' => 'true', 'id' => 'puc_percentage')) }}
            </div>
            <div class="col-md-3">
              {{ Form::text('puc_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion','required' => 'true', 'id' => 'puc_year')) }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="graduation">Graduation<span class="red1 font-bold"> *</span></label>  
            <div class="col-md-2">
            {{ Form::text('graduation_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage','required' => 'true',  'id' => 'graduation_percentage')) }}
            </div>
            <div class="col-md-3">
              {{ Form::text('graduation_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion','required' => 'true',  'id' => 'graduation_year')) }}
            </div>
            <div class="col-md-2">
            {{ Form::select('graduation_stream', array('' => '--Course--', 'BE' => 'B.E', 'BSC' => 'B.Sc', 'BA' => 'BA', 'BCOM' => 'B.Com', 'BBM' => 'BBM', 'B.Tech' => 'B.Tech', 'Others' => 'Others'), '--Course--', array('class'=> 'form-control input-md','required' => 'true')) }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="post_graduation"> Post Graduation Specialization<span class="red1 font-bold"> *</span></label>  
           <div class="col-md-3">
            {{ Form::select('post_graduation_stream',  array('' => 'Please Select Course', 'CA' => 'CA', 'MBA Finance' => 'MBA Finance', 'MBA Marketing' => 'MBA Marketing', 'MBA Human Resource' => 'MBA Human Resource', 'MBA Operations, Systems' => 'MBA Operations, Systems', 'MBA International Finance' => 'MBA International Finance', 'MBA Banking & Insurance' => 'MBA Banking & Insurance', 'MBA - Others' => 'MBA - Others'), '--Course--', array('class'=> 'form-control input-md', 'id' => 'post_graduation_stream', 'required'=>'required' )) }}
            </div>
           
            <div class="col-md-2 none">
            {{ Form::text('others_specialization', null, array('class'=>'form-control input-md','placeholder'=>'Others', 'id' => 'others_specialization')) }}        
            </div>

            <div class="col-md-4 none2">
            {{ Form::select('attempts', array('' => '--Attempts--', '2' => '2', '3' => '3', '4' => '4', '5' => '5', 'More than 5' => 'More than 5'), '--Attempts--', array('class'=> 'form-control input-md', 'id' => 'attempts')) }}        
              <span class="red1 align_center"><small>(Total number of attempts including Inter & Final)</small></span>
            </div>

            <div class="col-md-3 none1">
            {{ Form::select('result_status', array('' => '--Result Status--', 'Result Declared' => 'Result Declared', 'Result Awaited' => 'Result Awaited'), '----Result Status----', array('class'=> 'form-control input-md', 'id'=>'result_status')) }}        
            </div>

          </div>

          <div class="form-group none1">
           <label class="col-md-4 control-label" for="post_graduation"> Post Graduation<span class="red1 font-bold"> *</span><br><small>(Only 2 year full time course is applicable)</small></label>  
            <div class="col-md-2">
            {{ Form::text('post_graduation_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage', 'id' => 'post_graduation_percentage')) }}        
            </div>

            <div class="col-md-2">
              {{ Form::text('post_graduation_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion', 'id' => 'post_graduation_year')) }}
            </div>
             <div class="col-md-3">
              {{ Form::select('post_graduation_college', $college_list, Input::old('post_graduation_college'), array('class' => 'form-control input-md','id' => 'post_graduation_college')) }}

            </div>
          </div>
          <div class="form-group none_agg">
            <label class="col-md-4 control-label" for="post_graduation"></label>
            <div class="col-md-8 red1"><small>(In case of result awaited, please fill the aggregate percentage till date)</small></div>
          </div>
          <!-- Text input-->
          <div class="form-group other_colleges">
            <label class="col-md-4 control-label" for="other-colleges"></label>  
            <div class="col-md-7">
            {{ Form::text('other_colleges', null, array('class'=>'form-control input-md','placeholder'=>'please enter college name', 'id' => 'other_colleges')) }}
            </div>
          </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="home_location">Home Location<span class="red1 font-bold"> *</span> </label>  
              <div class="col-md-5">
              {{ Form::text('home_location', null, array('class'=>'form-control input-md','placeholder'=>'enter your home location (City, State)', 'required' => 'true', 'id' => 'home_location')) }}
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="current_location">Current Location<span class="red1 font-bold"> *</span> </label>  
              <div class="col-md-5">
              {{ Form::text('current_location', null, array('class'=>'form-control input-md','placeholder'=>'enter your current location (City, State)', 'required' => 'true', 'id' => 'current_location')) }}
              </div>
            </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="preferred_interview_location">Preferred Interview Location<span class="red1 font-bold"> *</span></label>  
            <div class="col-md-7">
            {{ Form::select('preferred_interview_location', $location['preferred_job_location'] , Input::old('preferred_interview_location'), array('class' => 'form-control input-md preferred_interview_location', 'required' => 'true', 'id' => 'preferred_interview_location')) }}
            </div>
          </div>

          <!-- File Button --> 
          <div class="form-group" style="margin-top: 10px;">
            <label class="col-md-4 control-label" for="resume">Upload Resume<span class="red1 font-bold"> *</span></label>
            <div class="col-md-4">
              {{ Form::file('resume', array('id'=>'resume')) }}
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" for="workex" > Work Experience<span class="red1 font-bold"> *</span><br><small>(Post MBA/PGDM/CA)</small></label>
            <div id="append-div">
              <div class="col-md-4">
              <select class="form-control input-md" name="work_experience" required>
                <option value="">--Select--</option>
                <option value="0">Fresher</option>
                <option value="0-1 Year (BFSI - Sales)">0-1 Year (BFSI - Sales)</option>
                <option value="0-1 Year ( Other - Sales)">0-1 Year ( Other - Sales)</option>
                <option value="0-1 Year (BFSI - Non Sales)">0-1 Year (BFSI - Non Sales)</option>
                <option value="1-2 Years (BFSI - Sales)">1-2 Years (BFSI - Sales)</option>
                <option value="1-2 Years ( Other - Sales)">1-2 Years ( Other - Sales)</option>
                <option value="1-2 Years (BFSI - Non Sales)">1-2 Years (BFSI - Non Sales)</option>
                <option value="More than 2 Years">More than 2 Years</option>
              </select>
              </div>
            </div>
          </div>
          <div id="workexappend"></div>

        <!-- Text input-->
        <div class="form-group">
          <label class="col-md-4 control-label" for="preferred_job_location_1">Preferred Job Location<span class="red1 font-bold"> *</span> <br> <small>(In order of priority)</small> </label>
          <div class="col-xs-1 preferred-job-location">
          	1.
          </div>
          <div class="col-md-4">
          {{ Form::text('preferred_job_location_1', null, array('class'=>'form-control input-md','placeholder'=>'enter location 1', 'required' => 'true', 'id' => 'preferred_job_location_1')) }}
          </div>
        </div>

        <div class="form-group">
          <label class="col-md-4 control-label" for="preferred_job_location_2"></label>
          <div class="col-xs-1 preferred-job-location">
          	2.
          </div>
          <div class="col-md-4">
          {{ Form::text('preferred_job_location_2', null, array('class'=>'form-control input-md','placeholder'=>'enter location 2', 'required' => 'true', 'id' => 'preferred_job_location_2')) }}
          </div>
        </div>

        <div class="form-group">
          <label class="col-md-4 control-label" for="preferred_job_location_3"></label>
          <div class="col-xs-1 preferred-job-location">
          	3.
          </div>
          <div class="col-md-4">
          {{ Form::text('preferred_job_location_3', null, array('class'=>'form-control input-md','placeholder'=>'enter location 3', 'required' => 'true', 'id' => 'preferred_job_location_3')) }}
          </div>
        </div>

           <div class="form-group">
            <label class="col-md-4 control-label" for="relocation" >Are you willing to relocate?<span class="red1 font-bold"> *</span></label>
              <div class="col-md-3">
              <select class="form-control input-md" name="relocate" id="relocate" required>
                <option value="">--Select--</option>
                <option value="Yes, anywhere in India">Yes, anywhere in India</option>
                <option value="Yes, within zone - North">Yes, within zone - North</option>
                <option value="Yes, within zone - South">Yes, within zone - South</option>
                <option value="Yes, within zone - West">Yes, within zone - West</option>
                <option class="none" id="east" value="Yes, within zone - East">Yes, within zone - East</option>
                <option value="No">No</option>
              </select>
              </div>

               <div class="job6">
              <label class="col-md-2 control-label" style="padding-left: 0px;padding-right: 0px;" for="relocation" >Preferred state/location<span class="red1 font-bold"> *</span></label>
                 <div class="col-md-3">
                  <select class="form-control input-md" name="relocation_specific[]" id="relocation_specific6">
                    <option value="">--Select--</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Gujarat">Gujarat</option>

                    <option value="Haryana">Haryana</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>

                    
                    <option value="Mumbai">Mumbai</option>
                    <option value="Rest of Maharashtra">Rest of Maharashtra</option>
                    <option value="NCR">NCR</option>
                    <option value="Odisha">Odisha</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Rajasthan">Rajasthan</option>

                    <option value="Sikkim">Sikkim</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="West Bengal">West Bengal</option>

                  </select>
                 </div>
              </div>

                <div class="job4">
                 <label class="col-md-2 control-label" style="padding-left: 0px;padding-right: 0px;" for="relocation" >Preferred state/location<span class="red1 font-bold"> *</span></label>
                 <div class="col-md-3">
                  <select class="form-control input-md" name="relocation_specific[]" id="relocation_specific4">
                    <option value="">--Select--</option>
                    <option value="Ahmedabad">Ahmedabad</option>
                    <option value="Bangalore">Bangalore</option>
                    <option value="Chandigarh">Chandigarh</option>
                    <option value="Chennai">Chennai</option>
                    <option value="Gurgaon">Gurgaon</option>
                    <option value="Hyderabad">Hyderabad</option>
                    <option value="Kolkata">Kolkata</option>
                    <option value="Mumbai">Mumbai</option>
                  </select>
                 </div>
              </div>


                <div class="job5">
                 <label class="col-md-2 control-label" style="padding-left: 0px;padding-right: 0px;" for="relocation" >Preferred state/location<span class="red1 font-bold"> *</span></label>
                 <div class="col-md-3">
                  <select class="form-control input-md" name="relocation_specific[]" id="relocation_specific5">
                    <option value="">--Select--</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Mumbai">Mumbai</option>
                     <option value="Rest of Maharashtra">Rest of Maharashtra</option>
                  </select>
                 </div>
              </div>
          </div>
  
     
        
         <div class="form-group">
            <label class="col-md-4 control-label" for="resume">Have you attended HDFC Bank selection process in last 3 months?<span class="red1 font-bold"> *</span></label>
            <div class="col-md-4" style="margin-top:15px;">
              {{ Form::label('yes','Yes') }}
              {{ Form::radio('attended','1','',array('id'=>'yes', 'required'=>'required')) }}
              {{ Form::label('no','No') }}
              {{ Form::radio('attended','0','',array('id'=>'no', 'required'=>'required')) }}
            </div>
          </div>

          <input id="job_id" name="job_id" type="hidden" value="<?php echo $location['id']; ?>" >
            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label" for="submit"></label>
              <div class="col-md-2">
                <button id="submit" name="submit" class="btn btn-lg btn-success btn-block button-padd"> Proceed </button>
              </div>
            </div>
          </fieldset>
        </form>

</div>

<form action="/showquestionnarie" method="post" id="Questionnaire">
    <input id="job_id" name="job_id" type="hidden" value="<?php echo $location['id']; ?>" >
    <input id="application_id" name="application_id" type="hidden" value="" >
    <input id="qsubmit" name="qsubmit" type="submit" style="display:none;">

</form>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Sorry, you are not eligible for the job.</h4>
      </div>
      <div class="modal-body">
        <p>
          Eligibility criteria - 
        </p>
        <ul>
          <li>Maximum age - 28 years</li>
          <li>50% across 10, 12, graduation and post graduation</li>
          <li>You are not eligible if you are MBA - HR/Systems/Operations</li>
          <li>For CA - maximum number of attempts should be less than equal to 5</li>
          <li>Work experience should be less than or equal to 1</li>
          <li>You should not have participated in HDFC selection process in last 3 months</li>
        </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="appliedModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title red1" id="myModalLabel">Note: </h4>
      </div>
      <div class="modal-body">
        <p>
          We see that you have already applied to this job. <br>
          <a href="/track">Click here</a> to track your application.
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="validatorModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title red1" id="myModalLabel">Error: </h4>
      </div>
      <div class="modal-body">
        <ul>
          <li>Please fill all mandatory fields and make sure you providing valid data</li>
          <li>First name should contain minimum of 3 characters</li>
          <li>The last name may only contain one word and <b>only letters</b></li>
          <li>Valid 10 digit phone number</li>
          <li>If you are entering <b>CGPA</b> then <b>convert it to percentage</b> and proceed</li>
          <li>Valid graduation/post-graduation passed out year</li>
        </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>

<script>
  (function($) {
    $id = <?php echo $location['id']; ?>;

    if($id == 5 || $id == 4) $("#post_graduation_stream option[value='CA']").remove();

    $('#post_graduation_college').change(function() {
        if($("#post_graduation_college option:selected").text() == 'Others') {
          $('.other_colleges').css({'display':'block'});
          $('#other_colleges').attr('required','required');
        }else{
          $('.other_colleges').css({'display':'none'});
          $('#other_colleges').removeAttr('required','required');
        }
    });

    $('#graduation_percentage, #post_graduation_percentage').on('keyup', function (e) {
        if (e.which === 46) return false;
    }).on('input', function () {
        var self = this;
        setTimeout(function () {
            if (self.value.indexOf('.') != -1){
                self.value = parseInt(self.value, 10);
                alert('If you anvert it to percentage and proceed');
            }
        }, 0);
    });

    $('.none, .none1, .none2, .other_colleges, .none_agg, .job6, .job5, .job4').css({'display':'none'});

    if($id == 6 || $id == 4) $('#east').css({'display':'block'});

    if($id != 7){
      $('#relocate').change(function() {
        if($("#relocate option:selected").text() == 'No') {
          if($id == 6){  
            $('.job6, #east').css({'display':'block'});
            $('#relocation_specific6').attr('required','required');
          }
          if($id == 5) {
             $('#relocation_specific5').attr('required','required');
            $('.job5').css({'display':'block'});
          }
          if($id == 4){
            $('#relocation_specific4').attr('required','required');
            $('.job4, #east').css({'display':'block'});
         }
        }
        else{
          $('.job6, .job5, .job4').css({'display':'none'});
          $('#relocation_specific4, #relocation_specific5, #relocation_specific6').val('');
        }
      });

    }

    $('#result_status').change(function() {
      if($("#result_status option:selected").text() == 'Result Awaited')  $('.none_agg').css({'display':'block'});
      else $('.none_agg').css({'display':'none'});
    });

    $('#post_graduation_stream').change(function() {
      if($("#post_graduation_stream option:selected").text() == 'MBA - Others') {
        $('.none, .none1').css({'display':'block'});
        $('.none2').css({'display':'none'});
        $('#post_graduation_percentage, #post_graduation_year, #post_graduation_college, #others_specialization, #result_status').attr('required','required');
        $('#attempts').removeAttr('required');
        $("#post_graduation_college option:first").val('');
        
      }
      else if($("#post_graduation_stream option:selected").text() != 'Please Select Course' && $("#post_graduation_stream option:selected").text() != 'CA' && $("#post_graduation_stream option:selected").text() != 'MBA - Others') {
        $('.none1').css({'display':'block'});
        $('.none2').css({'display':'none'});
        $('.none').css({'display':'none'});
        $("#post_graduation_college option:first").val('');

        $('#post_graduation_percentage, #post_graduation_year, #post_graduation_college, #result_status').attr('required','required');
        $('#others_specialization, #attempts').removeAttr('required');
        
      }
      else if($("#post_graduation_stream option:selected").text() == 'CA') {
        $('.none2').css({'display':'block'});
        $('.none, .none1').css({'display':'none'});
        $('#attempts').attr('required','required');
        $('#post_graduation_percentage, #post_graduation_year, #post_graduation_college, #others_specialization, #result_status').removeAttr('required');
      }else if($("#post_graduation_stream option:selected").text() == 'Please Select Course') {
         $('.none1, .none2, .none').css({'display':'none'});
      }
      else{
        $('.none, .none1, .none2').css({'display':'none'});
      }
    });

   })(jQuery);

</script>