    <style type="text/css">
      #scroller img{
        width: 82px;
        height: 84px;
        border: 1pt solid #d0d0d0;
      }
      #scroller1 li{
        border: 2px solid #d0d0d0;
        padding: 10px;
        width: 350px;
        height: 99px;
        display: block;
      }
      #scroller1 li span.name{
        font-weight: bold;
        display: block;
        text-align: center;
      }
      #scroller1 li span.text{
         height: 49px;
         display: block;
      }
    </style>
    <div class="col-md-12 border padd-15">
      <div class="col-md-2 marg-cust pull-left align_center"> 
        <h4 ><b>FLIP Certified Professionals:</b></h4>
      </div>
      <div class="hscroll">
        <ul id="scroller" class="align_center">
          <li><img src="/assets/images/16399_Anil-Dasa.jpg" /><span>Anil Dasa</span><br>YES Bank<br>IIM-L</li>
          <li><img src="/assets/images/4172_Anurag-Ghosh.jpg" /><span>Anurag Ghosh</span><br>HDFC Bank <br>XIM-B</li>
          <li><img src="/assets/images/16352_Archie-Gangrade.jpg" /><span>Archie Gangrade</span><br>HDFC Bank <br> IIFT Kolkata </li>
          <li><img src="/assets/images/15829_Narendra-Ahuja.jpg" /><span>Narendra Ahuja</span><br>HDFC Bank <br> JBIMS </li>
          <li><img src="/assets/images/16235_Rahul-Mahajan.jpg" /><span>Rahul Mahajan</span><br>HDFC Bank <br> Sydenham </li>
          <li><img src="/assets/images/6372_Swati-Singh.jpg" /><span>Swati Singh</span><br>YES Bank <br>IMT-G </li>
          <li><img src="/assets/images/28919_Rahul-Kolhe.jpg" /><span>Rahul Kolhe</span><br>YES Bank <br>JBIMS
 </li>
          <li><img src="/assets/images/27198_Nupur-Bansal.jpg" /><span>Nupur Bansal</span><br>YES Bank <br>NMIMS </li>
          <li><img src="/assets/images/17037_Dikins-Kumar.jpg" /><span>Dikins Kumar</span><br>YES Bank <br>FMS </li>
          <li><img src="/assets/images/15438_Ankur-Dubey.jpg" /><span>Ankur Dubey</span><br>YES Bank <br> IIM Raipur</li>
          <li><img src="/assets/images/16328_Felix-Jesudass.jpg" /><span>Felix Jesudass</span><br>YES Bank <br> SIBM Pune </li>
          <li><img src="/assets/images/16754_Shruti-Dadu.jpg" /><span>Shruti Dadu</span><br>HDFC Bank <br> SIBM Pune </li>
          <li><img src="/assets/images/15722_Tania-Sethi.jpg" /><span>Tania Sethi</span><br>HDFC Bank <br> MFC Delhi </li>
          <li><img src="/assets/images/18194_Tarun-Gupta.jpg" /><span>Tarun Gupta</span><br>YES Bank <br> NMIMS </li>
          <li><img src="/assets/images/27094_Prakash-Nishtala.jpg" /><span>Prakash Nishtala</span><br>YES Bank <br> NMIMS</li>
        </ul>           
      </div>
    </div>

    <div class="col-md-12 border padd-15">
      <div class="col-md-2 marg-cust pull-left align_center"> 
        <h4 style="padding: 25.6% 0;" ><b>Testimonials</b></h4>
      </div>
      <div class="hscroll">
        <ul id="scroller1" class="align_center">
          <li><span class="text">"I had taken the FLIP Corporate Banking.......... I found the course in itself is highly relevant for placements….."</span><br>
          <span class="name">Ankur Ghosh, IMT, Ghaziabad</span></li>
          <li><span class="text">"FLIP Certification actually opens the door in the arena of Finance ............ Without FLIP I could have never got 3 PPOs and a choice to make of my own."</span>
            <br><span class="name">Archie, IIFT, Kolkata</span></li>
          <li><span class="text">"I am in HDFC with the team mates from ISB, IIM A & IIM B. And I got this opportunity through FLIP. Apart from this I endorse the quality of the presentation & study material FLIP provides."</span>
            <br><span class="name">Mayank Gupta, IIFT, Kolkata</span></li>
          <li><span class="text">"FLIP’s course content was almost exhaustive. So, any companies hiring, asked questions usually limited to the course content of FLIP."</span>
            <br><span class="name">Ananya Roy, IIM Shillong</span></li>
        </ul>           
      </div>
    </div>

<script type="text/javascript">

  $(document).ready(function() {

   $("#scroller1").simplyScroll();

  });

</script>