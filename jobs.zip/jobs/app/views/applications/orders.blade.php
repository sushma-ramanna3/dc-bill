@extends('layouts.main')
@section('content')
 
  <h1>Order Details</h1>
  @if(HTML::ul($errors->all()))
    <div id="form-errors" class="alert alert-block red">
      {{ Session::get('error') }} 
      {{ HTML::ul($errors->all()) }}
    </div>
  @elseif(Session::get('success'))
    <div class="alert alert-info alert-block alert-dismissable">
      {{ Session::get('success') }} 
    </div>
  @elseif(Session::get('message')) 
    <div class="alert alert-info alert-block">
      {{ Session::get('message') }} 
    </div>
  @elseif(Session::get('warning')) 
    <div class="alert alert-warning alert-block">
      {{ Session::get('warning') }} 
    </div>
     @endif

  <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
    <li class="active"><a href="#hdfc" data-toggle="tab">Orders</a></li>
    <li ><a href="update-order-status">Update Orders</a></li>
    <li class="users"><a href="hdfc">Back</a></li>
  </ul>

<div id="my-tab-content" class="tab-content">
    <div id="hdfc" class="tab-pane active">   
     <?php 
        $page = Input::get('page', 1);
        $i = (15 * ($page -1)) + 1;
      ?>
      {{$orders->links()}}

      <table class="table table-striped table-bordered marg-top">
        <thead>
          <tr>
            <td>Sl.No.</td>
            <td>User ID</td>
            <td>Application ID</td>
            <td>Name</td>
            <td>Email</td>
            <td>Phone</td>
            <td>Order Status</td>
            <td>Transaction Date</td>
            <td>Print</td>
          </tr>
        </thead>
        <tbody>

          @foreach($orders as $key => $order)
            <tr>
              <td>{{ $i++ }}</td>
              <td>{{ $order->user_id }}</td>
              <td>{{ $order->application_id }}</td>
              <td>{{ $order->first_name.' '.$order->last_name }}</td>
              <td>{{ $order->email }}</td>
              <td>{{ $order->phone }}</td>
              @if($order->status == 'C')
              <td>{{ 'Confirmed' }}</td>
              @endif
              <td>{{ $order->updated_at }}</td>
              <td>{{ "<a href=\"/orders/". $order->application_id ."\" target=\"_blank\"><span class=\"glyphicon glyphicon-print\"></span></a>" }}</td>
            </tr>
          @endforeach

        </tbody>
      </table>
    </div>

 </div>

@stop