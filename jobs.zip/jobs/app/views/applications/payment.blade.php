@extends('layouts.main')

@section('content')

@if($response['transaction_response_code'] == 'SUCCESS')
  <div class="alert alert-success ">
    <p>You have successfully registered for this job application. <br>
    <span style="color:rgb(184, 33, 33);" >Next step:</span> You will receive online test details shortly from HDFC Bank. Please check your inbox/mails regularly.
    </p>
    <!-- <p>Your transaction is successful.  Thank you for your payment.</p> -->
  </div>
  <p style="padding-left:8px;padding-top:10px;"><a href="http://jobs.learnwithflip.com/track"><u>Click here</u></a> to track your application status. </p>
@endif
@if($response['transaction_response_code'] != 'SUCCESS')
  <div class="alert alert-danger ">
    <p>Your transaction is un-successful. </p>
  </div>
@endif

<div class="panel panel-default">
  <div class="panel-heading">Payment Details <a href="javascript:window.print()" style="float: right">Click to Print This Page</a></div>
  <div style="margin: 20px;">
    FLIP <br>
    #597, First Floor, 4th Main, <br>
    11th Cross, Gokulam 3rd Stage, <br>
    Mysore, 570002 <br>
    Service Tax Regn. No: AABCF3241JSD001 <br>
  </div>
  <hr>
  <table style="margin: 13px;width:40%">
  <thead>
    <tr>
      <th>Transaction Information </th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td> Transaction Status </td>
      <td> {{ $response['transaction_response_message'] }} </td>
    </tr>
    <tr>
    <td> Transaction ID </td>
      <td> {{ $response['merchant_transaction_id'] }} </td>
    </tr>
    <tr>
      <td> Transaction Date and Time </td>
      <td> {{ $response['transaction_time'] }} </td>
    </tr>
    @if($response['payment_method']=='CREDIT')
    <tr>
      <td> Payment Method </td>
      <td> Debit / Credit Card </td>
    </tr>
    @endif
  </tbody>
  </table>
  <hr>
  <table style="margin: 13px;width: 74%;">
    <thead>
      <tr>
        <th>User Information</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Name</td>
        <td>{{ $user[0]->first_name.' '.$user[0]->last_name }}</td>
      </tr>
      <tr>
        <td>Email ID</td>
        <td>{{ $user[0]->email }}</td>
      </tr>
      <tr>
        <td>Phone Number</td>
        <td>{{ $user[0]->phone }}</td>
      </tr>
      <tr>
        <td>Product</td>
        <td>Relationship Manager Program [Registration Fee]</td>
      </tr>
    </tbody>
  </table>
  <hr>
  <div style="margin: 20px;">
    Amount - INR 667.50 <br>
    Tax - INR 82.50 <br>
    Total Amount - INR 750.00
  </div>
  <!-- <p style="padding-left:8px;padding-top:15px;"><b>Please check your mail for further instructions and check your application status /b></p> -->
</div>
@stop