@extends('layouts.custom1')
@section('content')
  
  	<div class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="http://www.learnwithflip.com" target="_blank"><img src="/assets/images/fliplogo.png" alt="logo"></a>
          <ul class="nav navbar-nav col-md-7 align_center margin-navbar pull-left headerwidth"><h1 id="job_page_title" style="font-size: 37px;">Job Opening : Market Analyst (Non-Sales Role)</h1></ul>
        </div>
      </div>
    </div>

       <ul class="nav nav-pills padd-15" data-tabs="tabs" id="nav_li" style="padding-left:65px;">   
        <li class="about"><a href="/IIFL/3/#about" >Role / Eligibility</a></li>  
        <li class="apply active"><a href="/IIFL/3/#apply" style=" background:#EE0000;" data-toggle="tab">Apply</a></li>   
        <li class="last-item"><a href="/IIFL/3/#contact" >Contact Us</a></li>
      </ul>  

    	<div id="my-tab-content" class="tab-content padd-15 border-top">

		 	<div id="about" class="tab-pane">   
		    </div>

	    	<div id="apply" class="tab-pane"> 
	        	<div class="col-md-12 font-bold font-14 padd_null text-center panel panel-default" id="success-message">
		          <div class="panel-heading">
		            <p class="text-center" style="display:inline">You have successfully applied for this job. We will shortly get in touch with you. </p>
		            <p style="margin-top:15px;"><a style="background: #EE0000;" class="cust_apply" href="https://www.learnwithflip.com/buy-now.html?category_id=2715&category=Wealth-Management" target="_blank">Click here</a> to enrol for Wealth Management Certification Program.</p>
		          </div>
		        </div>
	        </div>
	        
	 		<div id="contact" class="tab-pane text-center"> </div>
		</div>

<style>
   #nav_li>li {
    background: #001E74;
    width: 265px;
    text-align: center;
  }
 #nav_li>li.active>a, #nav_li>li.active>a:hover, #nav_li>li.active>a:focus, #nav_li>li a:hover {
    color: #fff;
    background-color:#EE0000;
  }
  
</style>

<script type="text/javascript">

    $(document).ready(function() {
        document.title = 'Market Analyst (Non-Sales Role)';
    });

</script>
    <img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
    <a style="top:330px;position:fixed;right:-7px;" href="https://www.facebook.com/learnwithflip" target="_blank"><img class="fb" style="width:58px;height:80px :hover {opacity:0.4;}" src="/assets/images/Facebook_icon.png" border="0"></a>
    <a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>


	<!-- Google Code for Sign Up Conversion Page -->
	<script type="text/javascript">
		/* <![CDATA[ */
		var google_conversion_id = 977955575;
		var google_conversion_language = "en";
		var google_conversion_format = "2";
		var google_conversion_color = "ffffff";
		var google_conversion_label = "YAtnCNHc9AcQ99Wp0gM";
		var google_conversion_value = 0;
		var google_remarketing_only = false;
		/* ]]> */
	</script>

	<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script>
	
	<noscript>
		<div style="display:inline;">
			<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/977955575/?value=0&amp;label=YAtnCNHc9AcQ99Wp0gM&amp;guid=ON&amp;script=0"/>
		</div>
	</noscript>

@stop
