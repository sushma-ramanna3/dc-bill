@extends('layouts.custom1')
@section('content')
  
    <div class="col-md-12 img_w padd_null"><img src="/assets/images/banner2.jpg" alt="banner" name="banner"/></div>
  
      <ul class="nav nav-pills padd-15" data-tabs="tabs" id="nav_li">  
        <li class="active intro"><a href="/guaranteed-interview/AR/2#intro" >Introduction</a></li>     
        <li class="about"><a href="/guaranteed-interview/AR/2#about" >Role / Eligibility</a></li>  
        <li class="sales"><a href="/guaranteed-interview/AR/2#program" >Program Details</a></li>   
        <li class="apply"><a href="/guaranteed-interview/AR/2#apply" >Apply</a></li>   
        <li class="faq"><a href="/guaranteed-interview/AR/2/#faq" >FAQs</a></li> 
        <li class="last-item contact"><a href="/guaranteed-interview/AR/2/#contact" >Contact Us</a></li>   
      </ul>  

    	<div id="my-tab-content" class="tab-content padd-15 border-top">

		 	<div id="intro" class="tab-pane active"> 
		 	</div>

		    <div id="about" class="tab-pane">   
		    </div>
	      
		    <div id="program" class="tab-pane">   
		    </div>
	      
	    	<div id="apply" class="tab-pane"> 
	        	<div class="col-md-12 font-14 padd_null panel panel-default" id="success-message">
		          <div class="panel-heading">
		            <p style="display:inline">

		            	@if ($register_value == 0)
				        <p>Thank you for your job application to the above program. <br>You have completed Step 1 for applying to this job. The next step is to enroll/purchase the Wealth Management program by making a payment of 4250+S.Tax.</p>
				        <p><b>Selection Process:</b></p>
				        <p>1. Apply > 2. Enroll /Purchase the Program > 3. Clear Certification Exam > 4. Clear Interview > 5. Join</p>
				        <p><b>Steps to enroll/purchase the program:</b></p>
				        <ol>
				            <li>Click on enroll button <a href="http://www.learnwithflip.com/buy-now.html?category_id=2715&category=Wealth-Management-GI" class="apply_now cust_apply">Enroll</a></li>
				            <li>Click on Add to cart</li>
				            <li>Click ‘Login’ & fill your login details as mentioned below</li>
				            <li>Click on Add to Cart again and proceed</li>
				            <li>Follow the purchase process</li>
				        </ol>
				        <p><b>Your login details are (We have also mailed you these details):</b></p>
				        <p>User Name – <?php echo $user_details[0]->email ?><br>
				        Password – <?php echo $user_details[0]->switch_pass ?></p>
						<p style="text-align: center;">
							<a href="http://www.learnwithflip.com/buy-now.html?category_id=2715&amp;category=Wealth-Management-GI" class="apply_now cust_apply" style="padding: 10px 46.5px 10px;">Enroll</a>
						</p>
				        @elseif($register_value == 1)
				        <p>Thank you for your job application to the above program. <br>You have completed Step 1 for applying to this job. The next step is to enroll/purchase the Wealth Management program by making a payment of 4250+S.Tax.</p>
				        <p><b>Selection Process:</b></p>
				        <p> 1. Apply > 2. Enroll /Purchase the Program > 3. Clear Certification Exam > 4. Clear Interview > 5. Join</p>
				        <p><b>Steps to enroll/purchase the program:</b></p>
				        <ol>
				            <li>Click on enroll button <a href="http://www.learnwithflip.com/buy-now.html?category_id=2715&category=Wealth-Management-GI" class="apply_now cust_apply">Enroll</a></li>
				            <li>Click on Add to cart</li>
				            <li>Click ‘Login’ & fill your login details as mentioned below</li>
				            <li>Click on Add to Cart again and proceed</li>
				            <li>Follow the purchase process</li>
				        </ol>
				        <p>*If you, do not remember your login details (username/password), please contact us at support@learnwithflip.com or ask for help on LIVE Chat.</p>
				 		<p style="text-align: center;">
							<a href="http://www.learnwithflip.com/buy-now.html?category_id=2715&amp;category=Wealth-Management-GI" class="apply_now cust_apply" class="padding: 10px 46.5px 10px;">Enroll</a>
						</p>
				        @elseif($register_value == 2)
				            <p>Thank you for your job application to the above program. <br>We will review your application and update you on the next process. Please keep checking your mails.</p>
				        @endif
		            </p>
		          </div>
		        </div>
	        </div>
	        
	        <div id="track" class="tab-pane">   
	        </div>

	        <div id="interview" class="tab-pane">  
	        </div>
	        
	        <div id="faq" class="tab-pane">   
    		</div>

	</div>

    <img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
    <a style="top:330px;position:fixed;right:-7px;" href="https://www.facebook.com/learnwithflip" target="_blank"><img class="fb" style="width:58px;height:80px :hover {opacity:0.4;}" src="/assets/images/Facebook_icon.png" border="0"></a>
    <a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>


	<!-- Google Code for Sign Up Conversion Page -->
	<script type="text/javascript">
		/* <![CDATA[ */
		var google_conversion_id = 977955575;
		var google_conversion_language = "en";
		var google_conversion_format = "2";
		var google_conversion_color = "ffffff";
		var google_conversion_label = "YAtnCNHc9AcQ99Wp0gM";
		var google_conversion_value = 0;
		var google_remarketing_only = false;
		/* ]]> */
	</script>

	<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script>
	
	<noscript>
		<div style="display:inline;">
			<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/977955575/?value=0&amp;label=YAtnCNHc9AcQ99Wp0gM&amp;guid=ON&amp;script=0"/>
		</div>
	</noscript>

@stop
