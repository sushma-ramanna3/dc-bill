@extends('layouts.custom1')
@section('content')


		@include('applications._partials.hdfc.4_header')

		@include('applications._partials.hdfc.4_menu')
		
		@if($id == 4) @include('applications._partials.hdfc.4_jd_tsm')
		@elseif($id == 5) @include('applications._partials.hdfc.4_jd_rm')
		@elseif($id == 6) @include('applications._partials.hdfc.4_jd_bb')
		@else @include('applications._partials.hdfc.4_jd_bb')
		@endif

		@include('applications._partials.hdfc.4_form_questionnarie')

		@include('applications._partials.hdfc.4_contact')

		@include('applications._partials.footer_scroller')

		@include('applications._partials.live_chat')

		<script>
			(function($) {
				$("#apply, .apply").addClass("active");
				$(".about, #about, .contact, #contact").removeClass("active");
			})(jQuery);

		</script>
@stop

  		@include('applications._partials.hdfc.4_style')

