@extends('layouts.custom1')
@section('content')
      <style type="text/css">
            .cust_apply{
                  background: #EE0000;
            }
            .co:hover{
              cursor: pointer;
            }
          
      </style>


      @include('applications._partials.hdfc.4_header')

      @include('applications._partials.hdfc.4_menu')
      
      <div class="col-md-12" style="text-align: right;font-size: 20px;font-weight: bold;margin-top: 5px;text-decoration: underline;"><a href="/guaranteed-bank-job/HDFC/">Back</a></div>

      @if($location['id'] == 4) @include('applications._partials.hdfc.4_jd_tsm')
      @elseif($location['id'] == 5) @include('applications._partials.hdfc.4_jd_rm')
      @elseif($location['id'] == 6) @include('applications._partials.hdfc.4_jd_bb')
      @elseif($location['id'] == 7) @include('applications._partials.hdfc.4_jd_ee')
      @endif

      <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title red1" id="myModalLabel">
                Important Note
               </h4>
              </div>
              <div class="modal-body">
                You are applying for 

                  @if($location['id'] == 4) <b>Trade Sales Manager</b>.
                  @elseif($location['id'] == 5) <b>Branch Relationship Manager</b>.
                  @elseif($location['id'] == 6) <b>Relationship Manager - Business Banking</b>.
                  @elseif($location['id'] == 7) <b>Sales Manager/Relationship Manager - Emerging Enterprise Group(EEG)</b>.
                  @endif 

                  Please note, you can only apply to one job
              </div>
              <div class="modal-footer">
                 <button type="button" style="float:right;background:#18bc9c;" class="btn btn-default" data-dismiss="modal">
                  <a style="color: #fff;" id="cust_apply1" >Continue with this role</a> 
                </button>
                  <a class="btn btn-primary" href="/guaranteed-bank-job/HDFC/" style="float:left;">View all jobs</a>
                 <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               <button type="button" class="btn btn-primary">Save changes</button> -->
              </div>
            </div>
          </div>
        </div>

      @include('applications._partials.hdfc.4_form')

      @include('applications._partials.hdfc.4_faq')

      @include('applications._partials.hdfc.4_updates')

      @include('applications._partials.hdfc.4_contact')

      @include('applications._partials.footer_scroller')

      @include('applications._partials.live_chat')


      
<script>
   (function($) {
    $('.cust_apply').click(function() {
       $('#myModal2').modal('show');
       $('.about').removeClass('active');
    });
    $('.apply').click(function() {
      $('#myModal2').modal('show');
    });
    $('#cust_apply1').click(function() {
       $('.about').removeClass('active');
    });

    var url = document.location.toString();
    if (url.match('#')) {
         $('html,body').animate({ scrollTop: 0 }, 'slow', function () {
        });
        $('.nav-pills a[href=#'+url.split('#')[1]+']').tab('show').focus() ;
        $(".about").removeClass("active");
        $("."+url.split('#')[1]).addClass("active");
       // window.scrollTo(0,0);
        // $('html,body').animate({scrollTop: $('.nav-pills').offset().top}, 100);
    } 
    //H! text  change


  })(jQuery);
</script>



@stop

@section('scriptarea')

      @include('applications._partials.hdfc.4_footer_script')

@stop

	      @include('applications._partials.hdfc.4_style')

          <!--@if(Input::get('id') == 4) @include('applications._partials.hdfc.4_jd_bb')@endif-->


