@extends('layouts.custom_hdfc')
@section('content')
	<style>

		.col3{
			border: 2px solid #001E74;
			padding: 0 10px 10px;
			margin: 12px;
			width: 48.5%;
			text-align: left;
			float: left;
			margin: 5px 7px;
		}
		.col-main{
			margin: 0px 0px 10px;
			padding: 0 5px;
		}
		.col-main h4{
			margin-top: 5px;
			margin-bottom: 5px;
		}
		p{
			margin-bottom: 5px;
		}
		h4{
			font-size: 18px;
		}
		.down_btn{
			background:#4D9ACE;
		}

 	 #scroller2 li{
      /*   border: 2px solid #d0d0d0; */
       padding: 5px 5px 6px 5px;
	/* 	width: 185px; */
	/* 	height: 79px; */
        display: block;
      }
      #scroller2 li span.name{
        font-weight: bold;
        display: block;
        text-align: center;
      }
      #scroller2 li span.text{
         /* height: 49px; */
         display: block;
         float: left;
         color: #001E74;
      }
     .black{
      	color: #000;
      	 display: block;
      	 float: left;
     }
     .marg-cust h4.h4_recieved{
      	padding: 0.1% 0;
		margin: 0;
		color: #fff;
		font-weight: normal;
		font-size: 14px;

     }
  	.simply-scroll-clip{
      	border-right: none;
    	border-left: none;
     }
     .simply-scroll-list{
     	background: #f0f0f0;
     }
     .simply-scroll .simply-scroll-container{
     	padding: 0px;
     }
	</style>
  
	
	<div class="col-md-12 img_w padd_null" style="margin-top: 6px;margin-bottom: 6px;"><img src="/assets/images/HDFC_banner.jpg" alt="banner" name="banner"></div>
		<div class="col-md-12" style="border: 1px solid #001E74; padding: 0; margin: 1.5% 1.3% 0 1.3%;margin-top:0;width: 97.5%;background: #fefefe;">
		<div style="padding: 0px; text-align: left;" class="col-md-12 align_center">
			<!-- <h4 style="margin: 4px;font-size: 14px;" class="red font-bold"><span style="color: rgb(0, 0, 0); font-size: 14px;">Current Status</span>
			 - <span style="color: rgb(0, 0, 0);">Batch 1</span>: 73 selected for interview; <span style="color: rgb(0, 0, 0);">Batch 2:</span> 150 applicants- Online test completed; <span style="color: rgb(0, 0, 0);">Batch 3:</span>  66+ applications received
			 </h4> -->
			 <!-- Current Status - BB/EEG – Batch 1: Conditional offers made. 
				 Batch 2, 3 and 4 Interviews in process. BRM/TSM - Interviews scheduled next week. | Batch 5: 47+ Applications. -->
			<div style="margin: 4px;font-size: 9.35pt;" class="red font-bold">
				<span style="color: rgb(0, 0, 0);">Current Status - &nbsp;</span> BB/EEG -
				  <a href="/guaranteed-bank-job/HDFC/5#updates" style="color:#09c;"> <u>Conditional Offers made</u>. </a>  
				  Enrolments closed <span style="color: rgb(0, 0, 0);"> | </span> BRM/TSM - <span style="color: rgb(0, 0, 0);">Batch 1-4:</span> Interviews in process.<br>
				<span style="display: block;margin-left:100px;">All Profiles - <span style="color: rgb(0, 0, 0);">Batch 5:</span> Interviews to be scheduled soon. <span style="color: rgb(0, 0, 0);">Batch 6:</span> 33+ Applications.</span>
	  		</div> 
		</div>

	    <div class="col-md-12 border padd-15" style="border-top: none;padding: 0;border-bottom: none;margin: 0px;border-left: none;">
	      	<div class="col-md-2 marg-cust pull-left align_center" style=" margin: 0;padding: 0; border: none;"> 
	        	<h4 class="h4_recieved" style="margin: 0;border: none;">Applications received from:</h4>
	      	</div>
	      	<div class="hscroll" style="padding: 0;margin: 0;">
		        <ul id="scroller2" class="align_center">
		          	<li><span class="text">BIMHRD</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">IMI</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">LBSIMT</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">Sinhgad - Pune</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">Welingkar - Bangalore</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">Amity Business School - Noida</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">IBMR</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">IBS - Ahmedabad</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
		          	<li><span class="text">IBS - Gurgaon</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	        		<li><span class="text">IBS - Hyderabad</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	         		<li><span class="text">IBS - Kolkata</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	          		<li><span class="text">IBS - Mumbai</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	           		<li><span class="text">IIM - Indore</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	           		<li><span class="text">IIM - Rohtak</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	         		<li><span class="text">IMS - Ghaziabad</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	          		<li><span class="text">Netaji Subhash IMS</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	           		<li><span class="text">SOIL</span><span class="black"><b>&nbsp;&nbsp;|</b>  </span></li>
	           		<li><span class="text"><i>and more...</i></span><span class="black"></span></li>
	           		<li><span class="text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="black"></span></li>
	           		<li><span class="text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="black"></span></li>
	           		<li><span class="text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="black"></span></li>
		        </ul>
	      	</div>
	    </div>
    </div>
	<div class="col-md-12 col-main" style="margin:10px 3px;">
      <p style="margin: 0 5px 0px 5px;padding-right:5px;" class="tc_none">HDFC Bank (India's leading private sector bank), and FLIP 
      (Finitiatives Learning India Pvt Ltd/ India's largest provider of role based e-Learning and Certifications across Banking and Financial Services) have joined hands to develop programs and create trained managers, to join HDFC Bank, across India <b>(to check on bank website, <a style="font-size:14px;" href="https://www.hdfcbank.com/aboutus/careers/Relationship%20Manager%20Program.htm" target="_blank">click here</a>)</b>. </p>
      <p class="align_center" style="margin-bottom:0px;"><b>(There are 2 jobs on offer, you can apply to only one job)</b></p>
  	</div>


	<div class="col-md-12 col-main">
		<div class="col-md-3 col3">
			<h4 class="red font-bold paddb-border align_center">Branch Relationship Manager</h4>
				<p>This is a role, focused on High Net Worth customers of the Bank. The role of a Relationship Manager is, to enhance the existing relationship with HNI customers by analyzing his/her needs; and then cross-selling of various products and services, such as Current and Saving accounts, Loans and Third Party Products like Insurance and Mutual funds. </p>
				
				<p><span class="blue font-bold" style="font-size: 15px;">Eligibility:</span></p>
				<ul>
					<li>
						Age: Less than 28 years.
					</li>
					<li>
						MBA/PGDM with 0-2 years work experience.
					</li>
				</ul>
		
			<p style="float:left;margin-top: 20px;"><a href="/download/Branch RM.pdf" class="cust_apply down_btn"  >Download JD</a></p>
			<p class="align_center" style="margin-bottom:0px;float:right;margin-top: 22px;">
				<a href="/guaranteed-bank-job/HDFC/5" class="cust_apply">View details and apply</a>
			</p>
		</div>

		<div class="col-md-3 col3"> 
			<h4 class="red font-bold paddb-border align_center" style="margin: 0;margin-top: 5px;margin-left:8px;">Trade Sales Manager</h4>
			<p>The Trade Sales Manager is a Relationship Management role, focused on the retail and small business segment. </p>

			<p>You will be responsible for income targets and customer acquisition, for trade products, of the respective branches, and transactions in foreign exchange. You will also be involved in marketing and training initiatives of concerned branches, for trade and foreign exchange products and processes.</p>
			<p><span class="blue font-bold" style="font-size: 15px;">Eligibility:</span></p>
			<ul style="margin-bottom: 15px;">
				<li>
					Age: Less than 28 years.
				</li>
				<li>
					MBA/PGDM with 0-2 years work experience.
				</li>
			</ul>
		
			<p style="float:left"><a href="/download/TSM-RM.pdf" class="cust_apply down_btn"  >Download JD</a></p>
			<p class="align_center" style="margin-bottom: 0px;float:right;">
				<a href="/guaranteed-bank-job/HDFC/4" class="cust_apply" >View details and apply</a>
			</p>
		</div>
		
<!-- 		<div class="col-md-3 col3" >
	<h4 class="red font-bold paddb-border align_center" style="margin-bottom: 8px;">Relationship Manager - Business Banking</h4>
		<p>Like a Relationship Manager in Corporate Banking, this is a B2B Sales role, focused on the <b>higher end</b> of small and medium enterprises.</p> 
		<p>You will need to manage a portfolio of 20-35 Business Banking Group (BBG) credit relationships, depending on the geography covered, and the branches mapped to you. </p>
		<p><span class="blue font-bold" style="font-size: 15px;">Eligibility:</span></p>
		<ul>
			<li>
				Age: Less than 28 years.
			</li>
			<li>
				MBA/PGDM/CA with 0-2 years work experience.
			</li>
		</ul>
	
		<p class="align_center" style="margin-bottom: 0px;">
			<a class="cust_apply" >Enrollment Closed</a>
		</p>

	<p style="float:left;"><a class="cust_apply down_btn"   href="/download/BB-RM.pdf">Download JD</a></p>
	<p class="align_center" style="margin-bottom: 0px;float:right">
		<a href="/guaranteed-bank-job/HDFC/6" class="cust_apply" >View details and apply</a>
	</p>
</div> -->
		
<!-- 		<div class="col-md-3 col3" style="padding:0px;">
	<h4 class="red font-bold paddb-border align_center">Sales Manager/Relationship Manager –Emerging Enterprise Group(EEG)</h4>
		<div style="padding:7px;"><p>Like a Relationship Manager in Corporate Banking, this is focused on small and medium enterprises.</p> 
	
		<p><span class="blue font-bold" style="font-size: 15px;">Eligibility:</span></p>
		 <ul>
			<li>
				Age: Less than 28 years.
			</li>
			<li>
				MBA/PGDM/CA with 0-2 years work experience.
			</li>
		</ul> 
		<p class="align_center" style="margin-bottom: 3px;margin-top: 43px;">
			<a class="cust_apply" >Enrollment Closed</a>
		</p>
		<p style="float:left;margin-top: 31px;margin-bottom: 15px;">
			<a class="cust_apply down_btn" href="/download/RM-EEG.pdf">Download JD</a>
		</p> 
		<p class="align_center" style="margin-top: 31px;margin-bottom: 15px;float:right;">
			<a href="/guaranteed-bank-job/HDFC/7" class="cust_apply" >View details and apply</a>
		</p>
	</div>
</div> -->
		
	</div>

	
  	 @include('applications._partials.footer_scroller')


	<img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
	<a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>

<script type="text/javascript">

  $(document).ready(function() {

   $("#scroller2").simplyScroll();

  });

</script>
@stop
