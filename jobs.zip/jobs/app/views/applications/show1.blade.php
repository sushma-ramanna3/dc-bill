@extends('layouts.custom1')
@section('content')
  
	<div>
		<br><br><br>
		<center class="red1 font-bold paddb-border" style="font-size: 18px;" >All Registrations Closed</center>
	</div>

 
    <img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
    <a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>
@stop