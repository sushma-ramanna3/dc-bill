@extends('layouts.custom')
@section('content')
  
    <div class="col-md-12 img_w padd_null"><img src="/assets/images/banner.jpg" alt="banner" name="banner"/></div>
  
      <ul class="nav nav-pills padd-15" data-tabs="tabs" id="intro_li">  
        <li class="active intro"><a href="/">Program Details</a></li>     
       <!--  <li class="about"><a href="/#about" >Role / Eligibility</a></li> 
        <li class="sales"><a href="/#sales"></a></li>     -->
        <li class="apply"><a href="/#apply" data-toggle="tab">Apply</a></li>   
        <li class="track"><a href="/track">Track My Application</a></li>  
        <li><a href="/#interview" >Interviews</a></li>   
        <li ><a href="/#faq">FAQs</a></li>   
        <li class="last-item"><a href="/#contact" >Contact Us</a></li>
      </ul>  

    	<div id="my-tab-content" class="tab-content padd-15 border-top">

		 	<div id="intro" class="tab-pane active"> 
		 	</div>

		    <div id="about" class="tab-pane">   
		    </div>
	      
		    <div id="program" class="tab-pane">   
		    </div>
	      
	    	<div id="apply" class="tab-pane"> 
	        	<div class="col-md-12 font-bold font-14 padd_null text-center panel panel-default" id="success-message">
		          <div class="panel-heading">
		            <p class="text-center" style="display:inline">Your have successfully applied for this job. Please check your mail for details. </p>
		          </div>
		        </div>
	        </div>
	        
	        <div id="track" class="tab-pane">   
	        </div>

	        <div id="interview" class="tab-pane">  
	        </div>
	        
	        <div id="faq" class="tab-pane">   
    		</div>

	</div>

  	<div class="col-md-12 border padd-15">
	    <div class="col-md-2 marg-cust pull-left align_center"> 
	      <h4><b>Successfully<br> Placed by FLIP: <br>Similar Profiles</b></h4>
	    </div>
	    <div class="hscroll">
	      <ul id="scroller" class="align_center">
	        <li><img src="/assets/images/V-Sravani-Lakshmi.png" /><span>V Sravani Lakshmi</span><br>Axis Bank</li>
	        <li><img src="/assets/images/Sangam-Aenki-Naidu.png" /><span>Sangam Aenki N</span><br>Axis Bank</li>
	        <li><img src="/assets/images/B-Santosh-Kumar.png" /><span>B Santosh Kumar</span><br>Axis Bank</li>
	        <li><img src="/assets/images/Ajay-Kumar-Chinthakindi.png" /><span>Ajay Kumar C</span><br>ING Vysya Bank</li>
	        <li><img src="/assets/images/Suma-Ejjigani.png" /><span>Suma Ejjigani</span><br>ING Vysya Bank</li>
	        <li><img src="/assets/images/Srikanth-Reddy-Komareddy.png" /><span>Srikanth R K</span><br>ING Vysya Bank</li>
	        <li><img src="/assets/images/Sharath-Chandra-Reddy-Kasini.png" /><span>Sharath C R K</span><br>ING Vysya Bank</li>
	        <li><img src="/assets/images/Ajay-Prashanth-Barla.png" /><span>Ajay Prashanth B</span><br>ING Vysya Bank</li>
	        <li><img src="/assets/images/Deepjoy-Shome.png" /><span>Deepjoy Shome</span><br>HDFC Bank</li>
	      </ul>           
	    </div>
  </div>

    <img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
    <a style="top:330px;position:fixed;right:-7px;" href="https://www.facebook.com/learnwithflip" target="_blank"><img class="fb" style="width:58px;height:80px :hover {opacity:0.4;}" src="/assets/images/Facebook_icon.png" border="0"></a>
    <a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>


	<!-- Google Code for Sign Up Conversion Page -->
	<script type="text/javascript">
		/* <![CDATA[ */
		var google_conversion_id = 977955575;
		var google_conversion_language = "en";
		var google_conversion_format = "2";
		var google_conversion_color = "ffffff";
		var google_conversion_label = "YAtnCNHc9AcQ99Wp0gM";
		var google_conversion_value = 0;
		var google_remarketing_only = false;
		/* ]]> */
	</script>

	<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script>
	
	<noscript>
		<div style="display:inline;">
			<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/977955575/?value=0&amp;label=YAtnCNHc9AcQ99Wp0gM&amp;guid=ON&amp;script=0"/>
		</div>
	</noscript>

@stop
