@extends('layouts.custom_hdfc')
@section('content')
	<style>

		.col3{
			border: 2px solid #001E74;
			padding: 0 10px 10px;
			margin: 12px;
			width: 48.5%;
			text-align: left;
			float: left;
			margin: 5px 7px;
		}
		.col-main{
			margin: 0px 0px 10px;
			padding: 0 5px;
		}
		.col-main h4{
			margin-top: 5px;
			margin-bottom: 5px;
		}
		p{
			margin-bottom: 5px;
		}
		h4{
			font-size: 18px;
		}
		.down_btn{
			background:#4D9ACE;
		}

 	 #scroller2 li{
      /*   border: 2px solid #d0d0d0; */
       padding: 5px 5px 6px 5px;
	/* 	width: 185px; */
	/* 	height: 79px; */
        display: block;
      }
      #scroller2 li span.name{
        font-weight: bold;
        display: block;
        text-align: center;
      }
      #scroller2 li span.text{
         /* height: 49px; */
         display: block;
         float: left;
         color: #001E74;
      }
     .black{
      	color: #000;
      	 display: block;
      	 float: left;
     }
     .marg-cust h4.h4_recieved{
      	padding: 0.1% 0;
		margin: 0;
		color: #fff;
		font-weight: normal;
		font-size: 14px;

     }
  	.simply-scroll-clip{
      	border-right: none;
    	border-left: none;
     }
     .simply-scroll-list{
     	background: #f0f0f0;
     }
     .simply-scroll .simply-scroll-container{
     	padding: 0px;
     }
	</style>
  
<br><br><br><br><br><br>	

		<div class="col-md-12" style="border: 1px solid #001E74; padding: 0; margin: 1.5% 1.3% 0 1.3%;margin-top:0;width: 97.5%;background: #fefefe;">
			<div style="padding: 0px; text-align: left;" class="col-md-12 align_center">
				<div style="margin: 4px;font-size: 9.35pt;">
					<center style="padding: 20px;font-size: 15px;"> <span class="red font-bold">ALL REGISTRATIONS CLOSED.</span> Please provide your details, we will get in touch with you regarding any further openings.</center>
		  		</div> 
			</div>
    	</div>

    @if (isset($registered))
	<div class="col-md-12 font-14 padd_null panel panel-default" id="success-message">
      <div class="panel-heading">
        <center>Thank your for your interest. We will inform you for any updates.</center>
	  </div>
	</div>
    @endif

	<div class="col-md-12 col-main" style="margin-top:20px">
		<form class="form-horizontal" method="post" action="/registrations-closed">
			<fieldset>
			<!-- Form Name -->
			<legend></legend>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="name">Name</label>  
			  <div class="col-md-5">
			  <input id="name" name="name" type="text" placeholder="please enter your name" class="form-control input-md">
			    
			  </div>
			</div>

			<!-- Password input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="email">Email</label>
			  <div class="col-md-5">
			    <input id="email" name="email" type="text" placeholder="please enter your email" class="form-control input-md">
			    
			  </div>
			</div>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="phone">Phone</label>  
			  <div class="col-md-5">
			  <input id="phone" name="phone" type="text" placeholder="please enter your phone" class="form-control input-md">
			    
			  </div>
			</div>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="preferred_location">Preferred Job Location</label>  
			  <div class="col-md-5">
			  <input id="preferred_location" name="preferred_location" type="text" placeholder="please enter location" class="form-control input-md">
			    
			  </div>
			</div>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="current_location">Current Location</label>  
			  <div class="col-md-5">
			  <input id="current_location" name="current_location" type="text" placeholder="please enter location" class="form-control input-md">
			    
			  </div>
			</div>

			<!-- Select Basic -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="highest_qulification">Highest Qualification</label>
			  <div class="col-md-5">
			    <select id="highest_qulification" name="highest_qulification" class="form-control">
			      <option value="UG">UG</option>
			      <option value="PG - MBA/PGDM">PG - MBA/PGDM</option>
			      <option value="PG - Non MBA/PGDM">PG - Non MBA/PGDM</option>
			    </select>
			  </div>
			</div>

			<div class="form-group">
              <label class="col-md-4 control-label" for="submit"></label>
              <div class="col-md-2">
                <button id="submit" name="submit" class="btn btn-lg btn-success btn-block button-padd"> Submit </button>
              </div>
            </div>
			</fieldset>
		</form>
	</div>
	<img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
	<a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>

<script type="text/javascript">

  $(document).ready(function() {
  	$("footer").hide();
	$("#scroller2").simplyScroll();
  });

</script>
@stop
