@extends('layouts.custom')
@section('content')
  
  
    <div class="col-md-12 img_w padd_null"><img src="/assets/images/banner.jpg" alt="banner" name="banner"/></div>
  
      <ul class="nav nav-pills padd-15" data-tabs="tabs" id="intro_li">  
        <li class="active intro"><a href="#intro" data-toggle="tab">Program Details</a></li>     
<!--         <li class="about"><a href="#about" data-toggle="tab">Role / Eligibility</a></li>  
 <li class="sales"><a href="#program" data-toggle="tab">Program Details</a></li>  --> 
        <li class="apply"><a href="#apply" data-toggle="tab">Apply</a></li>   
        <li class="track"><a href="/track">Track My Application</a></li>  
        <li class="interview"><a href="#interview" data-toggle="tab">Interviews</a></li>   
        <li class="faq"><a href="#faq" data-toggle="tab">FAQs</a></li> 
        <li class="last-item contact"><a href="#contact" data-toggle="tab">Contact Us</a></li>   
      </ul>  

    <div id="my-tab-content" class="tab-content padd-15 border-top">

      <div id="intro" class="tab-pane active"> 

        <h4 class="red font-bold paddb-border">The FLIP Branch Sales Officer Certification Program, in association with HDFC Bank</h4>
        
        <p>The FLIP <span class="font-bold">Branch Sales Officer Certification Program (BSOP)</span>, <b>is a 4 week program, leading to a career with HDFC Bank.</b>
        </p>
        <p>It aims to provide both banking product knowledge and selling skills; enabling you to start a banking career, in the fast growth area of sales.</p>
        <ul class="checkmark">
          <li><span class="font-italic font-bold">Invest in your career,</span> by gaining an industry recognized certification.</li>
          <li>Join as a <span class="italic_bold"><b>fully trained professional.</b></span></li>
          <li>Meet your targets and <span class="italic_bold"><b>perform better,</b></span> from Day One!</li>
        </ul>

        <h4 class="blue font-bold">The Process</h4>
        <ul class="number-li" >
          <li><span class="blue font-bold">Apply:</span> Candidates are required to apply for the specific job location, by clicking on the &nbsp;<a href="#apply" class="apply_now cust_apply" data-toggle="tab">Apply</a> &nbsp;tab
            <br><span class="red"><small>*There is no application fee.</small></span></li>
          <li><span class="blue font-bold">Clear Interview and get an offer:</span> Eligible applicants for the job get interviewed by HDFC Bank. Selected candidates will get a provisional offer letter.</li>
          <li><span class="blue font-bold">Earn Industry recognized Certification in 4 weeks:</span> The fee would be shared between the candidate and HDFC Bank. The candidate will pay Rs. 5,000, to go through the training & clear the FLIP Branch Sales Officer Certification Program. </li>
          <li><span class="blue font-bold">Join HDFC Bank Immediately:</span> Successful candidates, after clearing the BSOP Certification, will join the bank.</li>
        </ul>


        <h4 class="blue font-bold">Role& Eligibility</h4>

        <p>You will be working as a <b>Sales officer</b> with HDFC Bank. The primary role would be, acquisition of customers for CASA (Current Account & Saving Account) from the local market, and cross selling banking & third party financial products, to them.
         It will be a 2 Years Fixed Term Contract on the payroll of the Bank (Contract renewed based on performance).</p>

        <p><b>Eligibility</b> - Graduate of less than 28 years of age, with 0 – 3 years of work experience.</p>

        <p><b>CTC</b> - Salary Range: Graduates - INR 1.20 to 1.44 Lakhs p.a ; Post Graduates - INR 1.44 to 1.68 Lakhs p.a + monthly performance incentives & other benefits</p>

        <p><a href="/download/BSOP-JD.pdf"><u>Click here to view the detailed Job Description.</u></a></p>

        <p class="font-bold">Job openings currently in: </p>

        <table border="1" cellpadding="3" cellspacing="1" style="width: 50%;">
          <tbody>
            <tr>
              <!-- <td align="center">
                <strong>North</strong></td>
              <td align="center">
                <strong>West</strong></td> -->
              <!-- <td align="center">
                <strong>South</strong></td>
              <td align="center">
                <strong>East</strong></td> -->
            </tr>
            <tr>
              <td>
                <ul class="ul_padding"><li>Chandigarh</li><li>Haryana</li><li>Himachal Pradesh</li><li>Lucknow</li></ul></td>
              <!-- <td>
                <ul class="ul_padding"><li>Pune</li></ul></td> -->
             <!--  <td>
               <ul class="ul_padding"><li>Hyderabad</li> <li>Chennai</li></ul></td>
             <td>
               <ul class="ul_padding"><li>Kolkata</li></ul></td> -->
            </tr>
          </tbody>
        </table>

      

        <h4 class="blue font-bold">Program Delivery</h4>
        <p>This is an <b>online program, which</b> is blended with interesting <b>live simulations, web faculty sessions</b> and <b>e-mail query support;</b> you can access the course from anywhere, anytime.</p>
        <p><span class="red font-bold">You will need a computer and an internet connection, for the program.</span> </p>


       <p class="col-md-12 font-bold font-14 padd_null">
          <span class="pull-left">Limited seats, strictly on a first-come-first served basis, for the current batch.&nbsp;</span>
          <a href="#apply" class="apply_now cust_apply" data-toggle="tab">Apply</a>
        </p>

      </div>

    <div id="about" class="tab-pane">   
        <h4 class="red font-bold paddb-border">About the Role</h4>
        <p><span class="blue font-bold">Post:</span> Sales Officer (Retail Branch Banking) </p>

        <p><span class="blue font-bold">Type:</span> 2 Years Fixed Term Contract <b>on the payroll</b> of the Bank (Contract renewed based on performance).</p>

        <p><span class="blue font-bold">Objective:</span> Providing support to branch profitability by selling bank products - saving & current account through different acquisition channels in the catchment area.</p>
      
        <h4 class="blue font-bold">Responsibilities</h4>
        <ul>
          <li>To acquire saving & current accounts for Resident / Non-resident Indians.</li>
<li>To make sure about the quality of newly acquired customers.</li>
<li>To source Fixed Deposits (FDs) for the existing as well as the new customers.</li>
<li>To acquire more customers by doing cold calls, meeting walk-ins, associates, referrals from other customers, through emails, direct mails, ATMs etc.</li>
<li>To give the best service to all the customers.</li>
Meeting productivity norms as defined through support of channels & own efforts.
Strictly adhere & maintain KYC norms compliance.
Adhere to the norms, regulations & practices of banks religiously and resolve customers' queries and problems.
</li>
        </ul>    
    
    




        <p>A Sales Officer is the face of a bank. </p>
        <p>The primary role of a Sales Officer would be, acquisition of customers for CASA (Current Account & Saving Account) from the local market and selling & cross selling banking & third party financial products, to them.</p>
        <p>He has to maintain a good relationship with new & existing customers and ensure all their queries and problems are resolved. He would ensure that all the banking norms and regulations are met in the process of acquisition & servicing.</p>

        
        <h4 class="blue font-bold">Eligibility</h4>
        <ul>
          <li>Age: 20 -28.</li>
          <li>Any Graduate with 0-3 years of work experience in sales.</li>
          <li>Successful completion of FLIP Branch Sales Officer Certification Program.</li>
        </ul>

        <h4 class="blue font-bold">Preferences</h4>
        <ul>
          <li>Two wheeler with valid license.</li>
          <li>Local residence.</li>
        </ul>

        <h4 class="blue font-bold">CTC Details</h4>
        <ul>
          <li>Salary Range: Graduates - <b>INR 1.20</b> to <b>1.44 Lakhs p.a</b> ; Post Graduates - <b>INR 1.44</b> to <b>1.68 Lakhs p.a</b> (Depending upon no. of years relevant work experience & education.)</li>
          <li>Other Benefits: Self medi-claim benefit of INR 50,000/-</li>
          <li>Performance Incentives: Monthly</li>
          <li>Statutory Benefits: 
            <ul>
              <li>Employee Provident Fund</li>
              <li>Paid Leave- 25 days calendar year (after completion of 6 months from Date of Joining.)</li>
            </ul>
          </li>
        </ul>

        <h4 class="blue font-bold">Responsibilities</h4>
        <ul>
          <li>To acquire saving & current accounts for Resident / Non-resident Indians.</li>
          <li>To make sure about the quality of newly acquired customers.</li>
          <li>To source Fixed Deposits (FDs) for the existing as well as the new customers.</li>
          <li>To acquire more customers by doing cold calls, meeting walk-ins, associates, referrals from other customers, through emails, direct mails, ATMs etc.</li>
          <li>To give the best service to all the customers.</li>
          <li>Meeting productivity norms as defined through support of channels & own efforts.</li>
          <li>Strictly adhere & maintain KYC norms compliance.</li>
          <li>Adhere to the norms, regulations & practices of banks religiously and resolve customers' queries and problems.</li>
        </ul>

        <h4 class="blue font-bold">Key Tasks</h4>
        <ul>
          <li>Cold calling and getting appointments</li>
          <li>Generating and maintaining database</li>
          <li>Understanding customer requirements</li>
          <li>Explaining the products as per requirement</li>
          <li>New customer acquisition and customer retention</li>
          <li>Resolving customers queries and problems</li>
        </ul>

        <h4 class="blue font-bold">Skill Set</h4>
        <ul>
          <li>Honesty and Integrity.</li>
          <li>Hard and Smart working.</li>
          <li>Go getter attitude.</li>
          <li>Ability to convince and influence.</li>
        </ul>

        <p class="font-bold">A candidate after clearing the interview, will undergo the 4 week FLIP Branch Sales Officer Certification Program.</p>
        <p class="font-bold">After successful completion, she/he will join the bank at the specified locations. To know more, click the 'Program Details' tab.</p>
     </div>
      
    <div id="program" class="tab-pane">   
      <h4 class="red font-bold paddb-border">The Branch Sales Officer Program</h4>

      <p>The FLIP Branch Sales Officer Program, in association with HDFC Bank, aims to provide both <span class="font-bold">banking product knowledge</span> and <span class="font-bold">selling skills;</span> enabling you to start a banking career, in the fast growth area of sales.</p>
      <p>The <span class="font-bold">4 week online program</span> is blended with interesting <span class="font-bold">live simulations, web faculty sessions</span> and <span class="font-bold">e-mail query support;</span> you can access the course from anywhere, anytime.</p>
      <p class="red font-bold">You will need a computer and an internet connection, for the program.</p>
    
      <h4 class="blue font-bold">Program Coverage:</h4>

      <ul>
        <li>Introduction to Banking, KYC and AML norms.</li>
        <li>Key elements of CASA Sales; an overview of different types of accounts.</li>
        <li>Various interactive real-life simulations like Account Opening, Key Selling Principles, Meeting Etiquette for a sales officer and Pitching to the customer.</li>
        <li>Facilities like Cheques, Lockers and Third Party Products.</li>
        <li>A sneak peek at consumer lending. </li>
        <li>The above is blended with Role-play based, interactive, online sessions.</li>
      </ul>    

      <p>For most freshers, lack of proper training and inadequate product knowledge results in poor performance.</p>

      <p>In order to bridge this skill gap, the program <span class="font-bold">uses applied learning: just product knowledge is not enough. You will learn how to use</span> it, in situations which you will face at work.</p>

      <h4 class="blue font-bold">Selection Process</h4>

      <p>You need to follow a simple, 4 step process:</p>

      <ul class="number-li"> 
        <li><span class="blue font-bold">Apply:</span>
          Candidates are required to apply for the specific job location, by clicking on the <a href="#apply" class="apply_now cust_apply" data-toggle="tab">Apply</a> tab.<br>
          <span class="orange">*There is no application fee.</span>
        </li>
        <li><span class="blue font-bold">Clear Interview and get an offer:</span>
          Eligible applicants for the job get interviewed by HDFC Bank. Selected candidates will get a provisional offer letter. See 'Interviews' tab above for more details.
        </li>
        <li><span class="blue font-bold">Earn Industry recognized Certification in 4 weeks:</span>
 	      The candidate will have to pay Rs. 5,000 as fee for the program. Candidates will then have to  go through the training & clear the FLIP Branch Sales Officer Certification Program.

          <br>
        </li>
        <li><span class="blue font-bold">Join HDFC Bank Immediately:</span>
         Successful candidates, after clearing the BSOP Certification, will join the bank. 
        </li>
      </ul>

      <p class="col-md-12 font-bold font-14 padd_null">
        <span class="pull-left">Limited seats, strictly on a first-come-first served basis, for the current batch.&nbsp;</span>
        <a href="#apply" class="apply_now cust_apply" data-toggle="tab">Apply</a>
      </p>
      <br>
      <p class="font-bold">Job openings currently in: </p>

		<table border="1" cellpadding="3" cellspacing="1" style="width: 500px;">
      <tbody>
        <tr>
          <td align="center">
            <strong>North</strong></td>
          <td align="center">
            <strong>West</strong></td>
          <td align="center">
            <strong>South</strong></td>
          <td align="center">
            <strong>East</strong></td>
        </tr>
        <tr>
          <td>
            <ul class="ul_padding"><li>Delhi</li><li> Lucknow</li> <li>Chandigarh</li></ul></td>
          <td>
            <ul class="ul_padding"><li>Mumbai</li> <li>Pune</li> <li>Ahmedabad</li></ul></td>
          <td>
            <ul class="ul_padding"><li>Hyderabad</li> <li>Chennai</li></ul></td>
          <td>
            <ul class="ul_padding"><li>Kolkata</li></ul></td>
        </tr>
      </tbody>
    </table>
		<br><br>

    </div>
      
    <div id="apply" class="tab-pane"> 
        @if($errors->has())
        <div id="form-errors" class="red">
          <p>The following errors have occurred:</p>
          <ul>
            @foreach($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div><!-- end form-errors -->
        @endif
        @if(Session::get('successful'))
        <div class="col-md-12 font-bold font-14 padd_null text-center panel panel-default" id="success-message">
          <div class="panel-heading">
            <p class="text-center" style="display:inline">Your have successfully applied for this job. Please check your mail for details. </p>
          </div>
         </div>
        @endif
        <form id="bsop_form" class="form-horizontal col-md-12" action="/applications" method="post" enctype="multipart/form-data">
            <fieldset id="fieldsetappend" >
          

      <div id="bsop">
            <!-- Form Name -->
            <h4 class="paddb-border red font-bold">Application Form</h4>
            <div class="form-group">
              <div class="col-md-5">
                {{ 'Fields marked as <span class="red font-bold"> *</span> are mandatory' }}
              </div>
            </div>
            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="first_name">First Name<span class="red font-bold"> *</span> </label>  
              <div class="col-md-5">
              {{ Form::text('first_name', null, array('class'=>'form-control input-md','placeholder'=>'enter your first name', 'required' => 'true', 'id' => 'first_name')) }}
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="last_name">Last Name<span class="red font-bold"> *</span></label>  
              <div class="col-md-5">
              {{ Form::text('last_name', null, array('class'=>'form-control input-md','placeholder'=>'enter your last name', 'required' => 'true', 'id' => 'last_name')) }}  
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="email">Email ID<span class="red font-bold"> *</span></label>  
              <div class="col-md-5">
              {{ Form::text('email', null, array('class'=>'form-control input-md','placeholder'=>'enter your email', 'required' => 'true')) }}  
                
              </div>
            </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="phone">Phone Number<span class="red font-bold"> *</span></label>  
            <div class="col-md-5">
              {{ Form::text('phone', null, array('class'=>'form-control input-md','placeholder'=>'phone number','maxlength'=>'10', 'required' => 'true', 'id' => 'phone_number')) }}      
            </div>
          </div>

          <!-- Select Basic -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="dob">Date of Birth( dd-mm-yyyy )<span class="red font-bold"> *</span></label>
            <div class="col-md-2 pull-left">
              {{ Form::selectRange('dob_day', 1, 31, null, array('class'=>'form-control')); }}
            </div>
            <div class="col-md-2 pull-left">
              {{ Form::selectRange('dob_month', 1, 12, null, array('class'=>'form-control')); }}
            </div>
            <div class="col-md-2 pull-left">
              {{ Form::selectRange('dob_year', 1975, 2010, null, array('class'=>'form-control')); }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="tenth">10th<span class="red font-bold"> *</span></label>  
            <div class="col-md-2">
            {{ Form::text('sslc_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage','required' => 'true', 'id' => 'sslc_percentage')) }}      
            </div>
            <div class="col-md-3">
              {{ Form::text('sslc_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion', 'required' => 'true', 'id' => 'sslc_year')) }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="twelfth">12th<span class="red font-bold"> *</span></label>  
            <div class="col-md-2">
            {{ Form::text('puc_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage','required' => 'true', 'id' => 'puc_percentage')) }}
            </div>
            <div class="col-md-3">
              {{ Form::text('puc_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion','required' => 'true', 'id' => 'puc_year')) }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="graduation">Graduation<span class="red font-bold"> *</span><br>(Graduating in 2014 or earlier)</label>  
            <div class="col-md-2">
            {{ Form::text('graduation_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage', 'required' => 'true', 'id' => 'graduation_percentage')) }}
            </div>
            <div class="col-md-3">
              {{ Form::text('graduation_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion', 'required' => 'true', 'id' => 'graduation_year')) }}
            </div>
            <div class="col-md-2">
            {{ Form::select('graduation_stream', array('' => '--Course--', 'BE' => 'B.E', 'BSC' => 'B.Sc', 'BA' => 'BA', 'BCOM' => 'B.Com', 'BBM' => 'BBM', 'B.Tech' => 'B.Tech', 'Others' => 'Others'), '--Course--', array('class'=> 'form-control input-md', 'required' => 'true')) }}
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="post_graduation"> Post Graduation</label>  
            <div class="col-md-2">
            {{ Form::text('post_graduation_percentage', null, array('class'=>'form-control input-md','placeholder'=>'percentage', 'id' => 'post_graduation_percentage')) }}        
            </div>
            <div class="col-md-3">
              {{ Form::text('post_graduation_year', null, array('class'=>'form-control input-md','placeholder'=>'year of completion', 'id' => 'post_graduation_year')) }}
            </div>
            <div class="col-md-2">
            {{ Form::select('post_graduation_stream',  array('' => '--Course--', 'MTECH' => 'M.Tech', 'MSC' => 'M.Sc', 'MA' => 'MA', 'MCOM' => 'M.Com', 'MBA' => 'MBA', 'CA' => 'CA', 'Others' => 'Others'), '--Course--', array('class'=> 'form-control input-md', 'id' => 'post_graduation_stream')) }}
            </div>
          </div>
          <!-- Text input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="preferred_job_location">Preferred Job Location<span class="red font-bold"> *</span></label>  
            <div class="col-md-7">
            {{ Form::select('preferred_job_location', $location['preferred_job_location'] , Input::old('preferred_job_location'), array('class' => 'form-control input-md preferred_job_location', 'required' => 'true', 'id' => 'preferred_job_location')) }}
            </div>
          </div>

          <!-- File Button --> 
          <div class="form-group">
            <label class="col-md-4 control-label" for="resume" required="true">Upload Resume<span class="red font-bold"> *</span></label>
            <div class="col-md-4">
              {{ Form::file('resume') }}
            </div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" for="workex" > Work Experience 1 (If any)</label>
            <div id="append-div">
              <div class="col-md-2">
              <select class="form-control input-md" name="workarea[]">
                <option value="">--Select--</option>
                <option value="Sales - Banking & Fin Services">Sales - Banking & Fin Services</option>
                <option value="Non-Sales - Banking & Fin Services">Non-Sales - Banking & Fin Services</option>
                <option value="Others">Others</option>
              </select>
              </div>
              <div class="col-md-2">
              <input class="form-control input-md months" placeholder="in months" name="workex[]" type="text">
              </div>
              <div class="col-md-2 padd_null">
              <button id="addNew" class="btn btn-primary" > Add More </button>
              </div>
              <div class="col-md-2 padd_null">
              <button id="remove" class="btn btn-primary" > Remove </button>
              </div>
            </div>
          </div>
          <div id="workexappend"></div>

          <!-- Checkboxes (inline) -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="declaration"></label>
            <div class="col-md-7">
              <label class="checkbox-inline" for="declaration-0">
              {{ Form::checkbox('name', 'value', false, array('required' => 'true')) }}
              <!-- I hereby declare that the above details are true to the best of my knowledge. -->
              I confirm that, I have understood the job profile and the selection process. I also declare that the above details are true to the best of my knowledge.
              </label>
            </div>
          </div>
</div>
          <input id="job_id" name="job_id" type="hidden" value="1" >
          <div class="form-horizontal col-md-12" id="questionnarie" style="display:none;">
        <fieldset id="fieldsetappend" >
            <!-- Form Name -->
            <h5 class="paddb-border red font-bold"><span class="red1">Step 2:</span>To proceed, please answer the following & submit the application</h5>

            <p class="red font-bold" id="required_all">Please answer all the questions.</p>
           
            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">1. This is a field sales role.</label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q1','1','', array('id'=>'q1')) }}
                  {{ Form::label('1','I understand', array('style' => 'font-weight:normal'))}} 
            
                </div>
            </div>

            <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue">2. I will have to enrol for the FLIP Branch Sales Officer Program on clearing the interview and getting the provisional offer letter. </label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q2','1','', array('id'=>'q2')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                
                </div>
            </div>

             <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue" style="text-align:left;">3. I will have to pay Rs. 5,000 as program fee for the same within 3 days of getting the provisional offer letter. </label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q3','1','', array('id'=>'q3')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
              
                </div>
            </div>

    
             <div class="form-group">
              <div class="col-md-12">
                <label class="control-label blue" style="text-align:left;">4.  I will be able to join HDFC Bank only after successfully completing the FLIP Branch Sales Officer Program, within the stipulated time. </label>
              </div>
                <div class="col-md-11" style="margin-left:30px;font-weight:normal;">
                  {{ Form::radio('q4','1','', array('id'=>'first1')) }}
                  {{ Form::label('1','I agree', array('style' => 'font-weight:normal'))}} 
                </div>
            </div>

           
        </fieldset>
      </div>

        <!--   Button
         Button
          <div class="form-group">
            <label class="col-md-4 control-label" for="submit"></label>
            <div class="col-md-2">
              <button id="questionnarie1" name="questionnarie1" class="btn btn-lg btn-success btn-block button-padd">Proceed</button>
            </div>
          </div>
         -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="submit"></label>
            <div class="col-md-2">
              <button id="submit" name="submit" class="btn btn-lg btn-success btn-block button-padd submit_final"> Proceed </button>
            </div>
          </div>
            </fieldset>
          </form>
        </div>
        
       <div id="track" class="tab-pane">   
        <h4 class="paddb-border red font-bold">Track</h4>
         
       </div>

        <div id="interview" class="tab-pane">   
          <h4 class="paddb-border red font-bold">Interviews</h4>
          <!-- <p>Interviews for the first batch of Branch Sales Officer Program with HDFC Bank, for Delhi and Mumbai, have been completed.</p> -->
          <!-- <p>The interviews will be conducted in Delhi - NCR and Mumbai. You will be receiving your interview slot details (Date, time and venue) on your e-mail ID.</p>
          <p>Admit cards have been sent to eligible candidates, for the locations mentioned below.</p>-->
          <p>Please carry relevant documents:- Resume, ID Proof, 2 passport size photographs, original and photocopy of all your mark sheets, along with you. If you have worked with HDFC group companies, you are required to submit a relieving letter.</p>
          <h5>INTERVIEW SCHEDULE<span class="font-14"><!--  (For Mumbai, Navi Mumbai & Thane candidates): --> </span></h5>
          <table class="table-simple" border="1">
            <thead>
              <th class="font-bold">Location</th>
              <th class="font-bold" style="width:150px;">Date</th>
              <th class="font-bold">Address</th>
              <th class="font-bold" style="width:150px;">Contact Details</th>
            </thead>
            <tbody>
              <tr>
                <td>Chandigarh</td>
                <td>10 am, June 13, 2014</td>
                <td>HDFC Bank, SCO 145 – 146, Sector 17C, Chandigarh  </td>
                <td>Nitish - 9243 726 044</td>
              </tr>
             <!--  <tr>
               <td></td>
               <td></td>
               <td></td>
               <td class="font-bold"></td>
             </tr> -->
            </tbody>
          </table>
         <!--  <p>The interview schedule for other locations will be updated soon.</p>  -->
        </div>
       
        
        <div id="faq" class="tab-pane">   
          <h4 class="paddb-border red font-bold">FREQUENTLY ASKED QUESTIONS (FAQs)</h4>
          <h5 class="blue font-bold">1.<span class="paddl-5">What is the Branch Sales Officer (BSO) Certification Program?</span> </h5>
         
          <div class="paddl-20">
            <p>The BSO Certification Program, offered jointly by FLIP &amp; HDFC Bank, offers a candidate, the chance to start a successful career, with HDFC Bank. It involves four stages: </p>
            <ul class="alpha-ul">
              <li>Apply for the Sales Officer role, with HDFC Bank.</li>
              <li>Get interviewed; if selected, you will get a provisional offer letter.</li>
              <li>Start the required Branch Sales Officer training, to ensure you start performing, from Day One.</li>
              <li>Complete the training successfully; you will need to clear an online certification exam. You will then be awarded the industry - endorsed, <span class="font-bold">'Branch Sales Officer' Certification,</span> and will join the bank immediately.</li>
            </ul>
          </div>

          <h4 class="blue font-bold">About FLIP</h4> 
          <p><span class="font-bold">Finitiatives Learning India Pvt. Ltd. (FLIP: <a href="http://www.learnwithflip.com" target="_blank">www.learnwithflip.com</a>),</span> is a senior IIM alumni initiative. A young company, it has crossed 22,000 learners: students (including from all the IIMs), working professionals, Banks, FIs, IT companies &amp; Educational Institutions.</p>
          <p>FLIP offers, for the new generation, <span class="font-bold">an e-learning + faculty interaction</span> model; using a computer and internet connection, you can learn from anywhere, anytime. Its courses have won a <span class="font-bold">global award.</span></p>
          <p>It offers 21 job-oriented certifications, across banking &amp; financial services; including those in collaboration with the National Stock Exchange and Finacle of Infosys. They are used by jobseekers, to enhance their career prospects.</p>
          <p>Leading banks like HDFC Bank, Axis Bank, Kotak Mahindra Bank, etc. have signed contracts to 'prefer/give weightage' to a FLIP Certified Candidate.</p>

          <h5 class="blue font-bold">2. <span class="paddl-5">How and where is the Program conducted?</span></h5>

          <div class="paddl-20">
            <p>The BSO Certification Program, is conducted online. You will need a computer with an internet connection (or a Smart Phone!), and that's it. You can learn from anywhere, any time.<br>
                <span class="font-bold">After receiving your offer letter from HDFC Bank, you will enrol for the Program. You will receive a login-ID and password. Log in at www.learnwithflip.com,</span> for a friendly, flexible learning experience:
            </p>
            <ul class="alpha-ul">
              <li>Global-award winning, interactive <span class="font-bold">e-learning,</span> with <span class="font-bold">real-life</span> simulations. It's like being on the job! <small>(No more falling asleep in boring classes)</small></li>
              <li>Regular online sessions with faculty: once a week, talk to the faculty, watch role-plays, and get trained on the finer points of selling skills, via <span class="font-bold">web-classroom.</span></li>
              <li>E-mail &amp; live chat query support: Help is just a click away; you can mail us or come on live chat, to get your queries answered.</li>
            </ul>
          </div>

        <h5 class="blue font-bold">3.<span class="paddl-5">What is the recognition of the Program &amp; Certification?</span></h5>
        <div class="paddl-20">
          <p>All FLIP Certifications are recognized by India's leading banks and Financial Institutions. Thousands of students and working professionals, take FLIP Certifications, each year - even without the assurance of placements! For this program, a career with HDFC Bank is assured on successful completion. You can see the program, on HDFC Bank's website as well: (<a href="http://www.hdfcbank.com/aboutus/careers/sales_officer_program.htm" target="_blank">www.hdfcbank.com</a>)</p>
        </div>

       <h5 class="blue font-bold">4.<span class="paddl-5">What is the program fee?</span></h5>
       <div class="paddl-20">
         <p>The candidate will have to pay Rs. 5,000 as fee for the program.</p>
       </div> 
        
        <h5 class="blue font-bold">5.<span class="paddl-5">How can I make the payment?</span></h5>
        <div class="paddl-20">
          <p>When you enroll online at <a href="http://www.learnwithflip.com" target="_blank">www.learnwithflip.com,</a> for the Branch Sales Officer Certification Program, you can pay in the following ways: </p>
          <ul class="alpha-ul">
            <li>Online, via debit/credit card or net banking.</li>
            <li>By using a special deposit slip (you can download it during the enrolment process), and depositing a cheque or cash, at any Axis Bank branch in India.</li>
          </ul>
        </div>

        <h5 class="blue font-bold">6.<span class="paddl-5">What if I do not clear the BSO certification exam?</span></h5>
        <div class="paddl-20">
          <p> This program is for participants, who are serious about their career. <br>
            We will guide you at every stage; you will also take a mock exam, before the actual certification exam. <br>
            Candidates who do not complete the training, or get a low score in the mock exam, will be given special assistance, at no extra cost, before the certification.<br>
          </p>
        </div>

        <h5 class="blue font-bold">7.<span class="paddl-5">How can I take the BSO certification exam?</span></h5>
         <div class="paddl-20">
          <p> FLIP runs online testing centers, across India. You can book a slot, (4 slots per day, 6 days a week) and write the computer based exam, in any of these centers, on any convenient day. <br>
          </p>
        </div>

        <h5 class="blue font-bold">8.<span class="paddl-5">What is the Sales Officer role with HDFC Bank?</span></h5>
        <div class="paddl-20">
          <p>A bank's main business model, is to raise funds via deposits, opening of saving &amp; current account and lend them out at a higher rate.<br>
            Therefore, raising funds via deposits, is an <b>essential</b> part of the bank's business. HDFC Bank has a very strong focus on both raising deposits, and building a good relationship with its customers.<br>
            The Sales Officer <b>is the face of HDFC Bank.</b> S/he will represent the bank, to individual and business customers, and get deposits, current &amp; saving account for the bank, while ensuring that all required regulations are met.<br>
            S/he will also build a good relationship, by providing excellent service to the customer.
            <a href="#about" data-toggle="tab" class="about_role">Click here</a> for the detailed Job Description.
          </p>
        </div>

        <h5 class="blue font-bold">9.<span class="paddl-5">Where will I get my posting?</span></h5>
        <div class="paddl-20">
          <p>HDFC Bank prefers that, the candidate is posted in the area s/he knows well - hence, they will try and post him/her as close as possible, to his/her home.<br>
            However, this is conditional to the requirements at that time, and the candidate must be open to posting at any branch, within the specified location (Jaipur, Chandigarh, Lucknow and Pune).
          </p>
        </div>

        <h5 class="blue font-bold">10.<span class="paddl-5">Is this a transferable job?</span></h5>
        <div class="paddl-20">
          <p>It is not a transferable job, however, transfer from one to another branch in the same city is possible on business exigency. </p>
        </div>

        <h5 class="blue font-bold">11.<span class="paddl-5">Can I move to other roles, within the bank?</span></h5>
        <div class="paddl-20">
          <p>The possibility of role changes happen again on business exigency.</p>
        </div>

        <h5 class="blue font-bold">12.<span class="paddl-5">What is the career path for this job?</span></h5>
        <div class="paddl-20">
          <ul class="number-li">
            <li>Contract is renewal after 2 years if the Sales Officer is a consistent performer. </li>
            <li>A consistent performer Sales Officer for 2 years would be eligible to participate in the assessment program to become a permanent bank staff.</li>
          </ul>
        </div>

        <h5 class="blue font-bold">13.<span class="paddl-5">Will I get a permanent job with the bank after 2 years?</span></h5>
        <div class="paddl-20">
          <p>A consistent performer Sales Officer for 2 years would be eligible to participate in the assessment program to become permanent bank staff.<br>
          On successful completion of assessment program, Sales Officer get absorb as permanent bank staff depending upon existing vacancy for any position at front line level.</p>
        </div>

    </div>

      
      <div id="contact" class="tab-pane text-center"> 
        <h4><b>Contact Person: </b>Ratnesh</h4> 
        <h4><b>Contact : </b><a href="mailto:nitish@learnwithflip.com">nitish@learnwithflip.com</a></h4> 
        <h4><b>Call us: </b>+91 9243.666.001 / 002 / 003 or +91 9243.726.044 </h4>
      </div>


  </div>



  <div class="col-md-12 border padd-15">
    <div class="col-md-2 marg-cust pull-left align_center"> 
      <h4><b>Successfully<br> Placed by FLIP: <br>Similar Profiles</b></h4>
    </div>
    <div class="hscroll">
      <ul id="scroller" class="align_center">
        <li><img src="/assets/images/V-Sravani-Lakshmi.png" /><span>V Sravani Lakshmi</span><br>Axis Bank</li>
        <li><img src="/assets/images/Sangam-Aenki-Naidu.png" /><span>Sangam Aenki N</span><br>Axis Bank</li>
        <li><img src="/assets/images/B-Santosh-Kumar.png" /><span>B Santosh Kumar</span><br>Axis Bank</li>
        <li><img src="/assets/images/Ajay-Kumar-Chinthakindi.png" /><span>Ajay Kumar C</span><br>ING Vysya Bank</li>
        <li><img src="/assets/images/Suma-Ejjigani.png" /><span>Suma Ejjigani</span><br>ING Vysya Bank</li>
        <li><img src="/assets/images/Srikanth-Reddy-Komareddy.png" /><span>Srikanth R K</span><br>ING Vysya Bank</li>
        <li><img src="/assets/images/Sharath-Chandra-Reddy-Kasini.png" /><span>Sharath C R K</span><br>ING Vysya Bank</li>
        <li><img src="/assets/images/Ajay-Prashanth-Barla.png" /><span>Ajay Prashanth B</span><br>ING Vysya Bank</li>
        <li><img src="/assets/images/Deepjoy-Shome.png" /><span>Deepjoy Shome</span><br>HDFC Bank</li>
      </ul>           
    </div>
  </div>
  

<script>
  (function($) {
        $("#preferred_job_location option[value=9]").css('display','none');
        
        $('#questionnarie').css({'display':'none'});

        $('#bsop_form').submit("click",function(event) {
          
          $('#questionnarie').css({'display':'block'});
          $('#bsop').css({'display':'none'});
          $("#submit").html("Submit");

          if ($("input[name='q1']:checked").length == 0 || $("input[name='q2']:checked").length == 0 
            || $("input[name='q3']:checked").length == 0 || $("input[name='q4']:checked").length == 0 ) {
            //$('#myModal').modal('show');
              $('#required_all').css({'display':'block'});
              event.preventDefault();
              return false;
          }


        });
   
  })(jQuery);
</script>

    <img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
    <a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>
@stop
