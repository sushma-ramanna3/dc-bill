@extends('layouts.custom1')
@section('content')
  
  <!--   <div class="col-md-12 img_w padd_null"><img src="/assets/images/banner2.jpg" alt="banner" name="banner"/></div> -->
  <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <a class="navbar-brand" href="http://www.learnwithflip.com" target="_blank">
          <img src="/assets/images/fliplogo.png" alt="logo">
        </a>
        <ul class="nav navbar-nav col-md-9 align_center margin-navbar pull-left">
          <h1 id="job_page_title" style="font-size: 37px;margin-top: 23px;">Market Analyst (Non-Sales Role)</h1>
        </ul>
        </div>
      </div>
    </div>

	<div>
		<br><br><br>
		<center class="red1 font-bold paddb-border" style="font-size: 18px;" >All Registrations Closed</center>
	</div>
      <!-- <ul class="nav nav-pills padd-15" data-tabs="tabs" id="nav_li" style="padding-left:65px;">  
         <li class="active intro"><a href="#intro" data-toggle="tab">Introduction</a></li>   
          <li class="active about"><a href="#about" data-toggle="tab">Role / Eligibility</a></li>  
          <li class="sales"><a href="#program" data-toggle="tab">Program Details</a></li>  
          <li class="apply"><a href="#apply" data-toggle="tab">Apply</a></li>   
          <li class="last-item contact"><a href="#contact" data-toggle="tab">Contact Us</a></li>   
        </ul> -->  
      
      <!-- <div id="my-tab-content" class="tab-content padd-15 border-top">
        <div id="about" class="tab-pane active">   
          <h4 class="red1 font-bold paddb-border">About the Role</h4>
              <p><span class="blue font-bold" style="font-size: 15px;">Organisation:</span>  IndiaInfoline</p>
      
              <p><span class="blue font-bold" style="font-size: 15px;">Job Title:</span>&nbsp;Market Analysts (part of Research Support team)</p>
              
              <p>The objective is to bring research closer to HNI clients. IIFL is looking to build an additional layer, designated ‘Market Analyst’ who will work closely with the analysts and the product team and service premium clients. The ‘Market Analyst’ will report to the research and product desk and will be based in Mumbai or Delhi. Servicing will be across asset classes like fixed income, mutual funds, equity, insurance,etc.</p>
              <h5 class="blue font-bold">Detailed job description:</h5>
              <ul>
                <li>Asset allocation based on risk profile of customer</li>
                <li>Restructure client's portfolio across equity, mutual fund, fixed income, etc.</li>
                <li>Promote research backed fundamental ideas and products</li>
                <li>Recommend non-equity products</li>
                <li>Client report through meetings and holding statements</li>
                <li> Financial planning</li>
                <li>Grow Assets (Half yearly and yearly targets will be given for overall assets under advice)</li>
              </ul>
              <p style="font-style: italic; margin-top: 20px;">Market Analysts will be part of the support function. Job profile does not include revenue targets, acquisition or dealing. Please note that this is not a research analyst role.</p>
      
              <h5 class="blue font-bold">Qualification:</h5>
              <p>
                <b>FLIP certified Professional in <a href="https://www.learnwithflip.com/buy-now.html?category_id=2715&amp;category=Wealth-Management" target="_blank">Wealth Management</a></b> (If you are not a FLIP Wealth Management certified professional, get certified soon).
              </p>
              <h5 class="blue font-bold">Eligibility:</h5>
              <ul>
                <li>Graduate / Post graduate with 6 months - 5 years of relevant work experience and FLIP Wealth Management Certification</li>
                <li>Work experience should be in fields of Wealth management, financial advisor, selling of financial products like Mutual  Funds, Equities, bonds etc.</li>
                <li>Fresher should have MBA or CA as the highest qualification</li>
              </ul>
        
              <h5 class="blue font-bold">Skills needed:</h5>
              <p>We are looking for excellent communicators with a passion for client servicing and advising on portfolios.Knowledge of personal finance, mutual funds, taxation, debt market, insurance, stock market and portfolio management is necessary.</p>
      
            <h5 class="blue font-bold">Location:</h5>
            <p>Mumbai, Delhi, Gurgaon, Noida</p><h5 class="blue font-bold">CTC:</h5><p>Rs. 3 -7 lacs p.a + Performance based discretionary bonus, as decided by management.</p>
      
       </div>
      
      <div id="apply" class="tab-pane"> 
          @if($errors->has())
          <div id="form-errors" class="red">
            <p>The following errors have occurred:</p>
            <ul>
              @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>end form-errors
          @endif
          @if(Session::get('successful'))
          <div class="col-md-12 font-bold font-14 padd_null text-center panel panel-default" id="success-message">
            <div class="panel-heading">
              <p class="text-center" style="display:inline">Your have successfully applied for this job. Please check your mail for details. </p>
            </div>
           </div>
          @endif
          <form class="form-horizontal col-md-12" action="ApplicationsController@applyAnandRathi" method="post" enctype="multipart/form-data">
          {{ Form::open(array('action' => 'ApplicationsController@iifl', 'method' => 'post', 'class'=>"form-horizontal col-md-12", 'files'=> true )) }}
              <fieldset id="fieldsetappend" >
      
              Form Name
              <h4 class="paddb-border red1 font-bold">Application Form</h4>
              <div class="form-group">
                <div class="col-md-5">
                  {{ 'Fields marked as <span id="red" class="red font-bold"> *</span> are mandatory' }}
                </div>
              </div>
              Text input
              <div class="form-group">
                <label class="col-md-4 control-label" for="first_name">First Name<span id="red" class="red font-bold"> *</span> </label>  
                <div class="col-md-5">
                {{ Form::text('first_name', null, array('class'=>'form-control input-md','placeholder'=>'enter your first name', 'required' => 'true', 'id' => 'first_name')) }}
                </div>
              </div>
      
              Text input
              <div class="form-group">
                <label class="col-md-4 control-label" for="last_name">Last Name<span id="red" class="red font-bold"> *</span></label>  
                <div class="col-md-5">
                {{ Form::text('last_name', null, array('class'=>'form-control input-md','placeholder'=>'enter your last name', 'required' => 'true', 'id' => 'last_name')) }}  
                </div>
              </div>
      
              Text input
              <div class="form-group">
                <label class="col-md-4 control-label" for="email">Email ID<span id="red" class="red font-bold"> *</span></label>  
                <div class="col-md-5">
                {{ Form::text('email', null, array('class'=>'form-control input-md','placeholder'=>'enter your email', 'required' => 'true')) }}  
                  
                </div>
              </div>
      
            Text input
            <div class="form-group">
              <label class="col-md-4 control-label" for="phone">Phone Number<span id="red" class="red font-bold"> *</span></label>  
              <div class="col-md-5">
                {{ Form::text('phone', null, array('class'=>'form-control input-md','placeholder'=>'phone number','maxlength'=>'10', 'required' => 'true', 'id' => 'phone_number')) }}      
              </div>
            </div>
      
            Text input
            <div class="form-group">
              <label class="col-md-4 control-label" for="graduation">Highest Qualification<span id="red" class="red font-bold"> *</span></label>  
              <div class="col-md-5">
              {{ Form::select('highest_qualification_stream', array('' => '--Course--','graduate_engineering' => 'Graduation - Engineering', 'graduate_commerce' => 'Graduation - Commerce', 'graduate_others' => 'Graduation - Others','mba_nonfinance' => 'MBA (Non - Finance)', 'mba_finance' => 'MBA - Finance', 'postgraduate_others' => 'Post Graduation - Others', 'ca' => 'CA'), '--Course--', array('class'=> 'form-control input-md', 'required' => 'true')) }}
            </div>
          </div>
      
            <div class="form-group">
              <label class="col-md-4 control-label" for="preferred_job_location">Preferred Interview & Job Location<span id="red" class="red font-bold"> *</span></label>  
              <div class="col-md-7">
              {{ Form::select('preferred_job_location', $location['preferred_job_location'] , Input::old('preferred_job_location'), array('class' => 'form-control input-md preferred_job_location', 'required' => 'true', 'id' => 'preferred_job_location')) }}
              </div>
            </div>
          
            <div class="form-group">
              <label class="col-md-4 control-label" for="workex" > Are you FLIP Wealth Management certified candidate ? <span id="red" class="red font-bold"> *</span></label>
              <div class="col-md-4">
                <select name="WM_certified" id="Certified" class="form-control" required="true">
                  <option value="">--Select--</option>
                  <option value="Yes">Yes</option>
                  <option value="No">No</option>
                </select>
                {{ Form::select('WM_certified', array('' => '--Select--','Yes' => 'Yes', 'No' => 'No'), '--Select--', array('class'=> 'form-control input-md', 'required' => 'true')) }}
              </div>
            </div>
      
               File Button 
            <div class="form-group">
              <label class="col-md-4 control-label" for="resume">Upload Resume<span id="red" class="red font-bold"> *</span></label>
              <div class="col-md-4 marg-top">
                {{ Form::file('resume') }}
              </div>
            </div>
           
            <div class="form-group">
              <label class="col-md-4 control-label" for="workex" > Work Experience 1 (If any)</label>
              <div id="append-div">
                <div class="col-md-2">
                <select class="form-control input-md" name="workarea[]">
                  <option value="">--Select--</option>
                  <option value="Financial Advisor/ Planner">Financial Advisor/ Planner</option>
                  <option value="RM in a Bank">RM in a Bank</option>
                  <option value="RM in a Brokerage firm">RM in a Brokerage firm</option>
                  <option value="Wealth Manager">Wealth Manager</option>
                  <option value="Equity Research">Equity Research</option>
                  <option value="Sales role in Bank or FIs">Sales role in Bank or FIs</option>
                  <option value="Others">Others</option>
                </select>
                {{ Form::select('workarea[]', array('' => '--Select--','Financial Advisor/ Planner' => 'Financial Advisor/ Planner', 'RM in a Bank' => 'RM in a Bank', 'RM in a Brokerage firm' => 'RM in a Brokerage firm', 'Wealth Manager' => 'Wealth Manager', 'Others' => 'Others'), '--Select--', array('class'=> 'form-control input-md', 'required' => 'true')) }}
                </div>
                <div class="col-md-2">
                <input class="form-control input-md months" placeholder="in months" name="workex[]" type="text">
                </div>
                <div class="col-md-2 padd_null">
                <button id="addNew1" class="btn btn-primary" > Add More </button>
                </div>
                <div class="col-md-2 padd_null">
                <button id="remove" class="btn btn-primary" > Remove </button>
                </div>
              </div>
            </div>
            <div id="workexappend"></div>
      
            Checkboxes (inline)
            <div class="form-group">
              <label class="col-md-4 control-label" for="declaration"></label>
              <div class="col-md-7">
                <label class="checkbox-inline" for="declaration-0">
                {{ Form::checkbox('name', 'value', false, array('required' => 'true')) }}
                I hereby declare that the above details are true to the best of my knowledge.
                I confirm that, I have understood the job profile and the selection process. I alsoI declare that the above details are true to the best of my knowledge.
                </label>
              </div>
            </div>
      
            <input id="job_id" name="job_id" type="hidden" value="3" >
            Button
            <div class="form-group">
              <label class="col-md-4 control-label" for="submit"></label>
              <div class="col-md-2">
                <button id="submit" name="submit" class="btn btn-lg btn-success btn-block button-padd"> Apply </button>
              </div>
            </div>
              </fieldset>
            </form>
            {{ Form::close() }}
          </div>
          
         <div id="track" class="tab-pane">   
          <h4 class="paddb-border red font-bold">Track</h4>
           
         </div>
       
        <div id="contact" class="tab-pane text-center"> 
          <h4><b>Contact Person: </b>Nitish Prasad</h4> 
          <h4><b>Contact : </b><a href="mailto:ratnesh@learnwithflip.com">ratnesh@learnwithflip.com</a></h4> 
          <h4><b>Call us: </b>+91 9243.666.001 / 002 / 003 or +91 9243.726.044 </h4>
        </div>
      
        </div> -->
 
    <img src="https://static.ssl7.net/b/en/593d63ac79adbf4b07f4d587d475/1870b48f3f862dc82594ed0956d3a8f2.gif" style="cursor:pointer;border:none;top:150px;position:fixed;right:2px;" alt="Live Chat" onclick="window.open('https://ssl7.net/chat/en/593d63ac79adbf4b07f4d587d475/'+document.location.href,'','height=400,width=300,menubar=no, location=no,resizable=yes,scrollbars=no,status=yes');" />
    <a style="top:430px;position:fixed;right:-7px;" href="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Flearnwithflip&width=10px&layout=standard&action=like&show_faces=false&share=false&height=35"></a>
    <script type="text/javascript">

   (function($) {
        document.title = 'Market Analyst (Non-Sales Role)';
    })(jQuery);

</script>
@stop

<style>
  .hdfc, .iifl{
    display: none;
  }
  #nav_li>li {
    background: #001E74;
    width: 265px;
    text-align: center;
  }
 #nav_li>li.active>a, #nav_li>li.active>a:hover, #nav_li>li.active>a:focus, #nav_li>li a:hover {
    color: #fff;
    background-color:#EE0000;
  }
  .red1,  #red  {
    color: #EE0000;
  }
 
</style>



