@extends('layouts.main')

@section('content')
<div class="panel panel-default">
  <div class="panel-heading">Job Listings</div>
  <table class="table">
  <thead>
  	<td> Job ID </td>
  	<td> {{ $job->job_cat_id }} </td>
  </thead>
  <tbody>
    <tr>
  		<td> Job Title </td>
      <td><p> {{ $job->title }} </p> </td>
    </tr>
    <tr>
      <td> Job Description </td>
      <td><p> {{ $job->description }} </p> </td>
    </tr>
  	<tr>
  		<td> Action </td>
  		<td> {{ HTML::link("/applications/".$job->id, 'Apply', array('class'=>'btn btn-primary')) }} </td>
  	</tr>    
    </tbody>
  </table>
</div>
@stop