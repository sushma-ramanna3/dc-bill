@extends('layouts.main')
@section('content')
<div class="container">

  <nav class="navbar navbar-inverse">
    <div class="navbar-header">
      <a class="navbar-brand" href="{{ URL::to('jobs') }}">Job Alert</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="{{ URL::to('jobs') }}">View All Jobs</a></li>
      <li><a href="{{ URL::to('jobs/create') }}">Create a Job</a>
      <li><a href="{{ URL::to('users') }}">Users</a>
    </ul>
  </nav>

  <h1>All the Jobs</h1>

  <!-- will be used to show any messages -->
  @if (Session::has('message'))
    <div class="alert alert-info">{{ Session::get('message') }}</div>
  @endif
    <table class="table table-striped table-bordered">
      <thead>
        <tr>
          <td>ID</td>
          <td>Job ID</td>
          <td>Title</td>
          <td>Category</td>
          <td>LMS ID</td>
          <td>Product ID</td>
        <!--   <td width="40%">Description </td> -->
          <td>Publish</td>
          <td>Action</td>
          <!-- <td>Updated at</td> -->
        </tr>
      </thead>
      <tbody>
      @foreach($jobs as $key => $value)
        <tr>
          <td>{{ $value->id}}</td>
          <td>{{ $value->job_cat_id }}</td>
          <td>{{ $value->title }}</td>
          <td>{{ $value->category }}</td>
          <td>{{ $value->lms_id }}</td>
          <td>{{ $value->product_id }}</td>
        <!--   <td>{{ $value->description }}</td> -->
          <td>{{ $value->publish }}</td>
         <!--  <td>{{ $value->created_at }}</td>
         <td>{{ $value->updated_at }}</td> -->

          <!-- we will also add show, edit, and delete buttons -->
          <td>

            <!-- delete the job (uses the destroy method DESTROY /jobs/{id} -->

            @if(Auth::check() && Auth::user()->usertype == 'admin')
            {{ Form::open(array('url' => 'jobs/' . $value->id, 'class' => 'pull-right')) }}
            {{ Form::hidden('_method', 'DELETE') }}
            {{ Form::submit('Delete', array('class' => 'btn btn-warning')) }}
            {{ Form::close() }}
            @endif

            <!-- show the job (uses the show method found at GET /jobs/{id} -->
            <a class="btn btn-small btn-success" href="{{ URL::to('jobs/' . $value->id) }}">View</a>

            <!-- edit this job (uses the edit method found at GET /jobs/{id}/edit -->
            @if(Auth::check() && Auth::user()->usertype == 'admin')
              <a class="btn btn-small btn-info" href="{{ URL::to('jobs/' . $value->id . '/edit') }}">Edit</a>
            @endif

          </td>
        </tr>
      @endforeach
      </tbody>
    </table>
</div>
@stop