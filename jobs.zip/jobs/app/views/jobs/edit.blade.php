@extends('layouts.main')
@section('content')
<div class="container">
  <nav class="navbar navbar-inverse">
    <div class="navbar-header">
      <a class="navbar-brand" href="{{ URL::to('jobs') }}">Job Alert</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="{{ URL::to('jobs') }}">View All Jobs</a></li>
      <li><a href="{{ URL::to('jobs/create') }}">Create a Job</a>
    </ul>
  </nav>

  <h1>Create a job</h1>
  <!-- if there are creation errors, they will show here -->
  {{ HTML::ul($errors->all()) }}

  {{ Form::model($job, array('route' => array('jobs.update', $job->id), 'method' => 'PUT')) }}

    <div class="form-group">
      {{ Form::label('job_cat_id', 'Job ID') }}
      {{ Form::text('job_cat_id', null, array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
      {{ Form::label('title', 'Title') }}
      {{ Form::text('title', null, array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
      {{ Form::label('category', 'Category') }}
      {{ Form::select('category', array('0' => 'Select a Category', 'AnandRathi' => 'AnandRathi', 'India Infoline' => 'India Infoline', 'Kotak Bank' => 'Kotak Bank', 'HDFC Bank' => 'HDFC Bank', 'Axis Bank' => 'Axis Bank'), null, array('class' => 'form-control')) }}
    </div>
  
    <div class="form-group">
      {{ Form::label('lms_id', 'Course LMS ID') }}
      {{ Form::text('lms_id', Input::old('lms_id'), array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
      {{ Form::label('product_id', 'Product ID') }}
      {{ Form::text('product_id', Input::old('product_id'), array('class' => 'form-control')) }}
    </div>
    
    <div class="form-group">
      {{ Form::label('description', 'Description') }}
      {{ Form::textarea('description', null, array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
      {{ Form::label('publish', 'Publish') }}
      <!-- {{ Form::checkbox('publish', null, array('class' => 'form-control')) }} -->
      {{ Form::checkbox('publish', '1', null) }}
    </div>

    {{ Form::submit('Edit', array('class' => 'btn btn-primary')) }}

  {{ Form::close() }}
</div>
@stop