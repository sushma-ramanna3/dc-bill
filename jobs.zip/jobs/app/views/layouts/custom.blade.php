<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>BRANCH SALES OFFICER PROGRAM</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <!--  <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css"> -->
       <!--  <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap-responsive.min.css"> -->
        <link rel="stylesheet" href="/packages/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/assets/hslider.css" />
        <link rel="stylesheet" href="/assets/custom.css">
		<style type="text/css">
			@media (min-width: 960px) {
				.container, .navbar-static-top .container, .navbar-fixed-top .container, .navbar-fixed-bottom .container{
					width:960px;
					border: 1px solid #ccc;
				}
				.nav h1{
					margin: 5px 0;
					font-weight: bold;
					font-family: impact;
				}
				.navbar>.container .navbar-brand {
					margin-left: 0;
				}
				.padd-15{
					padding:5px 10px;
				}
			}
			
			@media only screen and (max-width: 320px) {
				h1, .h1 {
					font-size: 20px;
					margin-top: 0;
				}
			}

			@media only screen and (max-width: 400px) {
			    h1, .h1 {
					font-size: 20px;
					margin-top: 0;
				}
			} 

			@media only screen and (max-width: 900px) {
			    h1, .h1 {
					font-size: 30px;
				}
			}

      .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus, .nav-pills>li a:hover {
        color: #fff;
        background-color: #001E74;
      }

		</style>
        <script src="/packages/bootstrap/js/vendor/jquery-1.10.1.min.js"></script>
        <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="/assets/placeholders.min.js"></script>
        <script src="/assets/bootstrap/js/bootstrap-tab.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
         <!--  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
         </button> -->
          <a class="navbar-brand" href="http://www.learnwithflip.com" target="_blank">
          <img src="/assets/images/fliplogo.png" alt="logo" /></a>
          <ul class="nav navbar-nav col-md-7 align_center margin-navbar pull-left headerwidth">
          <h1 id="custom_h1">BRANCH SALES OFFICER PROGRAM</h1></ul>
	        <a class="navbar-right hdfc border pull-right" href="#"><img src="/assets/images/hdfc_logo.png" alt="HDFC" /></a>
        </div>
       <!--  <div class="navbar-collapse collapse">
       </div> --><!--/.navbar-collapse -->
      </div>
    </div>
    <br><br><br><br><br>

    <div class="container padd_null">
      @if(Session::get('flash_message'))
        <div class="alert alert-success ">
          {{ Session::get('flash_message') }}
        </div>
      @endif
      
      @yield('content')
      <hr>

      <footer>
        <div class="padd-15"><span class="pull-left">&copy; Finitiatives Learning India Pvt. Ltd. 2014</span><span class="pull-right">Contact : <a href="mailto:nitish@learnwithflip.com">nitish@learnwithflip.com</a> | Call us:+91 9243.666.001 / 002 / 003 or +91 9243.726.044 </span></div>
      </footer>

    </div> <!-- /container -->
     <script type="text/javascript" src="/assets/jquery.simplyscroll.js"></script>
	 <script src="/packages/bootstrap/js/vendor/bootstrap-filestyle.min.js"></script>
	 <script src="/packages/bootstrap/js/main.js"></script>
   <script src="/assets/custom.js"></script>
    <script>
        var _gaq=[['_setAccount','UA-11854742-1'],['_trackPageview']];
        (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
        g.src='//www.google-analytics.com/ga.js';
        s.parentNode.insertBefore(g,s)}(document,'script'));
    </script>
    </body>
</html>
