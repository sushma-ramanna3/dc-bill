<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>FLIP BRANCH SALES OFFICER PROGRAM</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <!--  <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css"> -->
        <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="/packages/bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" href="/assets/datepicker/css/datepicker.css" /> 
         <link rel="stylesheet" href="/assets/main_blade_custom.css">
         <!--  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css"> -->
        <script src="/packages/bootstrap/js/vendor/jquery-1.10.1.min.js"></script>
        <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="/assets/bootstrap/js/bootstrap-tab.js"></script>
        <script src="/assets/datepicker/js/bootstrap-datepicker.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">FLIP Job Portal</a>
        </div>
         @if(Auth::check() && Auth::user()->usertype == 'admin')
        <div class="navbar-collapse collapse  pull-right">
          <ul class="nav navbar-nav">
            <li><a href="/logout">Logout</a></li>
          </ul>
        </div><!--/.navbar-collapse -->
        @endif
      </div>
    </div>
    <br><br><br><br>
    <div class="container">
      @if(Session::get('flash_message'))
        <div class="alert alert-success ">
          {{ Session::get('flash_message') }}
        </div>
      @endif
      
      @yield('content')
      <hr>

      <footer>
        <p>&copy; Finitiatives Learning India Pvt. Ltd. 2014</p>
      </footer>

    </div> <!-- /container -->
     
    <script src="/packages/bootstrap/js/vendor/bootstrap-filestyle.min.js"></script>

    <script src="/packages/bootstrap/js/main.js"></script>
   

    <script>
        var _gaq=[['_setAccount','UA-11854742-1'],['_trackPageview']];
        (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
        g.src='//www.google-analytics.com/ga.js';
        s.parentNode.insertBefore(g,s)}(document,'script'));
    </script>
    </body>
</html>