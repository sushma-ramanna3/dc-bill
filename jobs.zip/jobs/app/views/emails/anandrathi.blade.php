<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <p>Dear {{$name}},</p>
        @if ($register_value == 0)
        <p>Thank you for your job application to the above program. <br>You have completed Step 1 for applying to this job. The next step is to enroll/purchase the Wealth Management program by making a payment of 4250+S.Tax.</p>
        <p><b>Selection Process:</b></p>
        <p>1. Apply > 2. Enroll /Purchase the Program > 3. Clear Certification Exam > 4. Clear Interview > 5. Join</p>
        <p><b>Steps to enroll/purchase the program:</b></p>
        <ol>
            <li>Click on this link <a href="http://www.learnwithflip.com/buy-now.html?category_id=2715&category=Wealth-Management-GI" class="btn btn-primary">Enroll</a></li>
            <li>Click on Add to cart</li>
            <li>Click ‘Login’ & fill your login details as mentioned below</li>
            <li>Click on Add to Cart again and proceed</li>
            <li>Follow the purchase process</li>
        </ol>
        <p><b>Your login details are:</b></p>
        <p>User Name – <?php echo $user_details[0]->email ?><br>
        Password – <?php echo $user_details[0]->switch_pass ?></p>

        @elseif($register_value == 1)
        <p>Thank you for your job application to the above program. <br>You have completed Step 1 for applying to this job. The next step is to enroll/purchase the Wealth Management program by making a payment of 4250+S.Tax.</p>
        <p><b>Selection Process:</b></p>
        <p> 1. Apply > 2. Enroll /Purchase the Program > 3. Clear Certification Exam > 4. Clear Interview > 5. Join</p>
        <p><b>Steps to enroll/purchase the program:</b></p>
        <ol>
            <li>Click on this link <a href="http://www.learnwithflip.com/buy-now.html?category_id=2715&category=Wealth-Management-GI" class="btn btn-primary">Enroll</a></li>
            <li>Click on Add to cart</li>
            <li>Click ‘Login’ & fill your login details as mentioned below</li>
            <li>Click on Add to Cart again and proceed</li>
            <li>Follow the purchase process</li>
        </ol>
        <p>*If you, do not remember your login details (username/password), please contact us at support@learnwithflip.com or ask for help on LIVE Chat.</p>
 
        @elseif($register_value == 2)
            <p>Thank you for your job application to the above program. <br>We will review your application and update you on the next process. Please keep checking your mails.</p>
        @endif
        <p>For any queries, please contact us at support@learnwithflip.com or call 09243.666.001/002/003 or 0 9243.726.044</p>

        <p>Thanks,<br>
        Nitish<br>
        Team FLIP [www.learnwithflip.com]</p>

    </body>
</html>