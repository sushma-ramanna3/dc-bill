<div class="panel panel-default">
  <div class="panel-heading">Payment Details</div>
  <table class="table">
  <tbody>
    <tr>
      <td> Transaction Status </td>
      <td> {{ $transaction_response_message }} </td>
    </tr>
    <tr>
		<td> Transaction ID </td>
    	<td> {{ $merchant_transaction_id }} </td>
    </tr>
    <tr>
      <td> Transaction Amount </td>
      <td> {{ $transaction_amount }} </td>
    </tr>
    <tr>
      <td> Transaction Amount </td>
      <td> {{ $transaction_time }} </td>
    </tr>
    @if($payment_method == 'CREDIT')
    <tr>
      <td> Payment Method </td>
      <td> Debit / Credit Card </td>
    </tr>
    @endif
  </tbody>
  </table>
</div>