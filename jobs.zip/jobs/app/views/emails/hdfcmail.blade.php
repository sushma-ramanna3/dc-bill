<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <p>Dear {{$name}},</p>
        <!-- not eligible -->
       @if ($status == 'applied')
            <p>Thank you for your job application to <b>{{$job_title}}</b> with HDFC Bank. </p>
            <p>
                Your Reference Id for this job application: {{$reference_id}}</p>
            <p><b><u>Note: Please use this  ID, for all future communication with us.</u></b></p>

            <p>Your application status through the entire process can be tracked using this URL
                    <br>
                {{$track_url}}
            </p>
            <p>
                Step 1: Click on the tracking URL/Link <a href="<?php echo $track_url; ?>"><u>{{$track_url}}</u></a><br>
                Step 2: Enter your reference ID and Email ID<br>
                Step 3: Click on Next<br>
            <p>
            </p>You will be able to check the latest update on your application. </p>
			
		<!-- eligible and not filled questionnarie-->

        @elseif ($status == 20)
            <p>We are happy to inform you that your application meets the eligibility criteria for <b>{{$job_title}}</b> 
            but you have not completed the registration process. Please complete the process.
			</p>
            <p>There are limited seats!</p>
			<p>Please follow the steps below to complete the registration:</p>
            <p>
                Step 1: Click on the tracking URL/Link <a href="<?php echo $track_url; ?>"><u>{{$track_url}}</u></a><br>
                Step 2: Enter your reference ID and Email ID<br>
                Step 3: Click on Next<br>
            <p>
            <p>Your Reference Id is: {{$reference_id}}</p>

		<!-- eligible and filled questionnarie and not paid-->

         @elseif ($status == 22)
            <p>We are happy to inform you that your application meets the eligibility criteria for <b>{{$job_title}}</b> 
            but you have not completed the registration process. Please complete the process by paying the registration fee of INR 750.</p>
            
            <p>There are limited seats!</p>
            
            <p>Please follow the steps below to complete the registration:</p>

            <p>
                Step 1: Click on the tracking URL/Link <a href="<?php echo $track_url; ?>"><u>{{$track_url}}</u></a><br>
                Step 2: Enter your reference ID and Email ID<br>
                Step 3: Click on Next<br>
            <p>
			
			<p>Your Reference Id is: {{$reference_id}}</p>


		<!-- eligible and filled questionnarie and paid-->

        @elseif ($status == 24)
            <p>Thank you for applying for <b>{{$job_title}}</b>. You will receive <b>Online Test</b> details shortly.<br>
               Please check your inbox regularly.</p>

            <p>Your Reference Id for this job application is: {{$reference_id}}</p>

            <p><b><u>Note: Please use this ID, for all future communication with us.</u></b></p>

            <p>Your application status through the entire process can be tracked using this URL.<br>
             <a href="<?php echo $track_url; ?>"><u>{{$track_url}}</u></a>
            </p>

            <p>
                Step 1: Click on the tracking URL/Link <a href="<?php echo $track_url; ?>"><u>{{$track_url}}</u></a><br>
                Step 2: Enter your reference ID and Email ID<br>
                Step 3: Click on Next<br>
            <p>
            <p>You will be able to check the latest update on your application.</p>


		<!-- online test cleared -->

        @elseif ($status == 25)
            <p>Congratulations!</p>
            <p>You have successfully cleared online test with HDFC Bank for <b>{{$job_title}}</b>. 
                You are now one step closer to start your career with HDFC Bank.
            </p>
            <p><b>What happens now?</b></p>
            <p>Soon, we will schedule your interview with HDFC Bank. You will receive the details in your mail.</p>
            <p><b>Interview Preparation</b></p>
            <ul>
                <li><b>Interview Prep Pack:</b> Please download your interview prep pack by clicking <a href="<?php echo $prep_link;?>"><u><b>here</b></u></a>.<br> 
                Candidates are requested to use the provided preparatory materials in addition to the regular interview preparation. </li>
                <li><b>Mandatory Online Preparatory session:</b> You will soon be invited for a mandatory online interview preparatory session. 
                The details will be sent to your mail.</li>
            </ul>
            <p>All the best for your preparation.</p>


        <!-- online test failed -->

        @elseif ($status == 26)
            <p>With regards to your online test with HDFC Bank for <b>{{$job_title}}</b>, 
            we regret to inform you that you have not cleared the test, hence we will not be able to go ahead with your candidature.  </p>

            <p>Thank you, for your interest and application. We extend our best wishes for all your future endeavors.</p>

        @endif


            <p>For any queries, please contact us ratnesh@learnwithflip.com or call 09035.026.044/ 09243.666.002/003</p>

            <p>Regards,<br>
            Ratnesh Dubey<br>
            <span style="color:#0070C0;"><b>Finitiatives Learning India Pvt. Ltd./FLIP</b><br>
            Cell: +91. 9243666002/3</span><br>
            <a href="www.learnwithflip.com ">www.learnwithflip.com</a>
            <!-- Team FLIP --></p>

    </body>
</html>