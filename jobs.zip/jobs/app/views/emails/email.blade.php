<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <p>Dear {{$name}},</p>
       @if ($status === "Applied")
            <p>Thank you for your job application to the program.<!-- {{$job_title}} in association with {{$category}}. --> </p>
            <p>
                Your Reference Id for this job application: {{$reference_id}}<br>
                <b><u>Note: Please use this  ID, for all future communication with us.</u></b><br>
                    If your application meets the eligibility criteria as specified by the bank, you will receive an email asking you to confirm your availability for the interview.<br>
                    Your application status through the entire process can be tracked using this URL
                    <br>
                {{$track_url}}
            </p>
            <p><!-- <span style="color: #ec1c24;"><b>How to use your Reference ID:</b></span><br> -->
                Step 1: Click on the tracking URL/Link<br>
                Step 2: Enter your reference ID and Email ID<br>
                Step 3: Click on Next<br>
                You will be able to check the latest update on your application.
            </p>

        @elseif ($status === "Eligible")
            <p>We are happy to inform you that your application meets the eligibility criteria stipulated by the institution.<br>
                As mentioned, please click on the button below to confirm your interest and availability for the interview process.</p>
            <p>Please note that confirmation is mandatory for us to forward your application to {{$category}}.</p>
            <p>By clicking on the button below, you agree that you have understood the process and</p>
            <ul style="list-style-type: decimal;">
                <li>You know that this is a Branch Sales Officer role involving field sales.</li>
                <li>To get the final offer, you have to successfully complete the Branch Sales Officer Certification Program</li>
                <li><b>Program Fee:</b> INR 5,000 to be paid by the candidate.
                    <!-- <br> Instalment 1: INR 1,999 after getting the provisional offer letter, and<br>
                    Instalment 2: INR 3,001 on clearing the certification. --></li>
            </ul>
            <!-- <p><b>Note:</b> {{$category}} will reimburse the entire fee of INR 5,000 after you successfully complete 3 months with the bank.</p> -->
            <p style="margin:25px;"><a style="padding:9px 18px;background: #FFFF00;border: 1px solid #000;margin:25px;color:#000;text-decoration:none;" href="{{ $track_url }}"><b>Click to login & confirm</b></a></p>
            <p>Your Reference Id for this job application is: {{$reference_id}}</p>
            <p>Basis your confirmation, you will receive the interview date, time and location.</p>

         @elseif ($status === "Not Eligible")
            <p>Thank you for your interest.<br>
                We regret to inform you that your application does not meet the eligibility criteria as stipulated by the institution.<br>
                We will get in touch with you, if there are similar opportunities in the future.
            </p>

        @elseif ($status === "Confirmed Application")
            <p>Please find your interview details below:</p>
            <p><b>Date (DD-MM-YYYY) :</b> {{$interview_date}} [ {{$interview_day}} ]<br>
                <b>Slot/Time :</b> {{$interview_time}}<br>
                <b>Location :</b> {{$interview_location}}
            </p>
            <p><b>Please carry the below documents:</b></p>
            
            <ul style="list-style-type: decimal;">
                <li>Updated resume along with 2 recent color passport size photographs.</li>
                <li>Original and photocopy of passing certification or mark sheet of highest education.</li>
                <li>If you have worked with HDFC group companies, you are required to submit relieving letter.</li>
            </ul>

            <p>You must reach the interview location 15 minutes before the given time.</p>
            <p>Please click on the button below and confirm your attendance for the interview.</p>
            
            <p>By clicking on the button below, you agree that you have understood the process and</p>
            
            <ul style="list-style-type: decimal;">
                <li>You know that this is a Branch Sales Officer role involving field sales.</li>
                <li>To get the final offer, you have to successfully complete the Branch Sales Officer Certification Program</li>
                <li><b>Program Fee:</b> INR 5,000 to be paid by the candidate.<!-- <br>
                    Instalment 1: INR 1,999 after getting the provisional offer letter, and<br>
                    Instalment 2: INR 3,001 on clearing the certification. --></li>
            </ul>

            <p style="margin:25px;"><a style="padding:9px 18px;background: #FFFF00;border: 1px solid #000;margin:25px;color:#000;text-decoration:none;" href="{{ $track_url }}"><b>Click to login & confirm</b></a></p>
            <p>Please note that confirmation is mandatory to participate in the interview process.</p>
            <p>Your Reference Id for this job application is: {{$reference_id}}</p>

            <p>Don't forget to read the <b>BSOP Interview Preparation Kit</b> before the interview. Click on the below link to download the kit.</p>

            <p><span style="color: #ec1c24;"><b>Link</b></span> - <a href="http://learnwithflip.com/FLIP/FLIP-BSOP-Interview-Preparation.pdf">http://learnwithflip.com/FLIP/FLIP-BSOP-Interview-Preparation.pdf</a></p>

        @elseif ($status === "Cleared" )
            <p>Congratulations!<br>
                You have cleared the interview. You would have received your provisional offer letter soon.<br>
                Now, you need to enrol and successfully complete the {{$job_title}}, to be eligible for the final offer letter.
            </p>
            <p>Congratulations again and All the Best!</p>
                
            <p style="margin:25px;">
                <a style="padding:9px 18px;background: #FFFF00;border: 1px solid #000;margin:25px;color:#000;text-decoration:none;" href="{{ $enrol_url }}"><b>Click here to enroll for the program</b></a>
            </p>
            <p>Your Reference Id for this job application is: {{$reference_id}}</p>



        @elseif ($status === "Rejected")
            <p>We regret to inform you that, you did not clear the interview round.<br>
                We will get in touch with you, if there are similar opportunities in the future.
            </p>
           <!--  <p style="padding-left:25px;">
               1. Smart Banker Program [ <a href="http://www.learnwithflip.com/buy-now.html?category_id=2763&category=Smart-Banker-Program">View Details</a> ]<br>
               2. F&B India [ <a href="http://www.learnwithflip.com/buy-now.html?category_id=2713&category=Finance-and-Banking-Fundamentals-India">View Details</a> ]<br>
               3. Branch Banking & Retail Liabilities [ <a href="http://www.learnwithflip.com/buy-now.html?category_id=2720&category=Branch-Banking-and-Retail-Liabilities">View Details ]</a><br>
           </p> -->
        @endif

            <p>For any queries, please contact us at bsop@learnwithflip.com or call 09243726044 / 09243.666.002/003</p>

            <p>Thanks,<br>
            Nitish<br>
            Team FLIP</p>

    </body>
</html>