@extends('layouts.main')
@section('content')
 
  <h1>Admin Dashboard</h1>
  @if(HTML::ul($errors->all()))
    <div id="form-errors" class="alert alert-block red">
      {{ Session::get('error') }} 
      {{ HTML::ul($errors->all()) }}
    </div>
  @elseif(Session::get('success'))
    <div class="alert alert-success alert-block">
      {{ Session::get('success') }} 
    </div>
  @elseif(Session::get('message')) 
    <div class="alert alert-info alert-block">
      {{ Session::get('message') }} 
    </div>
  @elseif(Session::get('warning')) 
    <div class="alert alert-warning alert-block">
      {{ Session::get('warning') }} 
    </div>
  @endif

  <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
    <li class="active users"><a href="#users" data-toggle="tab">User List</a></li>
    <li class="upload"><a href="#upload" data-toggle="tab">Upload/Status Change</a></li>
    <li class="download"><a href="#download" data-toggle="tab">Download</a></li>
    <li class="mail"><a href="#mail" data-toggle="tab">Send Mail</a></li>
    <li class="tj"><a href="#tj" data-toggle="tab">Users Upload</a></li>
    <!-- <li class="certification"><a href="#certification" data-toggle="tab">Certification Status Update</a></li> -->
    <li><a href="/jobs">Jobs</a></li>
    <li><a href="/hdfc">HDFC Jobs</a></li>
  </ul>

  <div id="my-tab-content" class="tab-content">
    <div id="users" class="tab-pane active col-md-12">   
      <?php 
        $page = Input::get('page', 1);
        $i = (10 * ($page -1)) + 1;
      ?>
      {{ Form::open(array('url' => '/users')) }} <!-- Fliters --> 
        <div class="form-group col-md-12 marg-top" id="cv-filter" style="padding: 0px;">
          <div class="col-md-12">
            <div class="pull-left marg-right">
              {{ Form::label('application_id', 'Application ID') }}
              {{ Form::text('application_id', Input::get('application_id')) }}
            </div>
            <div class="pull-left marg-right">
              {{ Form::label('reference_id', 'Reference ID') }}
              {{ Form::text('reference_id', Input::get('reference_id')) }}
            </div>
            <div class="pull-left marg-right">
              {{ Form::label('email', 'Email') }}
              {{ Form::text('email', Input::get('email')) }}
            </div>
             <div class="pull-left marg-right">
              {{ Form::label('job_cat_id', 'Job ID') }}
             <!--  {{ Form::text('job_cat_id', Input::get('job_cat_id')) }} -->
              {{ Form::select('job_cat_id', $users['job_ids'], Input::get('job_cat_id')) }}
            </div>
          </div>
          <div class="col-md-12">
            <div class="pull-left marg-right">
              {{ Form::label('status', 'Status') }}
              {{ Form::select('status', $users['application_status'], Input::get('status')) }}
            </div>
            <div class="pull-left marg-right">
              <button class="btn btn-danger pull-left marg-right white" type="reset"><a href="/users">Reset</a></button>
            </div>
            <div class="pull-left marg-right">
              {{ Form::submit('Filter', array('class' => 'btn btn-primary')) }}
            </div>
            {{ Form::close() }}
          </div>
        </div>
     <div class="col-md-12">
       <div class="col-md-2"><b>Applied -</b> {{ $users['users_applied'] }}</div>
       <div class="col-md-2"><b>Eligible -</b> {{ $users['users_eligible'] }}</div>
       <div class="col-md-2"><b>Confirmed -</b> {{ $users['users_confirmed'] }}</div>
       <div class="col-md-3"><b>Attending Interview -</b> {{ $users['users_attending_interview'] }}</div>
       <div class="col-md-2"><b>Interview Cleared -</b> {{ $users['users_cleared'] }}</div>
     </div> 
      {{$users['pagination']}}

      <table class="table table-striped table-bordered marg-top">
        <thead>
          <tr>
            <td>Sl.No.</td>
            <td>Application ID</td>
            <td>Reference ID</td>
            <td>Name</td>
            <td>Email</td>
            <td>Phone</td>
            <td>Job ID/Category</td>
            <td>Current Status</td>
            <td>Last Action Time</td>
            <td>CV download</td>
          </tr>
        </thead>
        <tbody>

          @foreach($users['users'] as $key => $value)
            <tr>
              <?php $reference_id = md5($value->application_id);
                    $reference_id = strtoupper(substr($reference_id, 0, 8));?>
              <td>{{ $i++ }}</td>
              <td>{{ $value->application_id }}</td>
              <td>{{ $reference_id }}</td>
              <td>{{ $value->first_name.' '.$value->last_name }}</td>
              <td>{{ $value->email }}</td>
              <td>{{ $value->phone }}</td>
              <td>{{ $value->job_cat_id.'/'.$value->category }}</td>
              <td>{{ $value->status }}</td>
              <td>{{ $value->updated_at }}</td>
              <td>{{ "<a href='/cvdownload/".$value->application_id."'>CV download</a>" }}</td>
            </tr>
          @endforeach

        </tbody>
      </table>
      
    </div>
   
    <div id="upload" class="tab-pane">

      {{ Form::open(array('url' => '/runEligibility')) }} 
      <h4>Eligible Conditions:</h4>
      <div class="form-group col-md-12 padd_null">
      <div class="col-md-12 marg-top">
        <div class="pull-left marg-right">
          {{ Form::label('sslc_percentage', '10 % &nbsp;', array('class' => 'pull-left')) }}
          <div class="pull-left cust-col">
            {{ Form::text('sslc_percentage', Input::old('sslc_percentage'), array('class' => 'form-control', 'maxlength' => '2')) }}
          </div>
        </div>
        <div class="pull-left marg-right">
          {{ Form::label('puc_percentage', '12 %&nbsp;', array('class' => 'pull-left')) }} 
          <div class="pull-left cust-col">
            {{ Form::text('puc_percentage', Input::old('puc_percentage'), array('class' => 'form-control', 'maxlength' => '2')) }}
          </div>
        </div>
        <div class="pull-left marg-right">
          {{ Form::label('graduation_percentage', 'Graduation %&nbsp;', array('class' => 'pull-left')) }} 
          <div class="pull-left cust-col">
            {{ Form::text('graduation_percentage', Input::old('grrduation_percentage'), array('class' => 'form-control', 'required' => 'true', 'maxlength' => '2')) }}
          </div>
        </div>
        <div class="pull-left marg-right">
          {{ Form::label('post_graduation_percentage', 'Post Graduation %&nbsp;', array('class' => 'pull-left')) }} 
          <div class="pull-left cust-col">
            {{ Form::text('post_graduation_percentage', Input::old('post_graduation_percentage'), array('class' => 'form-control', 'maxlength' => '2')) }}
          </div>
        </div>
        <div class="pull-left marg-right">
          {{ Form::label('job_cat_id', 'Job ID&nbsp;', array('class' => 'pull-left')) }} 
          <div class="pull-left cust-col job_id">
            <!-- {{ Form::text('job_cat_id', Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }} -->
            {{ Form::select('job_cat_id', $users['job_ids'] , Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }}
          </div>
        </div>
       </div>

       <div class="col-md-12 marg-top1">

          <div class="pull-left marg-right">
            {{ Form::label('agefrom', 'Age Min&nbsp;', array('class' => 'pull-left')) }} 
            <div class="pull-left cust-col">
                {{ Form::selectRange('agefrom', 20, 30, null, array('class'=>'form-control')); }}
            </div>
          </div>

          <div class="pull-left marg-right">
            {{ Form::label('ageto', 'Age Max&nbsp;', array('class' => 'pull-left')) }} 
            <div class="pull-left cust-col">
                {{ Form::selectRange('ageto', 20, 30, null, array('class'=>'form-control')); }}
            </div>
          </div>
          <div class="pull-left marg-right">
            {{ Form::label('graduation_year', 'Graduation Year&nbsp;', array('class' => 'pull-left')) }} 
            <div class="pull-left select_year">
              <select class="form-control input-md" name="graduation_year">
                <option value="">--Select--</option>
                <option value="2013">2013</option>
                <option value="2014">2014</option>
                <option value="2015">2015</option>
              </select>
            </div>
          </div>

          <div class="pull-left marg-right">
            {{ Form::label('workarea', 'Work Area&nbsp;', array('class' => 'pull-left')) }} 
            <div class="pull-left work_area">
              <select class="form-control input-md" name="workarea">
                <option value="">--Select--</option>
                <option value="Sales - Banking & Fin Services">Sales - Banking & Fin Services</option>
                <option value="Non-Sales - Banking & Fin Services">Non-Sales - Banking & Fin Services</option>
                <option value="Others">Others</option>
                <option value="All">All</option>
              </select>
            </div>
          </div>
          
          <div class="pull-left marg-right">
            {{ Form::label('work_ex', 'Work Experience&nbsp;', array('class' => 'pull-left')) }} 
            <div class="pull-left cust-col">
             {{ Form::text('work_ex', Input::old('work_ex'), array('class' => 'form-control')) }}
           </div>
          </div>

        </div>
      
       <!--  <div class="pull-left marg-right">
         {{ Form::label('dob', 'Date', array('class' => 'pull-left')) }} 
         <div class="pull-left cust-col dob">
           {{ Form::text('dob', Input::old('dob'), array('class' => 'form-control', 'placeholder' => 'Y-m-d')) }}
         </div>
       </div> -->
        {{ Form::submit('Run', array('class' => 'btn btn-primary marg-right marg-top')) }}
        <button class="btn btn-danger marg-top" type="reset">Reset</button>
        <hr />
      </div> 
      {{ Form::close() }}

      {{ Form::open(array('url' => '/interviewDetails', 'enctype' => 'multipart/form-data')) }} 
      <h4>Upload Location, Date and Time:</h4>

      <div class="col-md-12">
        <div class="pull-left col-md-5">
          {{ Form::file('interviewdata', Input::old('interviewdata'), array('class' => 'pull-left', 'required' => 'true')) }}
          <p class="pull-left">You can download a csv skeleton copy<b><a href='/downloads/interview_details.csv'> here.</a></b></p>
          <p class="pull-left marg-bot"><span class="red">Please delete the first row before uploading.</span></p>
        </div>
      {{ Form::submit('Upload Location Details', array('class' => 'btn btn-primary pull-left')) }}
      </div>

      <div class="col-md-12"><hr /></div>
      {{ Form::close() }}
      
      <h4 class="pull-left marg-null">Upload Status:</h4><small>(Interview - Attending, Attended, Did Not Attend, Accecpted Offer, Full Payment, Rejected, Cleared, Certified)</small>
      {{ Form::open(array('url' => '/applicationStatus', 'enctype' => 'multipart/form-data')) }} 

      <div class="col-md-12">
        <div class="pull-left col-md-5">
          {{ Form::file('updatestatus', Input::old('updatestatus'), array('class' => 'pull-left', 'required' => 'true')) }}
          <p class="pull-left">You can download a csv skeleton copy<b><a href="/downloads/application_status.csv"> here.</a></b></p>
          <p class="pull-left marg-bot"><span class="red">Please delete the first row before uploading.</span></p>
        </div>
         {{ Form::submit('Update Status', array('class' => 'btn btn-primary pull-left')) }}
      </div>
      
      <div class="col-md-12"><hr /></div>
      {{ Form::close() }}
     <!--  <h4>Upload Job Acceptance Status:</h4>
     {{ Form::open(array('url' => '/interviewAttended')) }} 
        <div class="form-group col-md-12">
         {{ Form::file('attended', Input::old('attended', array('class' => 'pull-left'))) }}
         {{ Form::submit('Upload', array('class' => 'btn btn-primary pull-left')) }}
       </div>
       <div class="col-md-12"><hr /></div>
     {{ Form::close() }} -->
    </div>

    <div id="download" class="tab-pane">

      <div class="row">
      {{ Form::open(array('url' => '/downloadORsendmail')) }} 
        <div class="form-group marg-top col-md-4">
            {{ Form::label('job_cat_id', 'Job ID') }}
            {{ Form::select('job_cat_id', $users['job_ids'] , Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }}
            <!-- {{ Form::text('job_cat_id', Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }} -->
        </div>
        <div class="form-group marg-top col-md-4">
          {{ Form::label('status', 'Status') }}
          {{ Form::select('status', $users['application_status'] , Input::old('status'), array('class' => 'form-control')) }}
        </div>
        <div class="form-group marg-top col-md-4" style="margin-top: 3%">
          {{ Form::submit('Download', array('class' => 'btn btn-primary')) }}
        </div>
      {{ Form::close() }}
      </div>
    </div>

    <div id="mail" class="tab-pane">

      {{ Form::open(array('url' => '/downloadORsendmail')) }} 
        <div class="form-group marg-top">
            {{ Form::label('job_cat_id', 'Job ID') }}
            <!-- {{ Form::text('job_cat_id', Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }} -->
            {{ Form::select('job_cat_id', $users['job_ids'] , Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }}
        </div>
        <div class="form-group">
          {{ Form::label('status', 'Status') }}
          {{ Form::select('status', $users['application_status'] , Input::old('status'), array('class' => 'form-control', 'required' => 'true')) }}
        </div>
       <!-- <div class="form-group">
         {{ Form::label('to_date', 'To Date') }}<span><i class="icon-calendar"></i></span> 
         {{ Form::text('to_date', Input::old('to_date'), array('id' => 'dp2', 'class' => 'form-control datepicker', 'placeholder' => 'To', 'data-datepicker' => 'datepicker')) }}
       </div> -->
        <div class="col-md-11">
          <div class="form-group col-md-4">
            <label>From Date</label>
            <div class="input-append date pull-right"  id="dp2" data-date="2014-02-01" data-date-format="yyyy-mm-dd">
              <input name="from_date" class="span2" size="16" type="text" value="" readonly>
              <span class="add-on"><i class="icon-calendar"></i></span>
            </div>
          </div>

          <div class="form-group col-md-4">
            <label class=" pull-left">To Date</label>
            <div class="input-append date" id="dp1" data-date="2014-02-01" data-date-format="yyyy-mm-dd">
              <input name="to_date" class="span2" size="16" type="text" value="" readonly/>
              <span class="add-on"><i class="icon-th"></i></span>
            </div>
          </div>
        </div>
        
        <input id="sendmail" name="sendmail" type="hidden" value="1" />
        
        <div class="form-group">
          {{ Form::submit('Send Mail', array('class' => 'btn btn-primary')) }}
        </div>
      {{ Form::close() }}
    </div>

    <div id="tj" class="tab-pane">

     <div class="col-md-12">
        {{ Form::open(array('url' => '/uploadUsers', 'enctype' => 'multipart/form-data')) }} 
          {{ Form::label('uploadusers', 'Users CSV File Upload') }}
          {{ Form::file('uploadusers', Input::old('uploadusers'), array('class' => 'pull-left', 'required' => 'true')) }}
          <p>You can download a csv skeleton copy<b><a href="/downloads/uploadusers.csv"> here.</a></b></p>
          <p><span class="red">Please delete the first row before uploading.</span></p>
          {{ Form::submit('Upload Users', array('class' => 'btn btn-primary pull-left')) }}
        {{ Form::close() }}
      </div>
      <div class="col-md-12"><hr></div>
      <div class="form-group marg-top border">
        {{ Form::open(array('url' => '/downloadORsendmail')) }} 
          <div class="col-md-2 marg-top"> {{ Form::label('usertype', 'User Type') }}</div>
          <div class="col-md-4 marg-top">
            {{ Form::select('usertype', $users['usertype'] , Input::old('usertype'), array('class' => 'form-control', 'required' => 'true')) }}
          </div>
          <input id="job_cat_id" name="job_cat_id" type="hidden" value="1" >
          {{ Form::submit('Download Users Details', array('class' => 'btn btn-primary marg-top')) }}
        {{ Form::close() }}
      </div>
     
    </div>

    <!-- <div id="certification" class="tab-pane">
    
      <div class="col-md-12">
        {{ Form::open(array('url' => '/certificationStatus')) }} 
          <div class="form-group marg-top">
            {{ Form::label('job_cat_id', 'Job ID') }}
            {{ Form::select('job_cat_id', $users['job_ids'] , Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }}
            {{ Form::text('job_cat_id', Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }}
          </div>
          <input name="status" type="hidden" value="11" /> only Enrolled  candidates
          {{ Form::submit('Update Certification Status', array('class' => 'btn btn-primary pull-left')) }}
        {{ Form::close() }}
      </div>
      <div class="col-md-12"><hr></div>
        
    </div> -->
  
  </div>

  <script type="text/javascript">
    if (top.location != location) {
      top.location.href = document.location.href ;
    }

    $(function(){
      window.prettyPrint && prettyPrint();
      $('#dp1').datepicker({
        format: 'yyyy-mm-dd'
      });
      $('#dp2').datepicker({
        format: 'yyyy-mm-dd'
      });
      $('#dp1').datepicker();
     
      $('#dp2').datepicker();
          
      //redirecting to particular tab where error exits - creating registrations  
      /*var p = $("#upload").find("#form-errors").length;
      var p1 = $("#download").find("#form-errors").length;
      var p2 = $("#mail").find("#form-errors").length;
      var p3 = $("#tj").find("#form-errors").length;
       
      if(!p1 && p && !p2 && !p3) {
        $(".download, .mail, .users, .tj").removeClass("active");
        $(".upload").addClass("active");
      }
      else if(!p && p1 && !p2 && !p3) {
        $(".mail, .upload, .users, .tj").removeClass("active");
        $(".download").addClass("active");
      }
      else if(!p && p2 && !p1 && !p3) {
        $(".download, .upload, .users, .tj").removeClass("active");
        $(".mail").addClass("active");
      }
      else if(!p && !p2 && !p1 && p3) {
        alert('here');
        $(".download, .upload, .users, .mail").removeClass("active");
        $(".tj, #tj").addClass("active");
      }*/
    });
  </script>

@stop