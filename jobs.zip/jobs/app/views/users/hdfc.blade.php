@extends('layouts.main')
@section('content')
 
  <h1>Admin Dashboard</h1>
  @if(HTML::ul($errors->all()))
    <div id="form-errors" class="alert alert-block red">
      {{ Session::get('error') }} 
      {{ HTML::ul($errors->all()) }}
    </div>
  @elseif(Session::get('success'))
    <div class="alert alert-success alert-block">
      {{ Session::get('success') }} 
    </div>
  @elseif(Session::get('message')) 
    <div class="alert alert-info alert-block">
      {{ Session::get('message') }} 
    </div>
  @elseif(Session::get('warning')) 
    <div class="alert alert-warning alert-block">
      {{ Session::get('warning') }} 
    </div>
     @endif

  <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
    <li  class="active"><a href="#hdfc" data-toggle="tab">HDFC Jobs</a></li>
    <li><a href="#mail" data-toggle="tab">Send Mail</a></li>
    <li><a href="orders">Orders</a></li>
    <li><a href="#statusupdate" data-toggle="tab">Update Status</a></li>
    <li class="users"><a href="users">Back</a></li>
  </ul>

<div id="my-tab-content" class="tab-content">
    <div id="hdfc" class="tab-pane active col-md-12">   
      <?php 
        $page = Input::get('page', 1);
        $i = (10 * ($page -1)) + 1;
      ?>
      {{ Form::open(array('url' => '/hdfc')) }} <!-- Fliters --> 
        <div class="form-group col-md-12 marg-top" id="cv-filter" style="padding: 0;margin-bottom:0;">
          <div class="col-md-12">
            <div class="pull-left marg-right">
              {{ Form::label('application_id', 'Application ID') }}
              {{ Form::text('application_id', Input::get('application_id')) }}
            </div>
            <div class="pull-left marg-right">
              {{ Form::label('reference_id', 'Reference ID') }}
              {{ Form::text('reference_id', Input::get('reference_id')) }}
            </div>
            <div class="pull-left marg-right">
              {{ Form::label('email', 'Email') }}
              {{ Form::text('email', Input::get('email')) }}
            </div>
             <div class="pull-left marg-right">
              {{ Form::label('job_cat_id', 'Job ID') }}
             <!--  {{ Form::text('job_cat_id', Input::get('job_cat_id')) }} -->
              {{ Form::select('job_cat_id', $users['job_ids'], Input::get('job_cat_id')) }}
            </div>
          </div>
          <div class="col-md-12">
            <div class="pull-left marg-right">
              {{ Form::label('status', 'Status') }}
              {{ Form::select('status', $users['application_status'], Input::get('status')) }}
            </div>
             <div class="pull-left marg-right">
              {{ Form::label('usertype', 'User Type') }}
              {{ Form::select('usertype', $users['usertype'], Input::get('usertype')) }}
            </div>
            <div class="pull-left marg-right">
              <button class="btn btn-danger pull-left marg-right white" type="reset"><a href="/hdfc">Reset</a></button>
            </div>
            <div class="pull-left marg-right">
              {{ Form::submit('Filter', array('class' => 'btn btn-primary')) }}
            </div>
            <div class="pull-left marg-right">
              <button class="btn btn-primary" name="submit" value="download">Download</button>
            </div>
            {{ Form::close() }}
          </div>
        </div>
     <div class="col-md-12">
        <div class="col-md-2"><b>Form Filled & Eligible -</b> {{ $users['users_eligible'] }}</div>
       <div class="col-md-2"><b>Form Filled & Not Eligible -</b> {{ $users['users_ineligible'] }}</div>
       <div class="col-md-2"><b>Questionnaire Filled & Eligible -</b> {{ $users['users_qf'] }}</div> 
       <div class="col-md-2"><b>Fee Paid -</b> {{ $users['users_paid'] }}</div>
       <div class="col-md-2"><b>Test Cleared -</b> {{ $users['users_test_cleared'] }}</div>
       <div class="col-md-2"><b>Test Failed -</b> {{ $users['users_test_failed'] }}</div>
     </div> 
      {{$users['pagination']}}

      <table class="table table-striped table-bordered marg-top">
        <thead>
          <tr>
            <td>Sl.No.</td>
            <td>Application ID</td>
            <td>Reference ID</td>
            <td>Name</td>
            <td>Email</td>
            <td>Phone</td>
            <td>Job ID/Category</td>
            <td>Current Status</td>
            <td>Last Action Time</td>
            <td>CV download</td>
          </tr>
        </thead>
        <tbody>

          @foreach($users['users'] as $key => $value)
            <tr>
              <?php $reference_id = md5($value->application_id);
                    $reference_id = 'HDFC'.strtoupper(substr($reference_id, 0, 8));?>
              <td>{{ $i++ }}</td>
              <td>{{ $value->application_id }}</td>
              <td>{{ $reference_id }}</td>
              <td>{{ $value->first_name.' '.$value->last_name }}</td>
              <td>{{ $value->email }}</td>
              <td>{{ $value->phone }}</td>
              <td>{{ $value->job_cat_id.'/'.$value->category }}</td>
              <td>{{ $value->status }}</td>
              <td>{{ $value->updated_at }}</td>
              <td>{{ "<a href='/cvdownload/HDFC_".$value->application_id."'>CV download</a>" }}</td>
            </tr>
          @endforeach

        </tbody>
      </table>
    </div>


    <div id="mail" class="tab-pane">
        {{ Form::open(array('url' => '/hdfc')) }} 
          <div class="form-group marg-top">
              {{ Form::label('job_cat_id', 'Job ID') }}
              {{ Form::select('job_cat_id', $users['job_ids'] , Input::old('job_cat_id'), array('class' => 'form-control', 'required' => 'true')) }}
          </div>
          <div class="form-group">
            {{ Form::label('status', 'Status') }}
            {{ Form::select('status', $users['application_status'] , Input::old('status'), array('class' => 'form-control', 'required' => 'true')) }}
          </div>
                    
          <input id="sendmail" name="sendmail" type="hidden" value="1" />
          
          <div class="form-group">
            {{ Form::submit('Send Mail', array('class' => 'btn btn-primary')) }}
          </div>
        {{ Form::close() }}
    </div>

    <div id="statusupdate" class="tab-pane">
     <div class="col-md-12">
        <h4>Upload file to change status:</h4>
        {{ Form::open(array('url' => '/applicationStatus', 'enctype' => 'multipart/form-data')) }} 

        
          <div class="pull-left col-md-5">
            {{ Form::file('updatestatus', Input::old('updatestatus'), array('class' => 'pull-left', 'required' => 'true')) }}
            <p class="pull-left">You can download a csv skeleton copy<b><a href="/downloads/application_status.csv"> here.</a></b></p>
            <p class="pull-left marg-bot"><span class="red">Please delete the first row before uploading.</span></p>
          </div>
           <input id="hdfc_jobs" name="hdfc_jobs" type="hidden" value="1" />
           {{ Form::submit('Update Status', array('class' => 'btn btn-primary pull-left')) }}
        </div>
        <div class="col-md-12"><hr /></div>
        {{ Form::close() }}

        <div class="col-md-12">
          <div class="col-md-5"><h4 class="pull-left">Update course payment status</h4></div>
          <a class="btn btn-primary" href="update-payment-status">Update Orders</a>
           <!-- {{ HTML::link('update-payment-status', 'Update Payment Status', array('class'=>'btn btn-primary')) }} -->
        </div>
         <div class="col-md-12"><hr /></div>
    </div>

 </div>

@stop