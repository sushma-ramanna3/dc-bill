@extends('layouts.custom')

@section('content')

<div class="row hdfc">
<div class="col-md-10 col-md-offset-1">
<div class="panel panel-default">
  <div class="panel-heading">
    <?php echo " <b>Your Reference ID :</b>   ".'HDFC'.strtoupper(substr(md5($data['application'][0]->id), 0,8))." &nbsp; &nbsp;&nbsp;&nbsp; <b>JOB ID :</b> ".$data['job']->job_cat_id ?>
    <a id="rfloat" class="pull-right underline"><b>Go Back</b></a>

  </div>
  <?php //$interview_details = InterviewDetails::where('application_id',$data['application'][0]->id)->first();?>
  <table class="table">
  <thead>
    <td class="col-md-2"> Sl. No. </td>
    <td class="col-md-2"> Status </td>
    <td class="col-md-2"> Last Updated </td>
    <td class="col-md-2"> Action </td>
  </thead>
  <tbody>

  <?php
    if($data['job']->id == 7 ||$data['job']->id == 6 )
        $link = 'https://www.learnwithflip.com/buy-now.html?category_id=2793&category=Corporate-Banking-RM-and-Credit-Analysis-(HDFC-RM)';
    elseif($data['job']->id == 4 || $data['job']->id == 5) 
        $link = 'https://www.learnwithflip.com/buy-now.html?category_id=2794&category=Branch-Relationship-Manager-(HDFC-RM)';
  ?>
  
  @for($i=0; $i < count($data['status']); $i++)

    <tr>
        <td class="col-md-2"> {{ $i+1 }} </td>
      <td class="col-md-2"> {{ $data['status'][$i]->status_message }} </td>
      <td class="col-md-2">  {{ $data['status'][$i]->created_at }}</td>
      @if( $data['status'][$i]->status == 'Form Filled & Eligible' AND !isset($data['status'][$i+1]->status)  AND $data['job']->id != 6 AND $data['job']->id != 7 )
        <td> {{ '----' }} </td>
      @elseif( $data['status'][$i]->status == 'Questionnaire Filled & Eligible' AND !isset($data['status'][$i+1]->status) AND $data['job']->id != 6 AND $data['job']->id != 7 )
        <td> {{ '----' }} </td>
      @elseif($data['status'][$i]->status == 'Interview Cleared' AND !isset($data['status'][$i+1]->status))
        <td>{{ HTML::link($link, 'Click here to buy the course', array('class'=>'btn btn-primary', 'target' => '_blank')) }}
        <br>
            <span class="red "><small>Note: Post your payment the status will be updated in 24 hours.</small></span>
        </td>
      @elseif($data['status'][$i]->status == 'Interview Rejected' AND !isset($data['status'][$i+1]->status))
        <td><b>Interview Rejected</b>
        </td>
      @elseif($data['status'][$i]->status == 'Interview Not Attempted' AND !isset($data['status'][$i+1]->status))
        <td><b>Interview Not Attempted</b>
        </td>
      @elseif($data['status'][$i]->status == 'First Installment' AND !isset($data['status'][$i+1]->status))
        <td><b>First Installment Paid</b>
        </td>
      @elseif($data['status'][$i]->status == 'Confirmed Application' AND !isset($data['status'][$i+1]->status))
        <td>
            @if(isset($interview_details))
                {{ '----' }}
                <?php $show_confirm_button = true; ?>
               <!--{{ Form::open(array('action'=>'ApplicationStatusController@updatestatus')) }}
               {{ Form::hidden('application_id', $data['application'][0]->id) }}
               {{ Form::hidden('status','7') }}
               {{ Form::submit("Confirm", array('class'=>'btn btn-primary')) }}
               {{ Form::close() }} -->
          @else
                {{ '----' }}
          @endif
        </td>
      @else
        <td> {{ '----' }} </td>
      @endif
    </tr>
    @endfor
    </tbody>
  </table>

  @if (isset($interview_details))
  <hr>
<!--   <table class="table">
  <thead>
  <td class="col-md-2 " colspan="2">
  <div class="panel panel-default">
    <div class="panel-heading">
     <b>Interview Details</b>
    </div>
  </div>
  </td>
  </thead>
  <tbody>
  <tr>
    <td class="col-md-3"><b>Date (DD-MM-YYYY):</b></td>
    <td>{{ $interview_details->interview_date }}
      <?php 
       /* $date = $interview_details->interview_date;
        $timestamp = strtotime($date);
        $date1 = date("d-m-Y", $timestamp);
        echo $date1.'&nbsp;';
        $interview_day = date('l', $timestamp); 
        echo '['.$interview_day.']';*/
      ?> 
      
    </td>
  </tr>
   <tr>
    <td class="col-md-2"><b>Slot/Time:</b></td>
    <td>{{ $interview_details->interview_time }}</td>
  </tr>
  <tr>
    <td class="col-md-2"><b>Location:</b></td>
    <td>{{ $interview_details->interview_location_details }}</td>
  </tr>
  <tr>
    <td colspan="2">
      <p><b>Please carry the below documents:</b></p>

      <ul class="number-li">
          <li>Updated resume along with 2 recent color passport size photographs.</li>
          <li>Original and photocopy of passing certification or mark sheet of highest education.</li>
          <li>If you have worked with HDFC group companies, you are required to submit relieving letter.</li>
      </ul>

    </td>

  </tr>

  @if(isset($show_confirm_button))
    <tr><td colspan="2" class="red">By clicking confirm button, you agree that you have understood the job profile and the selection process. </td></tr>
    <tr><td colspan="2" align="center">
    
    {{ Form::open(array('action'=>'ApplicationStatusController@updatestatus')) }}
    {{ Form::hidden('application_id', $data['application'][0]->id) }}
    {{ Form::hidden('status','7') }}
    {{ Form::submit("Confirm", array('class'=>'btn btn-primary')) }}
    {{ Form::close() }}
    @endif
  </td></tr>
  </tbody>
</table> -->
  @endif
  
</div>
</div>
</div>
<script type="text/javascript">
  (function($) {
    document.title = 'Track Your Application Status';
    $("#custom_h1").html("Track Your Application Status");
    $("#custom_h1").css({'margin-top':'20px','font-size':'30px'});

    $('#rfloat').click(function(){ /*on back button click*/
          parent.history.back();
          proceedButton();
          return false;
    });

  })(jQuery);
</script>
@stop
