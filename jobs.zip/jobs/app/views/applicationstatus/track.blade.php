@extends('layouts.custom')

@section('content')
    <div class="row hdfc">
    <div class="col-md-5 col-md-offset-3">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">Track your application status</h3>
          </div>
        </div>
        <div class="panel-body">
          <!-- <form accept-charset="UTF-8" role="form"> -->
          {{ Form::open(array('action'=>'applicationstatus.store')) }}
            <fieldset>
             <div class="form-group">
              <!-- <input class="form-control" placeholder="E-mail" name="email" type="text"> -->
              {{ Form::text('email', null, array('class'=>'form-control','placeholder'=>'E-mail', 'required'=>'required')) }}
            </div>
            <div class="form-group">
             <!-- <input class="form-control" placeholder="Password" name="password" type="password" value=""> -->
            {{ Form::text('reference_id', null, array('class'=>'form-control','placeholder'=>'Reference ID', 'required'=>'required')) }}
            </div>
            <!-- <input class="btn btn-lg btn-success btn-block" type="submit" value="Login"> -->
            {{ Form::submit('Next', array('class' => 'btn btn-lg btn-success btn-block')) }}
          </fieldset>
          {{ Form::close() }}
            <!-- </form> -->
        </div>
      </div>
     <div class="col-md-11 text-center"><h4><a id="rfloat" class="underline"><b>Go Back</b></a></h4></div>
    </div>
<script type="text/javascript">
  (function($) {
    $('#rfloat').click(function(){ /*on back button click*/
          parent.history.back();
          proceedButton();
          return false;
    });
    
    document.title = 'Track Your Application Status';
    $("#custom_h1").html("Track Your Application Status");
    $("#custom_h1").css({'margin-top':'20px','font-size':'30px'});
    $('footer .pull-right').html('Call us:+91 9243.666.001 / 002 / 003 or +91 9243.726.044');

  })(jQuery);



</script>
@stop