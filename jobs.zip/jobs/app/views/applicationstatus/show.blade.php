@extends('layouts.custom')

@section('content')
<div class="row hdfc">
<div class="col-md-10 col-md-offset-1">
<div class="panel panel-default">
  <div class="panel-heading">

    <?php echo " <b>Your Reference ID :</b> # ".strtoupper(substr(md5($data['application'][0]->id), 0,8))." &nbsp; &nbsp;&nbsp;&nbsp; <b>JOB ID :</b> ".$data['job']->job_cat_id ?>
    <a href="/applications/1" class="pull-right underline"><b>Go Back</b></a>
  </div>
  <?php $interview_details = InterviewDetails::where('application_id',$data['application'][0]->id)->first();?>
  <table class="table">
  <thead>
    <td class="col-md-2"> Sl. No. </td>
    <td class="col-md-2"> Status </td>
    <td class="col-md-2"> Last Updated </td>
    <td class="col-md-2"> Action </td>
  </thead>
  <tbody>
  @for($i=0; $i < count($data['status']); $i++)
    <tr>
        <td class="col-md-2"> {{ $i+1 }} </td>
      <td class="col-md-2"> {{ $data['status'][$i]->status_message }} </td>
      <td class="col-md-2">  {{ $data['status'][$i]->created_at }}</td>
      @if( $data['status'][$i]->status == 'Eligible' AND !isset($data['status'][$i+1]->status))
        <td>{{ Form::open(array('action'=>'ApplicationStatusController@updatestatus')) }}
            {{ Form::hidden('application_id', $data['application'][0]->id) }}
            {{ Form::hidden('status','6') }}
            {{ Form::submit('Confirm', array('class'=>'btn btn-primary')) }}
            {{ Form::close() }}
        </td>
      @elseif($data['status'][$i]->status == 'Scheduled Inteview' AND !isset($data['status'][$i+1]->status))
        <td>{{ Form::open(array('action'=>'ApplicationStatusController@updatestatus')) }}
            {{ Form::hidden('application_id', $data['application'][0]->id) }}
            {{ Form::hidden('status','7') }}
            {{ Form::submit('Confirm', array('class'=>'btn btn-primary')) }}
            {{ Form::close() }}
        </td>
      @elseif($data['status'][$i]->status == 'Cleared')
        <td>{{ HTML::link('buy-now', 'Buy Now', array('class'=>'btn btn-primary')) }}
        </td>
      @elseif($data['status'][$i]->status == 'Confirmed Application' AND !isset($data['status'][$i+1]->status))
        <td>
            @if(isset($interview_details))
                {{ '----' }}
                <?php $show_confirm_button = true; ?>
               <!--{{ Form::open(array('action'=>'ApplicationStatusController@updatestatus')) }}
               {{ Form::hidden('application_id', $data['application'][0]->id) }}
               {{ Form::hidden('status','7') }}
               {{ Form::submit("Confirm", array('class'=>'btn btn-primary')) }}
               {{ Form::close() }} -->
            @else
                {{ '----' }}
            @endif
        </td>
      @else
        <td> {{ '----' }} </td>
      @endif
    </tr>
    @endfor
    </tbody>
  </table>

  @if (isset($interview_details))
  <hr>
  <table class="table">
    <thead>
    <td class="col-md-2 " colspan="2">
    <div class="panel panel-default">
      <div class="panel-heading">
       <b>Interview Details</b>
      </div>
    </div>
    </td>
    </thead>
    <tbody>
    <tr>
      <td class="col-md-3"><b>Date (DD-MM-YYYY):</b></td>
      <td><!-- {{ $interview_details->interview_date }} -->
        <?php 
          $date = $interview_details->interview_date;
          $timestamp = strtotime($date);
          $date1 = date("d-m-Y", $timestamp);
          echo $date1.'&nbsp;';
          $interview_day = date('l', $timestamp); 
          echo '['.$interview_day.']';
        ?> 
        
      </td>
    </tr>
     <tr>
      <td class="col-md-2"><b>Slot/Time:</b></td>
      <td>{{ $interview_details->interview_time }}</td>
    </tr>
    <tr>
      <td class="col-md-2"><b>Location:</b></td>
      <td>{{ $interview_details->interview_location_details }}</td>
    </tr>
    <tr>
      <td colspan="2">
        <p><b>Please carry the below documents:</b></p>

        <ul class="number-li">
            <li>Updated resume along with 2 recent color passport size photographs.</li>
            <li>Original and photocopy of passing certification or mark sheet of highest education.</li>
            <li>If you have worked with HDFC group companies, you are required to submit relieving letter.</li>
        </ul>

      </td>

    </tr>

    @if(isset($show_confirm_button))
      <tr><td colspan="2" class="red">By clicking confirm button, you agree that you have understood the job profile and the selection process. </td></tr>
      <tr><td colspan="2" align="center">
      
      {{ Form::open(array('action'=>'ApplicationStatusController@updatestatus')) }}
      {{ Form::hidden('application_id', $data['application'][0]->id) }}
      {{ Form::hidden('status','7') }}
      {{ Form::submit("Confirm", array('class'=>'btn btn-primary')) }}
      {{ Form::close() }}
      @endif
    </td></tr>
    </tbody>
  </table>
  @endif
  
</div>
</div>
</div>
@stop
