(function($) {
    //redirecting to particular tab where error exits - creating registrations  
    if(navigator.appVersion.indexOf("MSIE 8.")!=-1){
      //alert('IE 8');
      $('#apply :input').css({'width':'300px'});
      $('#apply').css({'text-align':'center'});
    }

   /* $("#preferred_job_location option[value=1]").attr('disabled','disabled').addClass('disable');
    $("#preferred_job_location option[value=2]").attr('disabled','disabled').addClass('disable');*/

    //$("#preferred_job_location option[value=2]").insertBefore("#preferred_job_location option[value=9]");

      // Javascript to enable link to tab
    var url = document.location.toString();
    if (url.match('#')) {
        $('.nav-tabs a[href=#'+url.split('#')[1]+']').tab('show') ;
        $(".intro").removeClass("active");
        $("."+url.split('#')[1]).addClass("active");
    } 

    // Change hash for page-reload
    $('.nav-tabs a').on('shown', function (e) {
        window.location.hash = e.target.hash;
    })

      var p = $("#apply").find("#form-errors").length;
      var p1 = $("#track").find("#form-errors").length;
      var successmessage = $("#success-message").length;
      if(!p1 && p) {
        $(".intro, #intro, #about, .about").removeClass("active");
        $(".apply, #apply").addClass("active");
      }
      if(!p && p1) {
        $(".intro, #intro, #about, .about").removeClass("active");
        $(".track, #track").addClass("active");
      }
      if(successmessage) {
        $(".intro, #intro").removeClass("active");
        $(".apply, #apply").addClass("active");
      }
      $('.apply_now').click(function(){
        $(".sales, .intro, .last-item").removeClass("active");
        $(".apply").addClass("active");
        $('html,body').animate({ scrollTop: 0 }, 'slow', function () {
        });
      });

      $('.about_role').click(function(){
        $(".sales, .intro, .last-item, .faq").removeClass("active");
        $(".about").addClass("active");
        $('html,body').animate({ scrollTop: 0 }, 'slow', function () {
        });
      });

      

      $("#first_name, #last_name").keypress(function(e){
        return letternumber(e);
      });

      function letternumber(e){
        var key;
        var keychar;
        if (window.event)
        key = window.event.keyCode;
        else if (e)
        key = e.which;
        else
        return true;
        keychar = String.fromCharCode(key);
        keychar = keychar.toLowerCase();
        // control keys
        if ((key==null) || (key==0) || (key==8) || 
        (key==9) || (key==13) || (key==27) )
        return true;
        // alphas and numbers
        else if ((("abcdefghijklmnopqrstuvwxyz   ").indexOf(keychar) > -1))
        return true;
        else
        return false;
      }

      $("#phone_number").live("keyup", function(){
          var value = $(this).val();
          if (!/^\d*$/.test(value)) {
              this.value = this.value.replace(/[^\d]/g,"");
           //   $(this).val("");
          }
      });


      $("#phone_number, #graduation_year, #post_graduation_year, .months, #puc_year, #sslc_year").live("keyup", function(){
          var value = $(this).val();
          if (!/^\d*$/.test(value)) {
              this.value = this.value.replace(/[^\d]/g,"");
           //   $(this).val("");
          }
      });


      $("#graduation_year, #post_graduation_year, #puc_year, #sslc_year").live("keyup", function(){
          var value = $(this).val();
          if (!/^\d*$/.test(value)) {
              this.value = this.value.replace(/[^\d]/g,"");
            //  $(this).val("");
          }
          if(value.length > 4)
          {
            var value1 = $(this).val();
            $(this).val(value1.substring(0,4));
            return;
          }
      });


      $("#sslc_year, #graduation_year, #post_graduation_year, #puc_year").blur(function(){
        
        var val = $(this).val();
       
          if(val.length > 4)
          {
            alert("Year cannot be greater than 4 digit");
          }
      });

      $("#phone_number").blur(function(){
        
        var val = $(this).val();
       
          if(val.length < 10)
          {
            alert("Phone number can not be lesser than 10 digit");
          }
      });

      $(".months").live("keyup", function(){
          var value = $(this).val();
          if (!/^\d*$/.test(value)) {
              this.value = this.value.replace(/[^\d]/g,"");
            //  $(this).val("");
          }
          if(value.length > 3)
          {
            var value1 = $(this).val();
            $(this).val(value1.substring(0,3));
            return;
          }
      });

      $('#graduation_percentage, #post_graduation_percentage, #sslc_percentage, #puc_percentage').live("keyup",function()
      {
        var value = $(this).val();
        var values = value.split("");
        var update = "";
        var transition = "";
        var expression = /(^\d+$)|(^\d+\.\d+$)|[,\.]/;
        var finalExpression = /^([0-9][0-9]*[,\.]?\d{0,2})$/;
        for(id in values)
        {
          if( expression.test(values[id]) == true && values[id] != '' )
          {
            transition+=''+values[id].replace(',','.');
            if( finalExpression.test(transition) == true ) {
              update+=''+values[id].replace(',','.');
            }
          }
        }
        $(this).val(update);
        var substr = update.split('.');

        if(substr[0].length>2)
        {
          alert("% value can't be greater than 100");
          $(this).val(update.substring(0,2));
          return;
        }

      /*  else if(value.length<2)
        {
          alert("Percentage value can't be less than 1 digit, if you entering GPA then convert it to percentage and proceed");
          return;
        }*/

        else if(substr[0].length == 2 && (update == 0 || update == 0.0 || update < 35)) {
          alert('% value must be at least 35');
          return;
        }
      });
  
      $('#post_graduation_stream').blur(function(){
        if($('#post_graduation_percentage').val() && $('#post_graduation_year').val() && !$(this).val()){
          alert("Please select post graduation course");
          $('#post_graduation_stream').focus();
        }
      });

      $('.preferred_job_location').change(function(){
        if($('#post_graduation_percentage').val() && $('#post_graduation_year').val() && !$('#post_graduation_stream').val()){
          alert("Please select post graduation course");
          $('#post_graduation_stream').focus();
        }
      });

      $('#graduation_percentage, #post_graduation_percentage').blur(function()
      {
        var value = $(this).val();
        if(value.length<2)
        {
          alert("If you are entering CGPA then convert it to percentage and proceed");
          return;
        }
      });

      $("#scroller").simplyScroll();

})(jQuery);